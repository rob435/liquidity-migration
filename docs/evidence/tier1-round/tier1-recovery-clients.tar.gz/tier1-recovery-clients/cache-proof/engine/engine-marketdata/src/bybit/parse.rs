//! Raw Bybit frame to typed values. No sockets, no state, no allocation:
//! every function here is pure over the received bytes, which is what makes
//! the whole parse path testable without a network.

use std::fmt;

use engine_types::FeedError;
use serde::de::{self, value::MapAccessDeserializer, Deserializer, MapAccess, SeqAccess, Visitor};
use serde::Deserialize;

use engine_types::BOOK_DEPTH;

/// One book level, already numeric.
#[derive(Copy, Clone, Debug, Default, PartialEq)]
pub struct Level {
    pub px: f64,
    pub qty: f64,
}

/// An absent side is `Option::None` at the frame level; an empty `Levels`
/// means the venue sent `[]`, which says "this side did not change".
#[derive(Copy, Clone, Debug, PartialEq)]
pub struct Levels {
    levels: [Level; BOOK_DEPTH],
    len: u8,
}

impl Default for Levels {
    fn default() -> Self {
        Self {
            levels: [Level::default(); BOOK_DEPTH],
            len: 0,
        }
    }
}

impl Levels {
    pub fn len(&self) -> usize {
        self.len as usize
    }

    pub fn is_empty(&self) -> bool {
        self.len == 0
    }

    /// The side's best level: index 0, which is where Bybit puts it on both
    /// sides (bids descending, asks ascending).
    pub fn best(&self) -> Option<Level> {
        (self.len > 0).then(|| self.levels[0])
    }

    pub fn iter(&self) -> impl Iterator<Item = Level> + '_ {
        self.levels[..self.len()].iter().copied()
    }
}

/// A book message, still keyed by venue symbol name.
#[derive(Copy, Clone, Debug, PartialEq)]
pub struct BookFrame<'a> {
    pub symbol: &'a str,
    pub depth: u8,
    /// True for `type: "snapshot"`, and for the `u == 1` service restart.
    pub snapshot: bool,
    pub update_id: u64,
    pub seq: u64,
    /// Absent means the message did not mention this side.
    pub bids: Option<Levels>,
    pub asks: Option<Levels>,
    pub venue_ts_ms: i64,
}

/// Public trades in one venue push, aggregated without retaining a heap list.
#[derive(Copy, Clone, Debug, PartialEq)]
pub struct TradeFrame<'a> {
    pub symbol: &'a str,
    pub buy_qty: f64,
    pub sell_qty: f64,
    pub last_px: f64,
    pub trade_count: u16,
    pub seq: u64,
    pub venue_ts_ms: i64,
}

/// A ticker message. Every field is optional because a delta carries only
/// what changed.
#[derive(Copy, Clone, Debug, PartialEq)]
pub struct TickerFrame<'a> {
    pub symbol: &'a str,
    pub snapshot: bool,
    pub last_px: Option<f64>,
    pub mark_px: Option<f64>,
    pub index_px: Option<f64>,
    pub funding_rate: Option<f64>,
    pub next_funding_ms: Option<i64>,
    pub venue_ts_ms: i64,
}

/// What one received frame turned out to be.
#[derive(Copy, Clone, Debug, PartialEq)]
// Book frames keep their fixed level arrays inline to avoid per-frame heaps.
#[allow(clippy::large_enum_variant)]
pub enum ParsedFrame<'a> {
    Book(BookFrame<'a>),
    Trades(TradeFrame<'a>),
    Ticker(TickerFrame<'a>),
    /// A subscribe/unsubscribe reply.
    Ack {
        op: &'a str,
        success: bool,
        ret_msg: &'a str,
    },
    /// The keep-alive reply.
    Pong,
    /// A frame the engine has no use for.
    Ignored,
}

/// Parse one frame from text.
pub fn parse_frame(raw: &str) -> Result<ParsedFrame<'_>, FeedError> {
    let env: Envelope<'_> =
        serde_json::from_str(raw).map_err(|e| FeedError::BadMessage(e.to_string()))?;
    frame_from(env)
}

/// Parse one frame from bytes, for binary websocket messages.
pub fn parse_frame_bytes(raw: &[u8]) -> Result<ParsedFrame<'_>, FeedError> {
    let env: Envelope<'_> =
        serde_json::from_slice(raw).map_err(|e| FeedError::BadMessage(e.to_string()))?;
    frame_from(env)
}

fn frame_from(env: Envelope<'_>) -> Result<ParsedFrame<'_>, FeedError> {
    // Control frames answer an `op` and carry no topic.
    if let Some(op) = env.op {
        return Ok(match op {
            "ping" | "pong" => ParsedFrame::Pong,
            "subscribe" | "unsubscribe" => ParsedFrame::Ack {
                op,
                success: env.success.unwrap_or(false),
                ret_msg: env.ret_msg.unwrap_or(""),
            },
            _ => ParsedFrame::Ignored,
        });
    }

    let Some(topic) = env.topic else {
        return Ok(ParsedFrame::Ignored);
    };
    let Some(symbol) = topic.rsplit_once('.').map(|(_, s)| s) else {
        return Ok(ParsedFrame::Ignored);
    };
    if symbol.is_empty() {
        return Ok(ParsedFrame::Ignored);
    }
    let snapshot = env.msg_type != Some("delta");

    if topic.starts_with("orderbook.") {
        let depth = topic
            .split('.')
            .nth(1)
            .and_then(|value| value.parse::<u8>().ok())
            .ok_or_else(|| FeedError::BadMessage(format!("invalid orderbook topic {topic}")))?;
        let DataPayload::Fields(data) = env.data.unwrap_or_default() else {
            return Err(FeedError::BadMessage(format!(
                "orderbook frame for {symbol} has array data"
            )));
        };
        let Some(update_id) = data.u else {
            return Err(FeedError::BadMessage(format!(
                "orderbook frame for {symbol} has no update id"
            )));
        };
        // `cts` is matching-engine time, closer to when the book actually
        // changed; `ts` is when the gateway sent it.
        let venue_ts_ms = env.cts.or(env.ts).unwrap_or(0);
        return Ok(ParsedFrame::Book(BookFrame {
            symbol,
            depth,
            snapshot: snapshot || update_id == 1,
            update_id,
            seq: data.seq.unwrap_or(0),
            bids: data.b,
            asks: data.a,
            venue_ts_ms,
        }));
    }

    if topic.starts_with("publicTrade.") {
        let DataPayload::Trades(rows) = env.data.unwrap_or_default() else {
            return Err(FeedError::BadMessage(format!(
                "public trade frame for {symbol} has object data"
            )));
        };
        if rows.trade_count == 0 {
            return Ok(ParsedFrame::Ignored);
        }
        return Ok(ParsedFrame::Trades(TradeFrame {
            symbol,
            buy_qty: rows.buy_qty,
            sell_qty: rows.sell_qty,
            last_px: rows.last_px,
            trade_count: rows.trade_count,
            seq: rows.seq,
            venue_ts_ms: rows.venue_ts_ms.or(env.ts).unwrap_or(0),
        }));
    }

    if topic.starts_with("tickers.") {
        let DataPayload::Fields(data) = env.data.unwrap_or_default() else {
            return Err(FeedError::BadMessage(format!(
                "ticker frame for {symbol} has array data"
            )));
        };
        return Ok(ParsedFrame::Ticker(TickerFrame {
            symbol,
            snapshot,
            last_px: data.last_price,
            mark_px: data.mark_price,
            index_px: data.index_price,
            funding_rate: data.funding_rate,
            next_funding_ms: data.next_funding_time,
            venue_ts_ms: env.ts.unwrap_or(0),
        }));
    }

    Ok(ParsedFrame::Ignored)
}

#[derive(Deserialize)]
struct Envelope<'a> {
    #[serde(borrow, default)]
    topic: Option<&'a str>,
    #[serde(borrow, default)]
    op: Option<&'a str>,
    #[serde(rename = "type", borrow, default)]
    msg_type: Option<&'a str>,
    #[serde(default)]
    ts: Option<i64>,
    #[serde(default)]
    cts: Option<i64>,
    #[serde(default)]
    success: Option<bool>,
    #[serde(borrow, default)]
    ret_msg: Option<&'a str>,
    #[serde(default)]
    data: Option<DataPayload>,
}

// Serde fills the fixed L50 arrays directly; boxing would add one allocation.
#[allow(clippy::large_enum_variant)]
enum DataPayload {
    Fields(DataFields),
    Trades(TradeRows),
}

impl Default for DataPayload {
    fn default() -> Self {
        Self::Fields(DataFields::default())
    }
}

impl<'de> Deserialize<'de> for DataPayload {
    fn deserialize<D: Deserializer<'de>>(d: D) -> Result<Self, D::Error> {
        struct PayloadVisitor;
        impl<'de> Visitor<'de> for PayloadVisitor {
            type Value = DataPayload;

            fn expecting(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                f.write_str("an object payload or public-trade row array")
            }

            fn visit_map<A: MapAccess<'de>>(self, map: A) -> Result<Self::Value, A::Error> {
                DataFields::deserialize(MapAccessDeserializer::new(map)).map(DataPayload::Fields)
            }

            fn visit_seq<A: SeqAccess<'de>>(self, mut seq: A) -> Result<Self::Value, A::Error> {
                let mut rows = TradeRows::default();
                while let Some(row) = seq.next_element::<TradeRow>()? {
                    rows.push(row).map_err(de::Error::custom)?;
                }
                Ok(DataPayload::Trades(rows))
            }
        }
        d.deserialize_any(PayloadVisitor)
    }
}

/// The union of the two payload shapes the engine subscribes to. Orderbook
/// and ticker messages share no field name, so one struct reads either in a
/// single pass over the bytes.
#[derive(Deserialize, Default)]
struct DataFields {
    #[serde(default)]
    b: Option<Levels>,
    #[serde(default)]
    a: Option<Levels>,
    #[serde(default)]
    u: Option<u64>,
    #[serde(default)]
    seq: Option<u64>,

    #[serde(rename = "lastPrice", default, deserialize_with = "opt_positive_f64")]
    last_price: Option<f64>,
    #[serde(rename = "markPrice", default, deserialize_with = "opt_positive_f64")]
    mark_price: Option<f64>,
    #[serde(rename = "indexPrice", default, deserialize_with = "opt_positive_f64")]
    index_price: Option<f64>,
    #[serde(rename = "fundingRate", default, deserialize_with = "opt_f64")]
    funding_rate: Option<f64>,
    #[serde(
        rename = "nextFundingTime",
        default,
        deserialize_with = "opt_positive_i64"
    )]
    next_funding_time: Option<i64>,
}

#[derive(Copy, Clone, Debug, Default)]
struct TradeRows {
    buy_qty: f64,
    sell_qty: f64,
    last_px: f64,
    trade_count: u16,
    seq: u64,
    venue_ts_ms: Option<i64>,
}

impl TradeRows {
    fn push(&mut self, row: TradeRow) -> Result<(), &'static str> {
        match row.side {
            TradeSide::Buy => {
                self.buy_qty += row.qty;
                if !self.buy_qty.is_finite() {
                    return Err("aggregated buy quantity is not finite");
                }
            }
            TradeSide::Sell => {
                self.sell_qty += row.qty;
                if !self.sell_qty.is_finite() {
                    return Err("aggregated sell quantity is not finite");
                }
            }
            TradeSide::Unknown => return Ok(()),
        }
        self.trade_count = self.trade_count.saturating_add(1);
        if row.seq >= self.seq {
            self.seq = row.seq;
            self.last_px = row.px;
            self.venue_ts_ms = Some(row.venue_ts_ms);
        }
        Ok(())
    }
}

#[derive(Deserialize)]
struct TradeRow {
    #[serde(rename = "S")]
    side: TradeSide,
    #[serde(rename = "v", deserialize_with = "required_positive_f64")]
    qty: f64,
    #[serde(rename = "p", deserialize_with = "required_positive_f64")]
    px: f64,
    #[serde(rename = "T", deserialize_with = "required_positive_i64")]
    venue_ts_ms: i64,
    #[serde(default)]
    seq: u64,
}

#[derive(Copy, Clone, Debug, PartialEq, Eq)]
enum TradeSide {
    Buy,
    Sell,
    Unknown,
}

impl<'de> Deserialize<'de> for TradeSide {
    fn deserialize<D: Deserializer<'de>>(d: D) -> Result<Self, D::Error> {
        struct SideVisitor;
        impl Visitor<'_> for SideVisitor {
            type Value = TradeSide;

            fn expecting(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                f.write_str("Buy or Sell")
            }

            fn visit_str<E: de::Error>(self, value: &str) -> Result<Self::Value, E> {
                Ok(match value {
                    "Buy" => TradeSide::Buy,
                    "Sell" => TradeSide::Sell,
                    _ => TradeSide::Unknown,
                })
            }
        }
        d.deserialize_str(SideVisitor)
    }
}

impl<'de> Deserialize<'de> for Levels {
    fn deserialize<D: Deserializer<'de>>(d: D) -> Result<Self, D::Error> {
        struct V;
        impl<'de> Visitor<'de> for V {
            type Value = Levels;
            fn expecting(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                f.write_str("an array of [price, quantity] pairs")
            }
            fn visit_seq<A: SeqAccess<'de>>(self, mut seq: A) -> Result<Levels, A::Error> {
                let mut out = Levels::default();
                while let Some(level) = seq.next_element::<Level>()? {
                    if (out.len as usize) < BOOK_DEPTH {
                        out.levels[out.len as usize] = level;
                        out.len += 1;
                    }
                }
                Ok(out)
            }
        }
        d.deserialize_seq(V)
    }
}

impl<'de> Deserialize<'de> for Level {
    fn deserialize<D: Deserializer<'de>>(d: D) -> Result<Self, D::Error> {
        struct V;
        impl<'de> Visitor<'de> for V {
            type Value = Level;
            fn expecting(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                f.write_str("a [price, quantity] pair")
            }
            fn visit_seq<A: SeqAccess<'de>>(self, mut seq: A) -> Result<Level, A::Error> {
                let px: Num = seq
                    .next_element()?
                    .ok_or_else(|| de::Error::invalid_length(0, &"a price"))?;
                let qty: Num = seq
                    .next_element()?
                    .ok_or_else(|| de::Error::invalid_length(1, &"a quantity"))?;
                while seq.next_element::<de::IgnoredAny>()?.is_some() {}
                if px.0 <= 0.0 {
                    return Err(de::Error::custom("book price must be positive"));
                }
                if qty.0 < 0.0 {
                    return Err(de::Error::custom("book quantity cannot be negative"));
                }
                Ok(Level {
                    px: px.0,
                    qty: qty.0,
                })
            }
        }
        d.deserialize_seq(V)
    }
}

/// A number the venue sends as a string.
struct Num(f64);

impl<'de> Deserialize<'de> for Num {
    fn deserialize<D: Deserializer<'de>>(d: D) -> Result<Self, D::Error> {
        d.deserialize_any(NumVisitor).and_then(|v| {
            v.map(Num)
                .ok_or_else(|| de::Error::custom("expected a number, found nothing"))
        })
    }
}

fn opt_f64<'de, D: Deserializer<'de>>(d: D) -> Result<Option<f64>, D::Error> {
    d.deserialize_any(NumVisitor)
}

fn required_f64<'de, D: Deserializer<'de>>(d: D) -> Result<f64, D::Error> {
    d.deserialize_any(NumVisitor)?
        .ok_or_else(|| de::Error::custom("expected a number, found nothing"))
}

fn opt_positive_f64<'de, D: Deserializer<'de>>(d: D) -> Result<Option<f64>, D::Error> {
    let value = opt_f64(d)?;
    if value.is_some_and(|value| value <= 0.0) {
        return Err(de::Error::custom("price must be positive"));
    }
    Ok(value)
}

fn required_positive_f64<'de, D: Deserializer<'de>>(d: D) -> Result<f64, D::Error> {
    let value = required_f64(d)?;
    if value <= 0.0 {
        return Err(de::Error::custom("value must be positive"));
    }
    Ok(value)
}

fn opt_positive_i64<'de, D: Deserializer<'de>>(d: D) -> Result<Option<i64>, D::Error> {
    let value = d.deserialize_any(IntVisitor)?;
    if value.is_some_and(|value| value <= 0) {
        return Err(de::Error::custom("timestamp must be positive"));
    }
    Ok(value)
}

fn required_positive_i64<'de, D: Deserializer<'de>>(d: D) -> Result<i64, D::Error> {
    let value = d
        .deserialize_any(IntVisitor)?
        .ok_or_else(|| de::Error::custom("expected an integer, found nothing"))?;
    if value <= 0 {
        return Err(de::Error::custom("timestamp must be positive"));
    }
    Ok(value)
}

/// Reads a number whether it arrives as a JSON string or a JSON number.
/// Bybit sends prices, sizes and times as strings, and uses `""` for a field
/// that does not apply, which reads as absent.
struct NumVisitor;

impl<'de> Visitor<'de> for NumVisitor {
    type Value = Option<f64>;

    fn expecting(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("a number, or a string holding one")
    }

    fn visit_str<E: de::Error>(self, v: &str) -> Result<Self::Value, E> {
        let v = v.trim();
        if v.is_empty() {
            return Ok(None);
        }
        let value = v
            .parse::<f64>()
            .map_err(|_| de::Error::custom(format!("not a number: {v}")))?;
        self.visit_f64(value)
    }

    fn visit_f64<E: de::Error>(self, v: f64) -> Result<Self::Value, E> {
        if !v.is_finite() {
            return Err(de::Error::custom("number must be finite"));
        }
        Ok(Some(v))
    }

    fn visit_i64<E: de::Error>(self, v: i64) -> Result<Self::Value, E> {
        Ok(Some(v as f64))
    }

    fn visit_u64<E: de::Error>(self, v: u64) -> Result<Self::Value, E> {
        Ok(Some(v as f64))
    }

    fn visit_unit<E: de::Error>(self) -> Result<Self::Value, E> {
        Ok(None)
    }

    fn visit_none<E: de::Error>(self) -> Result<Self::Value, E> {
        Ok(None)
    }

    fn visit_some<D: Deserializer<'de>>(self, d: D) -> Result<Self::Value, D::Error> {
        d.deserialize_any(NumVisitor)
    }
}

/// An exact integer the venue may send as a JSON number or as text.
struct IntVisitor;

impl<'de> Visitor<'de> for IntVisitor {
    type Value = Option<i64>;

    fn expecting(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("an exact integer, or a string holding one")
    }

    fn visit_str<E: de::Error>(self, value: &str) -> Result<Self::Value, E> {
        let value = value.trim();
        if value.is_empty() {
            return Ok(None);
        }
        value
            .parse::<i64>()
            .map(Some)
            .map_err(|_| de::Error::custom(format!("not an exact integer: {value}")))
    }

    fn visit_i64<E: de::Error>(self, value: i64) -> Result<Self::Value, E> {
        Ok(Some(value))
    }

    fn visit_u64<E: de::Error>(self, value: u64) -> Result<Self::Value, E> {
        i64::try_from(value)
            .map(Some)
            .map_err(|_| de::Error::custom("integer is outside the i64 range"))
    }

    fn visit_f64<E: de::Error>(self, value: f64) -> Result<Self::Value, E> {
        if !value.is_finite()
            || value.fract() != 0.0
            || value < i64::MIN as f64
            || value >= -(i64::MIN as f64)
        {
            return Err(de::Error::custom("number is not an exact i64 integer"));
        }
        Ok(Some(value as i64))
    }

    fn visit_unit<E: de::Error>(self) -> Result<Self::Value, E> {
        Ok(None)
    }

    fn visit_none<E: de::Error>(self) -> Result<Self::Value, E> {
        Ok(None)
    }

    fn visit_some<D: Deserializer<'de>>(self, d: D) -> Result<Self::Value, D::Error> {
        d.deserialize_any(IntVisitor)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    // Captured from the venue's public linear stream on 2026-08-13.
    const OB_SNAPSHOT: &str = r#"{"topic":"orderbook.1.BTCUSDT","ts":1786659828109,"type":"snapshot","data":{"s":"BTCUSDT","b":[["63561.5","1.776"]],"a":[["63561.6","4.848"]],"u":31398762,"seq":764144453970},"cts":1786659828107}"#;
    const TK_SNAPSHOT: &str = r#"{"topic":"tickers.BTCUSDT","type":"snapshot","data":{"symbol":"BTCUSDT","tickDirection":"ZeroPlusTick","price24hPcnt":"0.001455","lastPrice":"63561.60","prevPrice24h":"63469.20","highPrice24h":"63994.40","lowPrice24h":"62810.50","prevPrice1h":"63413.60","markPrice":"63560.80","indexPrice":"63585.51","openInterest":"59972.256","openInterestValue":"3811884569.16","turnover24h":"3515096831.9640","volume24h":"55362.9100","fundingIntervalHour":"8","fundingCap":"0.005","singleOpenInterest":"29986.128","singleOpenInterestValue":"1905942284.58","nextFundingTime":"1786665600000","fundingRate":"0.00005013","bid1Price":"63561.50","bid1Size":"1.760","ask1Price":"63561.60","ask1Size":"4.690","preOpenPrice":"","preQty":"","curPreListingPhase":""},"cs":764144442982,"ts":1786659827683}"#;
    const TK_DELTA: &str = r#"{"topic":"tickers.BTCUSDT","type":"delta","data":{"symbol":"BTCUSDT","indexPrice":"63585.74"},"cs":764144450620,"ts":1786659827983}"#;
    const ACK: &str = r#"{"success":true,"ret_msg":"","conn_id":"d9tc7k421nl91l9k6obg-s09y","req_id":"t1","op":"subscribe"}"#;
    const PONG: &str = r#"{"success":true,"ret_msg":"pong","conn_id":"d9tc7k421nl91l9k6obg-s09y","req_id":"p1","op":"ping"}"#;

    fn book(raw: &str) -> BookFrame<'_> {
        match parse_frame(raw).expect("parses") {
            ParsedFrame::Book(b) => b,
            other => panic!("expected a book frame, got {other:?}"),
        }
    }

    fn ticker(raw: &str) -> TickerFrame<'_> {
        match parse_frame(raw).expect("parses") {
            ParsedFrame::Ticker(t) => t,
            other => panic!("expected a ticker frame, got {other:?}"),
        }
    }

    fn trades(raw: &str) -> TradeFrame<'_> {
        match parse_frame(raw).expect("parses") {
            ParsedFrame::Trades(t) => t,
            other => panic!("expected public trades, got {other:?}"),
        }
    }

    #[test]
    fn orderbook_snapshot_reads_both_sides() {
        let b = book(OB_SNAPSHOT);
        assert_eq!(b.symbol, "BTCUSDT");
        assert!(b.snapshot);
        assert_eq!(b.update_id, 31398762);
        // cts wins over ts: it is matching-engine time.
        assert_eq!(b.venue_ts_ms, 1786659828107);
        assert_eq!(b.bids.unwrap().best().unwrap().px, 63561.5);
        assert_eq!(b.bids.unwrap().best().unwrap().qty, 1.776);
        assert_eq!(b.asks.unwrap().best().unwrap().px, 63561.6);
        assert_eq!(b.asks.unwrap().best().unwrap().qty, 4.848);
    }

    #[test]
    fn one_sided_delta_leaves_the_other_side_absent() {
        let raw = r#"{"topic":"orderbook.1.BTCUSDT","ts":1786659828200,"type":"delta","data":{"s":"BTCUSDT","b":[["63561.4","2.100"]],"a":[],"u":31398763},"cts":1786659828199}"#;
        let b = book(raw);
        assert!(!b.snapshot);
        assert_eq!(b.bids.unwrap().best().unwrap().px, 63561.4);
        // An empty array is "this side did not change", distinct from absent.
        assert!(b.asks.unwrap().is_empty());

        let missing = r#"{"topic":"orderbook.1.BTCUSDT","ts":1,"type":"delta","data":{"s":"BTCUSDT","b":[["63561.4","2.100"]],"u":31398764},"cts":1}"#;
        assert!(book(missing).asks.is_none());
    }

    #[test]
    fn zero_quantity_level_survives_the_parse() {
        // The parse reports it faithfully; removal is the state layer's job.
        let raw = r#"{"topic":"orderbook.1.BTCUSDT","ts":1,"type":"delta","data":{"s":"BTCUSDT","b":[["63561.5","0"]],"a":[],"u":31398765},"cts":1}"#;
        let b = book(raw);
        let best = b.bids.unwrap().best().unwrap();
        assert_eq!(best.px, 63561.5);
        assert_eq!(best.qty, 0.0);
    }

    #[test]
    fn update_id_one_is_a_service_restart_snapshot() {
        let raw = r#"{"topic":"orderbook.1.BTCUSDT","ts":1,"type":"delta","data":{"s":"BTCUSDT","b":[["1.0","1.0"]],"a":[["2.0","1.0"]],"u":1},"cts":1}"#;
        assert!(book(raw).snapshot);
    }

    #[test]
    fn tickers_snapshot_reads_the_fields_of_interest() {
        let t = ticker(TK_SNAPSHOT);
        assert_eq!(t.symbol, "BTCUSDT");
        assert!(t.snapshot);
        assert_eq!(t.last_px, Some(63561.60));
        assert_eq!(t.mark_px, Some(63560.80));
        assert_eq!(t.index_px, Some(63585.51));
        assert_eq!(t.funding_rate, Some(0.00005013));
        assert_eq!(t.next_funding_ms, Some(1786665600000));
        assert_eq!(t.venue_ts_ms, 1786659827683);
    }

    #[test]
    fn tickers_delta_reports_only_what_changed() {
        let t = ticker(TK_DELTA);
        assert!(!t.snapshot);
        assert_eq!(t.index_px, Some(63585.74));
        assert_eq!(t.last_px, None);
        assert_eq!(t.mark_px, None);
        assert_eq!(t.funding_rate, None);
        assert_eq!(t.next_funding_ms, None);
    }

    #[test]
    fn empty_string_field_reads_as_absent() {
        let raw = r#"{"topic":"tickers.BTCUSDT","type":"delta","data":{"symbol":"BTCUSDT","fundingRate":"","markPrice":"12.5"},"ts":7}"#;
        let t = ticker(raw);
        assert_eq!(t.funding_rate, None);
        assert_eq!(t.mark_px, Some(12.5));
    }

    #[test]
    fn malformed_numbers_are_rejected_before_they_reach_market_state() {
        for value in ["NaN", "inf", "-inf"] {
            let ticker = format!(
                r#"{{"topic":"tickers.BTCUSDT","type":"delta","data":{{"markPrice":"{value}"}},"ts":7}}"#
            );
            assert!(parse_frame(&ticker).is_err(), "accepted {value}");

            let book = format!(
                r#"{{"topic":"orderbook.1.BTCUSDT","type":"snapshot","data":{{"b":[["{value}","1"]],"a":[["2","1"]],"u":1}},"ts":7}}"#
            );
            assert!(parse_frame(&book).is_err(), "accepted {value}");
        }

        for timestamp in [r#""1.5""#, "1.5", r#""9223372036854775808""#] {
            let raw = format!(
                r#"{{"topic":"tickers.BTCUSDT","type":"delta","data":{{"nextFundingTime":{timestamp}}},"ts":7}}"#
            );
            assert!(parse_frame(&raw).is_err(), "accepted {timestamp}");
        }
    }

    #[test]
    fn prices_are_positive_and_book_removal_is_the_only_zero_quantity() {
        for (px, qty) in [("0", "1"), ("-1", "1"), ("1", "-1")] {
            let raw = format!(
                r#"{{"topic":"orderbook.1.BTCUSDT","type":"snapshot","data":{{"b":[["{px}","{qty}"]],"a":[["2","1"]],"u":1}},"ts":7}}"#
            );
            assert!(parse_frame(&raw).is_err(), "accepted [{px}, {qty}]");
        }

        let remove = r#"{"topic":"orderbook.1.BTCUSDT","type":"delta","data":{"b":[["1","0"]],"a":[],"u":2},"ts":7}"#;
        assert_eq!(book(remove).bids.unwrap().best().unwrap().qty, 0.0);

        for (qty, px) in [("0", "1"), ("1", "0"), ("-1", "1")] {
            let raw = format!(
                r#"{{"topic":"publicTrade.BTCUSDT","data":[{{"S":"Buy","v":"{qty}","p":"{px}","T":1}}]}}"#
            );
            assert!(parse_frame(&raw).is_err(), "accepted trade {qty} at {px}");
        }
    }

    #[test]
    fn subscription_ack_is_not_a_market_event() {
        assert_eq!(
            parse_frame(ACK).unwrap(),
            ParsedFrame::Ack {
                op: "subscribe",
                success: true,
                ret_msg: ""
            }
        );
        let failed = r#"{"success":false,"ret_msg":"Invalid symbol","conn_id":"x","req_id":"t1","op":"subscribe"}"#;
        assert_eq!(
            parse_frame(failed).unwrap(),
            ParsedFrame::Ack {
                op: "subscribe",
                success: false,
                ret_msg: "Invalid symbol"
            }
        );
    }

    #[test]
    fn pong_is_not_a_market_event() {
        assert_eq!(parse_frame(PONG).unwrap(), ParsedFrame::Pong);
        assert_eq!(parse_frame(r#"{"op":"pong"}"#).unwrap(), ParsedFrame::Pong);
    }

    #[test]
    fn unknown_topics_and_junk_are_handled() {
        assert_eq!(
            parse_frame(r#"{"topic":"publicTrade.BTCUSDT","data":[]}"#).unwrap(),
            ParsedFrame::Ignored
        );
        assert!(matches!(
            parse_frame("not json"),
            Err(FeedError::BadMessage(_))
        ));
        // A book frame with no update id cannot be sequenced, so it is a fault.
        let no_u = r#"{"topic":"orderbook.1.BTCUSDT","ts":1,"type":"delta","data":{"s":"BTCUSDT","b":[]},"cts":1}"#;
        assert!(matches!(parse_frame(no_u), Err(FeedError::BadMessage(_))));
    }

    #[test]
    fn bytes_and_text_agree() {
        assert_eq!(
            parse_frame(OB_SNAPSHOT).unwrap(),
            parse_frame_bytes(OB_SNAPSHOT.as_bytes()).unwrap()
        );
    }

    #[test]
    fn a_deeper_push_keeps_the_best_level_and_counts_the_rest() {
        let raw = r#"{"topic":"orderbook.50.BTCUSDT","ts":1,"type":"snapshot","data":{"s":"BTCUSDT","b":[["10","1"],["9","2"],["8","3"]],"a":[],"u":5},"cts":1}"#;
        let bids = book(raw).bids.unwrap();
        assert_eq!(bids.best(), Some(Level { px: 10.0, qty: 1.0 }));
        assert_eq!(bids.len(), 3);
    }

    #[test]
    fn public_trades_are_aggregated_by_aggressor_without_a_row_vector() {
        let raw = r#"{"topic":"publicTrade.BTCUSDT","type":"snapshot","ts":1003,"data":[{"T":1000,"s":"BTCUSDT","S":"Buy","v":"1.25","p":"100.1","seq":10},{"T":1001,"s":"BTCUSDT","S":"Sell","v":"0.50","p":"100.0","seq":11},{"T":1002,"s":"BTCUSDT","S":"Buy","v":"0.25","p":"100.2","seq":12}]}"#;
        let trades = trades(raw);
        assert_eq!(trades.symbol, "BTCUSDT");
        assert_eq!(trades.buy_qty, 1.5);
        assert_eq!(trades.sell_qty, 0.5);
        assert_eq!(trades.trade_count, 3);
        assert_eq!(trades.last_px, 100.2);
        assert_eq!(trades.seq, 12);
        assert_eq!(trades.venue_ts_ms, 1002);
    }

    #[test]
    fn l50_keeps_every_received_level_through_the_fixed_capacity() {
        let bids = (0..50)
            .map(|index| format!(r#"["{}","1"]"#, 100 - index))
            .collect::<Vec<_>>()
            .join(",");
        let raw = format!(
            r#"{{"topic":"orderbook.50.BTCUSDT","ts":1,"type":"snapshot","data":{{"s":"BTCUSDT","b":[{bids}],"a":[["101","1"]],"u":5,"seq":9}},"cts":1}}"#
        );
        let book = book(&raw);
        assert_eq!(book.depth, 50);
        assert_eq!(book.seq, 9);
        assert_eq!(book.bids.unwrap().len(), 50);
        assert_eq!(book.bids.unwrap().iter().last().unwrap().px, 51.0);
    }
}
