//! Shared contracts for the execution engine.
//!
//! Every other crate implements or consumes what is defined here. Changing a
//! public signature in this crate is an integration decision, not a local
//! edit — the orchestrating session owns this file set.
//!
//! Strategy observations retain binary64 compatibility. Execution amounts
//! retain exact values and provenance; prepared order terms carry exact
//! quantities and prices through the WAL to venue encoding.
//! Time: `recv_ns`-style fields are monotonic nanoseconds from the engine's
//! own clock (comparable to each other, not to wall time); `*_ms` fields are
//! venue wall-clock milliseconds.

pub mod clock;
pub mod execution_allocation;
pub mod ids;
pub mod identity;
pub mod market;
pub mod numeric;
pub mod order_terms;
pub mod orders;
pub mod portfolio;
pub mod portfolio_control;
pub mod quantize;
pub mod risk;
pub mod signal_lifecycle;
pub mod strategy;
pub mod strategy_process;
pub mod wal;

pub use async_trait::async_trait;
pub use ids::{StrategyId, Symbol, SymbolId, SymbolTable, TimerId};
pub use market::{
    BookLevel, Depth, Feed, FeedError, MarketEvent, MarketFeed, MarketState, OrderFeed, Quote,
    Subscription, Ticker, TradeFlow, BOOK_DEPTH,
};
pub use orders::{
    AccountInventory, AccountOrder, AccountPosition, Action, AmendSpec, ForcedClose,
    InstrumentRule, Intent, OrderAck, OrderFacts, OrderKind, OrderRequest, OrderUpdate,
    QuoteFillFeatures, RestingOrder, Side, StopSpec, TimeInForce, VenueError, VenueExecution,
    VenueOrder, WorkPolicy,
};
pub use risk::{AccountView, DenyReason, PositionView, RiskKernel, RiskVerdict};
pub use signal_lifecycle::{
    legacy_signal_lane, valid_signal_generation, ManagedSignalSource, SignalAdmissionSuspension,
    SignalAdmissionSuspensionReason, SignalGenerationState, SignalLane, SignalLegacyGeneration,
    SignalLifecycleRequest, SignalLifecycleResponse, SignalProducerLifecycle, SignalProducerReport,
    SignalProducerRoute, SIGNAL_LIFECYCLE_SCHEMA_VERSION,
};
pub use strategy::{
    CheckpointProvenance, EngineEvent, RuntimeControlCommand, RuntimeControlError,
    RuntimeControlFeed, RuntimeControlRequest, SignalError, SignalFeed, SignalFeedEvent,
    SignalGapRequest, SignalObservation, SignalReadinessRequest, SignalReadinessResponse,
    SignalSourceFrontier, Strategy, StrategyAccountSummary, StrategyCheckpoint,
    StrategyCheckpointIdentity, StrategyCtx, StrategyEvent, StrategyImportContext,
    StrategyImportSource, StrategyPositionFacts, TranslatedStrategyEvent, TranslatedStrategyState,
    MAX_DURABLE_SIGNAL_SUBSCRIPTIONS, MAX_SIGNAL_OBSERVATION_BYTES, MAX_SIGNAL_SUBSCRIPTIONS,
    MAX_STRATEGY_EVENT_BYTES, MAX_STRATEGY_STATE_BYTES, SIGNAL_OBSERVATION_SCHEMA_VERSION,
    SIGNAL_READINESS_REQUEST_FILE, SIGNAL_READINESS_RESPONSE_FILE, SIGNAL_READINESS_SCHEMA_VERSION,
    STRATEGY_ENTRY_PERMISSION_SCHEMA_VERSION,
};
pub use wal::{
    AnchorState, FilledTotal, IntendedStop, OpenOrderState, RecentExecutionId, SignalCursor,
    SignalGap, SignalSubscriptionState, StrategyCheckpointState, StrategyGlobalCheckpointState,
    StrategySymbol, SymbolTotal, Wal, WalError, WalRecord,
};

/// Which venue account a gateway's credentials actually reach, as the venue
/// itself reports it.
///
/// Read from the venue rather than from config on purpose: config says which
/// key to sign with, and only the venue can say whose account that key opens.
/// Two engines pointed at one account by two different config files have to
/// arrive at the same answer here, because this is what names the lock that
/// keeps them from both sending.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct AccountIdentity {
    /// Which venue this account lives on: `bybit`, `hyperliquid`, `lighter`,
    /// `variational`. Part of the single-writer lock's name, because two
    /// venues can hand out the same account number and they are not the same
    /// account.
    pub venue: String,
    /// The venue's own name for the account. A number on Bybit and Lighter, a
    /// wallet address on Hyperliquid — whatever that venue calls the thing the
    /// credentials open.
    pub user_id: String,
    /// Which of the venue's realms: `demo` or `mainnet` on Bybit, and
    /// venue-qualified elsewhere (`hyperliquid_mainnet`), so that a realm
    /// string read out of a heartbeat can only mean one venue's account.
    pub realm: String,
}

/// What a venue can actually do. Venues differ in kind, not just in address:
/// one holds a position-level stop for you, the next expects you to work the
/// exit yourself. The engine reads these and refuses an action the venue
/// cannot honour, rather than quietly substituting a different trade.
///
/// Every field is stated by the adapter. There is no default: a wrong guess
/// here is a strategy believing it has a stop it does not have.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct VenueCaps {
    /// The venue keeps a position-level stop the engine can set and move
    /// (Bybit's full-position trading stop). False means a stop has to be
    /// worked as an ordinary reduce-only order by whoever wants one.
    pub native_position_stop: bool,
    /// A resting order can be repriced or resized in place, keeping its
    /// venue identity.
    pub amend_in_place: bool,
    /// The venue's margin leverage for a symbol can be set by the engine.
    /// False means whatever leverage the symbol already carries is what an
    /// order will post margin at, and the engine has no say in it.
    pub set_leverage: bool,
    /// The venue accepts an explicit close-entire-position order below its
    /// ordinary quantity or value minimum. The engine uses this only for a
    /// market exit that matches the whole position in a fresh account view.
    pub close_position_below_minimum: bool,
}

/// A venue gateway: signs and sends orders, attaches stops, reads account
/// state. One implementation per venue; the engine picks one by name at
/// assembly and never learns which it got.
///
/// Whether a given adapter is allowed to touch real money is that adapter's
/// own decision, made in its own crate — this trait deliberately cannot
/// express an endpoint.
#[async_trait]
pub trait VenueGateway: Send + 'static {
    /// What this venue can do. Read before asking it for anything exotic.
    fn caps(&self) -> VenueCaps;
    /// Whose account these credentials open. Asked once at boot, before
    /// anything is sent: it is what the single-writer lock is named after, so
    /// an engine that cannot answer it does not know what it would be
    /// stepping on.
    async fn account_identity(&mut self) -> Result<AccountIdentity, VenueError>;
    /// Place an order. The caller has already made the intent durable.
    async fn send_order(&mut self, req: &OrderRequest) -> Result<OrderAck, VenueError>;
    /// Place a group whose durable records share one barrier.
    ///
    /// Results are in request order and there is exactly one result per
    /// request. The default keeps wire order strict for venues whose nonces
    /// must arrive in sequence. Adapters that can safely overlap requests or
    /// use a native batch endpoint override it.
    async fn send_orders(&mut self, reqs: &[OrderRequest]) -> Vec<Result<OrderAck, VenueError>> {
        let mut out = Vec::with_capacity(reqs.len());
        for req in reqs {
            out.push(self.send_order(req).await);
        }
        out
    }
    /// Cancel by the engine's own client order id.
    async fn cancel_order(
        &mut self,
        symbol: SymbolId,
        client_order_id: &str,
    ) -> Result<(), VenueError>;
    /// Cancel a group of known orders. Results are in request order and there
    /// is exactly one result per request. The default preserves compatibility
    /// for adapters without a native batch endpoint; adapters with one should
    /// override this so a circuit breaker can pull a book in one wire turn.
    async fn cancel_orders(
        &mut self,
        requests: &[(SymbolId, String)],
    ) -> Vec<Result<(), VenueError>> {
        let mut out = Vec::with_capacity(requests.len());
        for (symbol, client_order_id) in requests {
            out.push(self.cancel_order(*symbol, client_order_id).await);
        }
        out
    }
    /// Reprice or resize a resting order in place. Only called when
    /// [`VenueCaps::amend_in_place`] is true.
    async fn amend_order(
        &mut self,
        symbol: SymbolId,
        client_order_id: &str,
        spec: AmendSpec,
    ) -> Result<(), VenueError>;
    /// Exact timing marks for the most recent cancel or amend when the
    /// transport exposes them. Taking the value clears it so an older
    /// request can never be attributed to a later command.
    fn take_mutation_timing(&mut self) -> Option<VenueMutationTiming> {
        None
    }
    /// How long the adapter held the most recent order command back to stay
    /// inside the venue's request quota, in nanoseconds. `None` when the
    /// adapter does not pace itself.
    ///
    /// This is delay we chose, not delay the venue imposed, and the two ask
    /// for opposite fixes: a large venue leg is a network or matching-engine
    /// problem, a large wait here is a quota that needs raising or a strategy
    /// asking for more requests than it has. The venue task's own span cannot
    /// tell them apart, so it is measured separately. Taking the value clears
    /// it, so an older command's wait is never charged to a later one.
    fn take_rate_wait_ns(&mut self) -> Option<u64> {
        None
    }
    /// Attach or move a position stop (stop-loss trigger price).
    ///
    /// Called whatever the caps say. Reconciliation puts back a stop the log
    /// says a position was opened behind, and a venue whose caps under-declare
    /// must not be the reason a held position stays naked.
    async fn set_stop(&mut self, symbol: SymbolId, trigger_px: f64) -> Result<(), VenueError>;
    async fn set_stop_exact(&mut self, _symbol: SymbolId, _terms: &crate::order_terms::ExactStopTerms) -> Result<(), VenueError> {
        Err(VenueError::Unsupported("exact standalone stops are unavailable".into()))
    }

    /// Start trading a symbol this gateway was not built with, and return the
    /// id it will use. `None` if it cannot grow.
    ///
    /// Part of the same lockstep the feeds are in: every table that maps names
    /// to ids has to gain a symbol in the same order, because a `SymbolId` is
    /// an index assigned by position.
    fn add_symbol(&mut self, symbol: &str) -> Option<SymbolId> {
        let _ = symbol;
        None
    }
    /// Set the venue's margin leverage for a symbol, both sides. Only called
    /// when [`VenueCaps::set_leverage`] is true, and only before an order that
    /// would increase exposure.
    ///
    /// Leverage decides how much margin a position posts, so an engine that
    /// cannot set it is trading at whatever the last person to touch the
    /// symbol chose. Setting it to the value it already holds must succeed:
    /// venues tend to report that as an error, and it is not one.
    ///
    /// The default refuses, so a venue that has not implemented it cannot
    /// quietly claim the leverage was applied.
    async fn set_leverage(&mut self, symbol: SymbolId, leverage: f64) -> Result<(), VenueError> {
        let _ = (symbol, leverage);
        Err(VenueError::BadRequest(
            "this venue cannot set leverage, and said so in its caps".to_string(),
        ))
    }
    /// Current positions and equity. On Bybit this is two venue reads
    /// (wallet and positions), issued together.
    async fn account_view(&mut self) -> Result<AccountView, VenueError>;
    /// Tick size, quantity step, and minimums for every tradable symbol.
    async fn instrument_rules(&mut self) -> Result<Vec<(Symbol, InstrumentRule)>, VenueError>;
    fn restore_instrument_catalog(&self, _checkpoint: &crate::orders::InstrumentCatalogCheckpoint) -> Result<crate::orders::InstrumentCatalog, VenueError> {
        Err(VenueError::Unsupported("durable instrument catalog restore".into()))
    }
    fn install_instrument_catalog(&mut self, _catalog: &crate::orders::InstrumentCatalog) -> Result<(), VenueError> {
        Err(VenueError::Unsupported("instrument catalog installation is unavailable".into()))
    }
    fn instrument_catalog_client(&self) -> Option<Box<dyn crate::orders::InstrumentCatalogClient>> { None }
    fn account_recovery_client(&self) -> Option<Box<dyn orders::AccountRecoveryClient>> { None }
    fn order_lookup_client(&self) -> Option<Box<dyn orders::OrderLookupClient>> {
        None
    }

    /// Exact client-ID lookup; absence in a retained history is not proof of no acceptance.
    async fn order_status(
        &mut self,
        _symbol: SymbolId,
        _client_order_id: &str,
    ) -> Result<orders::OrderLookup, VenueError> {
        Ok(orders::OrderLookup::Unavailable)
    }

    /// Exact instrument capabilities; absence is never reconstructed from legacy floats.
    async fn instrument_specs(
        &mut self,
    ) -> Result<Vec<(Symbol, numeric::ExactInstrumentSpec)>, VenueError> {
        Err(VenueError::BadReply(
            "exact instrument capabilities are unavailable for this venue".to_owned(),
        ))
    }
    /// Every order the venue is currently working on this account, whoever
    /// placed it. Read at boot: the log says what this engine sent, and only
    /// the venue can say what is actually out there.
    async fn working_orders(&mut self) -> Result<Vec<VenueOrder>, VenueError>;
    /// Complete machine-enumerable credential inventory for deployment
    /// flatness checks.
    ///
    /// This is wider than the symbols configured in the engine. An adapter
    /// must scan every listable product, asset-account, and settlement surface
    /// its credentials can reach, including unknown and delisted symbols, or
    /// return an error. If a venue exposes latent automation that no API can
    /// enumerate, the adapter must additionally enforce a venue-specific
    /// dedicated-account contract during identity verification; a sample-time
    /// zero balance alone is not proof that such automation is absent.
    async fn account_inventory(&mut self) -> Result<AccountInventory, VenueError> {
        Err(VenueError::BadRequest(
            "this venue cannot prove account-wide flatness".to_string(),
        ))
    }
    /// Every execution on this account between the two wall-clock times,
    /// whoever ordered it — the venue's own history, read to recover fills
    /// the private stream never delivered (an engine-down gap, a reconnect
    /// gap). Recovery fails closed when the required interval is unavailable;
    /// the default refusal therefore prevents a boot that cannot prove it
    /// recovered the whole gap.
    async fn executions(
        &mut self,
        start_ms: i64,
        end_ms: i64,
    ) -> Result<Vec<VenueExecution>, VenueError> {
        let _ = (start_ms, end_ms);
        Err(VenueError::BadRequest(
            "this venue cannot list its execution history".to_string(),
        ))
    }
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct VenueMutationTiming {
    pub sent_ns: u64,
    pub ack_ns: u64,
}

pub use wal::{StrategyEffectsState, StrategyTransitionState};

pub mod order_dispatch;
