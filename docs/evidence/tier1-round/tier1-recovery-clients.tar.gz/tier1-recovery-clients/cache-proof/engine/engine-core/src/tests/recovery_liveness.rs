use super::*;

struct ExitOnQuote;
impl Strategy for ExitOnQuote {
    fn name(&self) -> &str { "recovery-exit" }
    fn subscriptions(&self) -> Vec<Subscription> { vec![Subscription { symbol: "BTCUSDT".into(), feed: Feed::Quote }] }
    fn on_event(&mut self, event: &EngineEvent, ctx: &mut dyn StrategyCtx) {
        if let EngineEvent::Market(MarketEvent::Quote { symbol, .. }) = event {
            ctx.place(Intent { strategy: StrategyId(0), symbol: *symbol, side: Side::Sell, qty: 0.01, kind: OrderKind::Market, stop: None, reduce_only: true, tag: "while-recovery-waits".into(), decided_ns: ctx.now_ns(), work: None, leverage: None });
        }
    }
}

struct QuoteAfterRead {
    control: Arc<MockRecoveryControl>,
    history: bool,
    sent: bool,
}
impl MarketFeed for QuoteAfterRead {
    async fn next_event(&mut self) -> Result<MarketEvent, FeedError> {
        if self.sent { return std::future::pending().await; }
        if self.history { self.control.history_started.notified().await; }
        else { self.control.account_started.notified().await; }
        self.sent = true;
        Ok(MarketEvent::Quote { symbol: SymbolId(0), quote: Quote { bid_px: 30_000.0, bid_qty: 10.0, ask_px: 30_001.0, ask_qty: 10.0, venue_ts_ms: clock::wall_ms(), recv_ns: clock::now_ns() } })
    }
}

async fn stalled_recovery(history: bool) {
    let (mut engine, h) = super::order_path::build_exit_inventory(vec![Box::new(ExitOnQuote)], &[(StrategyId(0), Side::Buy, 0.01)], None).await;
    let delay = if history { &h.recovery_reads.history_delay_ms } else { &h.recovery_reads.account_delay_ms };
    delay.store(300, std::sync::atomic::Ordering::Relaxed);
    let held = engine.account().positions.clone();
    h.account_readings.lock().unwrap().extend([held.clone(), held]);
    let mut market = QuoteAfterRead { control: h.recovery_reads.clone(), history, sent: false };
    let update = OrderUpdate::Ack(OrderAck { client_order_id: "private-during-recovery".into(), venue_order_id: "observed-before-read-return".into(), sent_ns: 1, ack_ns: clock::now_ns() });
    let mut private = ScriptOrderFeed::playing(vec![OrderUpdate::StreamReset { recv_ns: clock::now_ns() }, update]);
    let deadline = tokio::time::Instant::now() + Duration::from_millis(150);
    engine.run(&mut market, &mut private, tokio::time::sleep_until(deadline)).await.unwrap();
    assert!(h.records.lock().unwrap().iter().any(|row| matches!(row, WalRecord::OrderUpdate { update: OrderUpdate::Ack(ack), .. } if ack.client_order_id == "private-during-recovery")), "a delayed recovery read stopped private order news");
    assert_eq!(h.sends.lock().unwrap().iter().filter(|request| request.reduce_only && request.side == Side::Sell).count(), 1, "a recovery read held the urgent reducing order behind REST");
}

#[tokio::test]
async fn delayed_account_recovery_keeps_private_news_and_reductions_live() { stalled_recovery(false).await; }

#[tokio::test]
async fn delayed_execution_history_keeps_private_news_and_reductions_live() { stalled_recovery(true).await; }
