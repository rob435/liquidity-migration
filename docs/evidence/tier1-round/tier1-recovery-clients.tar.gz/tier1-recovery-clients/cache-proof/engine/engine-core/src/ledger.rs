//! The latency ledger: how long each part of our own side of the wire took.
//!
//! Timing segments, all measured on the one monotonic clock:
//!
//! - **decide** — market message arrived (`recv_ns`) until the strategy's
//!   intent was decided.
//! - **durable** — intent decided until the order group's durability barrier
//!   is requested. Disk completion is still outstanding; this is not fsync
//!   duration. **barrier wait** measures the later wait for that completion.
//! - **submit result** — intent decided until `send_orders` returned (in
//!   shadow mode, until the point where the send was skipped). This includes
//!   the adapter's request, response, and reply parsing; it is not a socket
//!   write timestamp.
//! - **API round trip** — socket write completion until the adapter parsed
//!   the venue acknowledgement. This excludes local queueing and signing.
//! - **dispatch queue** — command queued until the venue task began it.
//! - **venue task** — venue task start until the adapter returned.
//! - **core resume** — adapter return until the engine handled the result.
//!
//! **market to submit result** is market message in until the batch submit
//! call returned and result handling began.

use hdrhistogram::Histogram;

use engine_types::WalRecord;

pub const WINDOW_NS: u64 = 60_000_000_000;

/// Histograms are sized once, at boot, to cover a nanosecond up to a minute
/// with three digits of precision. A self-resizing histogram would allocate
/// in the middle of the hot path and measure its own allocation; anything
/// slower than a minute is recorded as a minute.
const CEILING_NS: u64 = 60_000_000_000;

#[derive(Copy, Clone, Debug, Default, PartialEq)]
pub struct Quantiles {
    pub count: u64,
    pub p50_ns: u64,
    pub p90_ns: u64,
    pub p99_ns: u64,
    pub p999_ns: u64,
    pub max_ns: u64,
}

#[derive(Copy, Clone, Debug, PartialEq)]
pub enum Segment {
    Decide,
    Durable,
    /// What the order path actually waited for the disk, after the barrier
    /// was moved alongside the send. Usually zero: the venue's round trip
    /// outlasts the disk's. A number here is the disk winning that race.
    BarrierWait,
    /// How long the venue adapter held a command back to stay inside the
    /// venue's request quota. Pacing this engine chose, not latency the venue
    /// imposed — the two ask for opposite fixes.
    QuotaHold,
    Wire,
    Ack,
    DispatchQueue,
    VenueTask,
    CoreResume,
    EndToEnd,
}

impl Segment {
    pub const ALL: [Self; 10] = [
        Self::Decide,
        Self::Durable,
        Self::BarrierWait,
        Self::QuotaHold,
        Self::Wire,
        Self::Ack,
        Self::DispatchQueue,
        Self::VenueTask,
        Self::CoreResume,
        Self::EndToEnd,
    ];

    pub fn plain_name(self) -> &'static str {
        match self {
            Segment::Decide => "think",
            Segment::Durable => "write it down",
            Segment::BarrierWait => "still waiting on the disk",
            Segment::QuotaHold => "held back for quota",
            Segment::Wire => "submit result",
            Segment::Ack => "API round trip",
            Segment::DispatchQueue => "dispatch queue",
            Segment::VenueTask => "venue task",
            Segment::CoreResume => "core resume",
            Segment::EndToEnd => "market to submit result",
        }
    }
}

pub struct LatencyLedger {
    decide: Histogram<u64>,
    durable: Histogram<u64>,
    barrier_wait: Histogram<u64>,
    quota_hold: Histogram<u64>,
    wire: Histogram<u64>,
    ack: Histogram<u64>,
    dispatch_queue: Histogram<u64>,
    venue_task: Histogram<u64>,
    core_resume: Histogram<u64>,
    end_to_end: Histogram<u64>,
    events: u64,
    window_start_ns: u64,
}

impl LatencyLedger {
    pub fn new(now_ns: u64) -> Self {
        let make = || Histogram::<u64>::new_with_bounds(1, CEILING_NS, 3).expect("histogram");
        LatencyLedger {
            decide: make(),
            durable: make(),
            barrier_wait: make(),
            quota_hold: make(),
            wire: make(),
            ack: make(),
            dispatch_queue: make(),
            venue_task: make(),
            core_resume: make(),
            end_to_end: make(),
            events: 0,
            window_start_ns: now_ns,
        }
    }

    pub fn record(&mut self, segment: Segment, ns: u64) {
        self.histogram(segment).saturating_record(ns);
    }

    /// One more market message seen. Counted whether or not it led anywhere.
    pub fn saw_event(&mut self) {
        self.events += 1;
    }

    pub fn quantiles(&self, segment: Segment) -> Quantiles {
        let h = match segment {
            Segment::Decide => &self.decide,
            Segment::Durable => &self.durable,
            Segment::BarrierWait => &self.barrier_wait,
            Segment::QuotaHold => &self.quota_hold,
            Segment::Wire => &self.wire,
            Segment::Ack => &self.ack,
            Segment::DispatchQueue => &self.dispatch_queue,
            Segment::VenueTask => &self.venue_task,
            Segment::CoreResume => &self.core_resume,
            Segment::EndToEnd => &self.end_to_end,
        };
        Quantiles {
            count: h.len(),
            p50_ns: h.value_at_quantile(0.50),
            p90_ns: h.value_at_quantile(0.90),
            p99_ns: h.value_at_quantile(0.99),
            p999_ns: h.value_at_quantile(0.999),
            max_ns: h.max(),
        }
    }

    pub fn events(&self) -> u64 {
        self.events
    }

    pub fn due(&self, now_ns: u64) -> bool {
        now_ns.saturating_sub(self.window_start_ns) >= WINDOW_NS
    }

    pub fn decisions(&self) -> u64 {
        self.decide.len()
    }

    /// The log record for the window just ended.
    pub fn record_for_wal(&self, now_ns: u64) -> WalRecord {
        let decide = self.quantiles(Segment::Decide);
        let durable = self.quantiles(Segment::Durable);
        let barrier_wait = self.quantiles(Segment::BarrierWait);
        let wire = self.quantiles(Segment::Wire);
        let ack = self.quantiles(Segment::Ack);
        let dispatch_queue = self.quantiles(Segment::DispatchQueue);
        let venue_task = self.quantiles(Segment::VenueTask);
        let core_resume = self.quantiles(Segment::CoreResume);
        let end_to_end = self.quantiles(Segment::EndToEnd);
        WalRecord::LatencyLedger {
            window_s: (now_ns.saturating_sub(self.window_start_ns) / 1_000_000_000) as u32,
            events: self.events,
            decide_p50_ns: decide.p50_ns,
            decide_p99_ns: decide.p99_ns,
            decide_p999_ns: (decide.count > 0).then_some(decide.p999_ns),
            durable_p50_ns: durable.p50_ns,
            durable_p99_ns: durable.p99_ns,
            durable_p999_ns: (durable.count > 0).then_some(durable.p999_ns),
            barrier_wait_p50_ns: barrier_wait.p50_ns,
            barrier_wait_p99_ns: barrier_wait.p99_ns,
            barrier_wait_p999_ns: (barrier_wait.count > 0).then_some(barrier_wait.p999_ns),
            wire_p50_ns: wire.p50_ns,
            wire_p99_ns: wire.p99_ns,
            wire_p999_ns: (wire.count > 0).then_some(wire.p999_ns),
            ack_p50_ns: ack.p50_ns,
            ack_p99_ns: ack.p99_ns,
            ack_p999_ns: (ack.count > 0).then_some(ack.p999_ns),
            dispatch_queue_p50_ns: dispatch_queue.p50_ns,
            dispatch_queue_p99_ns: dispatch_queue.p99_ns,
            dispatch_queue_p999_ns: (dispatch_queue.count > 0).then_some(dispatch_queue.p999_ns),
            venue_task_p50_ns: venue_task.p50_ns,
            venue_task_p99_ns: venue_task.p99_ns,
            venue_task_p999_ns: (venue_task.count > 0).then_some(venue_task.p999_ns),
            core_resume_p50_ns: core_resume.p50_ns,
            core_resume_p99_ns: core_resume.p99_ns,
            core_resume_p999_ns: (core_resume.count > 0).then_some(core_resume.p999_ns),
            end_to_end_p50_ns: end_to_end.p50_ns,
            end_to_end_p99_ns: end_to_end.p99_ns,
            end_to_end_p999_ns: (end_to_end.count > 0).then_some(end_to_end.p999_ns),
        }
    }

    pub fn reset(&mut self, now_ns: u64) {
        for segment in Segment::ALL {
            self.histogram(segment).reset();
        }
        self.events = 0;
        self.window_start_ns = now_ns;
    }

    /// One line a person can read without a key.
    pub fn plain_line(&self, now_ns: u64) -> String {
        let secs = (now_ns.saturating_sub(self.window_start_ns) / 1_000_000_000).max(1);
        let mut parts = vec![format!(
            "last {}s: {} market messages, {} orders decided",
            secs,
            self.events,
            self.decisions()
        )];
        for segment in Segment::ALL {
            let q = self.quantiles(segment);
            if q.count == 0 {
                continue;
            }
            parts.push(format!(
                "{} usually {}, slow one in a hundred {}, slow one in a thousand {}",
                segment.plain_name(),
                pretty(q.p50_ns),
                pretty(q.p99_ns),
                pretty(q.p999_ns)
            ));
        }
        parts.join("; ")
    }

    fn histogram(&mut self, segment: Segment) -> &mut Histogram<u64> {
        match segment {
            Segment::Decide => &mut self.decide,
            Segment::Durable => &mut self.durable,
            Segment::BarrierWait => &mut self.barrier_wait,
            Segment::QuotaHold => &mut self.quota_hold,
            Segment::Wire => &mut self.wire,
            Segment::Ack => &mut self.ack,
            Segment::DispatchQueue => &mut self.dispatch_queue,
            Segment::VenueTask => &mut self.venue_task,
            Segment::CoreResume => &mut self.core_resume,
            Segment::EndToEnd => &mut self.end_to_end,
        }
    }
}

/// Nanoseconds in units a person reads at a glance.
pub fn pretty(ns: u64) -> String {
    if ns < 1_000 {
        format!("{ns}ns")
    } else if ns < 1_000_000 {
        format!("{:.1}us", ns as f64 / 1_000.0)
    } else if ns < 1_000_000_000 {
        format!("{:.2}ms", ns as f64 / 1_000_000.0)
    } else {
        format!("{:.2}s", ns as f64 / 1_000_000_000.0)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn quantiles_track_what_was_recorded() {
        let mut ledger = LatencyLedger::new(0);
        for ns in 1..=1000u64 {
            ledger.record(Segment::Decide, ns * 1_000);
        }
        let q = ledger.quantiles(Segment::Decide);
        assert_eq!(q.count, 1000);
        assert!(q.p50_ns > 490_000 && q.p50_ns < 510_000, "p50 {}", q.p50_ns);
        assert!(q.p99_ns > 980_000, "p99 {}", q.p99_ns);
        assert!(q.max_ns >= 1_000_000);
    }

    #[test]
    fn p999_is_measured_for_every_segment_and_written_to_the_wal() {
        let mut ledger = LatencyLedger::new(0);
        let segments = [
            (Segment::Decide, "decide"),
            (Segment::Durable, "durable"),
            (Segment::BarrierWait, "barrier_wait"),
            (Segment::Wire, "wire"),
            (Segment::Ack, "ack"),
            (Segment::DispatchQueue, "dispatch_queue"),
            (Segment::VenueTask, "venue_task"),
            (Segment::CoreResume, "core_resume"),
            (Segment::EndToEnd, "end_to_end"),
            (Segment::QuotaHold, "quota_hold"),
        ];
        for (index, (segment, _)) in segments.iter().enumerate() {
            let offset = index as u64 * 10;
            for (count, ns) in [(9_900, 100), (90, 1_000), (9, 10_000), (1, 100_000)] {
                for _ in 0..count {
                    ledger.record(*segment, ns + offset);
                }
            }
            let q = ledger.quantiles(*segment);
            assert_eq!(q.count, 10_000);
            assert_eq!(q.p99_ns, 100 + offset);
            assert_eq!(q.p999_ns, 1_000 + offset);
            assert!(q.p999_ns < q.max_ns);
        }
        let row = serde_json::to_value(ledger.record_for_wal(WINDOW_NS)).unwrap();
        for (index, (_, name)) in segments[..9].iter().enumerate() {
            assert_eq!(row[format!("{name}_p999_ns")], 1_000 + index as u64 * 10);
        }
        let line = ledger.plain_line(WINDOW_NS);
        assert_eq!(
            line.matches("slow one in a thousand").count(),
            segments.len()
        );
    }

    #[test]
    fn wal_p999_distinguishes_empty_and_measured_zero_segments() {
        let mut ledger = LatencyLedger::new(0);
        let empty = serde_json::to_value(ledger.record_for_wal(WINDOW_NS)).unwrap();
        assert!(!empty
            .as_object()
            .unwrap()
            .keys()
            .any(|key| key.ends_with("p999_ns")));
        for segment in Segment::ALL {
            ledger.record(segment, 0);
        }
        let measured = serde_json::to_value(ledger.record_for_wal(WINDOW_NS)).unwrap();
        let p999: Vec<_> = measured
            .as_object()
            .unwrap()
            .iter()
            .filter(|(key, _)| key.ends_with("p999_ns"))
            .collect();
        assert_eq!(p999.len(), 9);
        assert!(p999.iter().all(|(_, value)| value.as_u64() == Some(0)));
        ledger.reset(WINDOW_NS);
        assert_eq!(
            serde_json::to_value(ledger.record_for_wal(2 * WINDOW_NS)).unwrap(),
            empty
        );
    }

    #[test]
    fn the_window_rolls_after_a_minute_and_clears() {
        let mut ledger = LatencyLedger::new(0);
        ledger.record(Segment::Wire, 5_000);
        ledger.saw_event();
        assert!(!ledger.due(WINDOW_NS - 1));
        assert!(ledger.due(WINDOW_NS));
        match ledger.record_for_wal(WINDOW_NS) {
            WalRecord::LatencyLedger {
                window_s,
                events,
                wire_p50_ns,
                ..
            } => {
                assert_eq!(window_s, 60);
                assert_eq!(events, 1);
                assert!(wire_p50_ns > 0);
            }
            other => panic!("wrong record: {other:?}"),
        }
        ledger.reset(WINDOW_NS);
        assert_eq!(ledger.quantiles(Segment::Wire).count, 0);
        assert_eq!(ledger.events(), 0);
    }

    #[test]
    fn every_segment_starts_a_new_window_without_previous_samples() {
        let mut ledger = LatencyLedger::new(0);
        for segment in Segment::ALL {
            for ns in [1_000_000, 2_000_000, 3_000_000] {
                ledger.record(segment, ns);
            }
            assert_eq!(ledger.quantiles(segment).count, 3, "{segment:?}");
        }
        ledger.saw_event();
        ledger.reset(WINDOW_NS);
        assert_eq!(ledger.events(), 0);
        assert_eq!(ledger.decisions(), 0);
        assert!(!ledger.due(2 * WINDOW_NS - 1));
        assert!(ledger.due(2 * WINDOW_NS));

        let retained: Vec<_> = Segment::ALL
            .into_iter()
            .filter(|segment| ledger.quantiles(*segment).count != 0)
            .collect();
        assert!(
            retained.is_empty(),
            "segments retained previous samples: {retained:?}"
        );

        let mut fresh = LatencyLedger::new(WINDOW_NS);
        for segment in Segment::ALL {
            assert_eq!(
                ledger.quantiles(segment),
                Quantiles::default(),
                "{segment:?}"
            );
            for ns in [10, 20, 30] {
                ledger.record(segment, ns);
                fresh.record(segment, ns);
            }
            assert_eq!(
                ledger.quantiles(segment),
                fresh.quantiles(segment),
                "{segment:?}"
            );
        }
        assert_eq!(
            ledger.record_for_wal(2 * WINDOW_NS),
            fresh.record_for_wal(2 * WINDOW_NS)
        );
        assert_eq!(
            ledger.plain_line(2 * WINDOW_NS),
            fresh.plain_line(2 * WINDOW_NS)
        );
        ledger.reset(2 * WINDOW_NS);
        for segment in Segment::ALL {
            assert_eq!(
                ledger.quantiles(segment),
                Quantiles::default(),
                "{segment:?}"
            );
        }
    }

    #[test]
    fn plain_line_names_the_segments_in_words() {
        let mut ledger = LatencyLedger::new(0);
        ledger.saw_event();
        ledger.record(Segment::Decide, 12_000);
        ledger.record(Segment::Durable, 2_200_000);
        ledger.record(Segment::Wire, 2_400_000);
        let line = ledger.plain_line(1_000_000_000);
        assert!(line.contains("think"), "{line}");
        assert!(line.contains("write it down"), "{line}");
        assert!(line.contains("submit result"), "{line}");
        assert!(!line.contains("out the door"), "{line}");
        assert!(line.contains("2.20ms"), "{line}");
        assert!(!line.contains("p99"), "no jargon: {line}");
    }

    #[test]
    fn pretty_picks_readable_units() {
        assert_eq!(pretty(999), "999ns");
        assert_eq!(pretty(12_340), "12.3us");
        assert_eq!(pretty(2_200_000), "2.20ms");
        assert_eq!(pretty(1_500_000_000), "1.50s");
    }
}
