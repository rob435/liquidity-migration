//! Shared mechanics for the native directional sleeves.
//!
//! The directional reducers do not send orders themselves. They return this
//! small ordered effect language. The engine adapter persists each checkpoint
//! or handoff before it submits the next order effect, preserving the same
//! state-before-side-effect rule as the WAL-backed in-loop strategies.

use std::collections::{BTreeMap, BTreeSet};

use engine_types::quantize::round_clean;
use engine_types::{
    Action, InstrumentRule, Intent, OrderKind, Side, StopSpec, StrategyAccountSummary,
    StrategyCheckpoint, StrategyCtx, StrategyEvent, StrategyId, WorkPolicy,
};
use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};

use crate::position_plan::{Held, PlanRules, Skipped, Step, SymbolFacts, Target};

pub mod sleeve;

pub const DIRECTIONAL_CHECKPOINT_SCHEMA_VERSION: u16 = 1;
pub const CARRY_SLEEVE_NAME: &str = "carry";
pub const EXODUS_SLEEVE_NAME: &str = "exodus";

pub fn directional_account_is_healthy(account: StrategyAccountSummary) -> bool {
    account.observed_ns != 0
        && account.equity_usdt.is_finite()
        && account.equity_usdt > 0.0
        && account.available_margin_usdt.is_finite()
        && account.available_margin_usdt >= 0.0
}

/// Config identity copied into every signal-worker payload. The strategy
/// checks the fields that bind its own registered rule; the remaining hashes
/// keep the source artifact auditable without making operational settings a
/// durable-state identity.
#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct SignalConfigIdentity {
    pub schema_version: u32,
    pub signal_config_id: String,
    pub long_profile: String,
    pub long_execution_strategy_id: String,
    pub long_rule_sha256: String,
    pub long_feature_contract_sha256: String,
    pub signal_config_sha256: String,
    pub carry_config_id: String,
    pub carry_rule_sha256: String,
    pub carry_feature_contract_sha256: String,
    pub operational_profile_sha256: String,
    pub engine_config_sha256: String,
    pub long_decision_fingerprint: String,
    pub carry_decision_fingerprint: String,
}

#[derive(Clone, Copy, Debug, Deserialize, Eq, PartialEq, Serialize)]
#[serde(rename_all = "snake_case")]
pub enum UniverseMode {
    Current,
    Pit,
}

#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct UniverseIdentity {
    pub mode: UniverseMode,
    pub environment: String,
    pub endpoint: String,
    pub snapshot_ts_ms: i64,
    pub available_at_ms: i64,
    pub artifact_sha256: String,
    pub file_sha256: String,
    pub symbols: Vec<String>,
    pub long_symbols: Vec<String>,
    pub carry_symbols: Vec<String>,
}

/// Public ticker fields shared byte-for-byte by the Rust producer and CARRY
/// consumer. Per-field clocks prevent a fresh delta from extending the life of
/// an unrelated stale value.
#[derive(Clone, Debug, Deserialize, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct TickerObservation {
    pub symbol: String,
    pub observed_ts_ms: i64,
    pub available_at_ms: i64,
    #[serde(default)]
    pub mark_observed_ts_ms: Option<i64>,
    #[serde(default)]
    pub funding_observed_ts_ms: Option<i64>,
    #[serde(default)]
    pub schedule_observed_ts_ms: Option<i64>,
    pub last_price: Option<f64>,
    pub mark_price: Option<f64>,
    pub index_price: Option<f64>,
    pub bid1_price: Option<f64>,
    pub ask1_price: Option<f64>,
    pub bid1_size: Option<f64>,
    pub ask1_size: Option<f64>,
    pub open_interest: Option<f64>,
    pub open_interest_value: Option<f64>,
    pub turnover_24h: Option<f64>,
    pub volume_24h: Option<f64>,
    pub funding_rate: Option<f64>,
    pub next_funding_time_ms: Option<i64>,
}

pub fn validate_signal_identity(
    config: &SignalConfigIdentity,
    universe: Option<&UniverseIdentity>,
    expected_environment: &str,
) -> Result<(), &'static str> {
    if config.schema_version != 1
        || config.signal_config_id.is_empty()
        || !valid_sha256(&config.long_rule_sha256)
        || !valid_sha256(&config.long_feature_contract_sha256)
        || !valid_sha256(&config.signal_config_sha256)
        || !valid_sha256(&config.carry_rule_sha256)
        || !valid_sha256(&config.carry_feature_contract_sha256)
        || !valid_sha256(&config.operational_profile_sha256)
        || !valid_sha256(&config.engine_config_sha256)
        || !valid_sha256(&config.long_decision_fingerprint)
        || !valid_sha256(&config.carry_decision_fingerprint)
    {
        return Err("signal payload config identity is invalid");
    }
    let universe = universe.ok_or("signal payload has no universe identity")?;
    let symbols = universe.symbols.iter().collect::<BTreeSet<_>>();
    let long_symbols = universe.long_symbols.iter().collect::<BTreeSet<_>>();
    let carry_symbols = universe.carry_symbols.iter().collect::<BTreeSet<_>>();
    if universe.environment != expected_environment
        || universe.endpoint.is_empty()
        || universe.snapshot_ts_ms <= 0
        || universe.available_at_ms < universe.snapshot_ts_ms
        || !valid_sha256(&universe.artifact_sha256)
        || !valid_sha256(&universe.file_sha256)
        || universe.symbols.iter().any(|symbol| !valid_symbol(symbol))
        || universe
            .long_symbols
            .iter()
            .any(|symbol| !valid_symbol(symbol))
        || universe
            .carry_symbols
            .iter()
            .any(|symbol| !valid_symbol(symbol))
        || symbols.len() != universe.symbols.len()
        || long_symbols.len() != universe.long_symbols.len()
        || carry_symbols.len() != universe.carry_symbols.len()
        || long_symbols.iter().any(|symbol| !symbols.contains(symbol))
        || carry_symbols.iter().any(|symbol| !symbols.contains(symbol))
    {
        return Err("signal payload universe identity is invalid");
    }
    Ok(())
}

pub fn validate_exact_symbol_coverage(
    eligible: &[String],
    accepted: &[String],
    rejected: &[String],
) -> Result<(), &'static str> {
    let expected = eligible.iter().collect::<BTreeSet<_>>();
    if expected.len() != eligible.len() {
        return Err("declared eligible population contains duplicates");
    }
    let mut seen = BTreeSet::new();
    for symbol in accepted.iter().chain(rejected) {
        if !expected.contains(symbol) {
            return Err("batch symbol escapes declared eligible population");
        }
        if !seen.insert(symbol) {
            return Err("batch symbol is accepted or rejected more than once");
        }
    }
    if seen != expected {
        return Err("batch omits members of declared eligible population");
    }
    Ok(())
}

/// One target plus the leverage the position planner deliberately does
/// not carry. Native adapters join leverage back onto opening steps by symbol.
#[derive(Clone, Debug, PartialEq)]
pub struct PlannedTarget {
    pub target: Target,
    pub leverage: f64,
}

/// Complete market/account facts passed to the pure position planner.
#[derive(Clone, Debug, Default)]
pub struct PlannerFacts {
    pub held: BTreeMap<String, Held>,
    pub prices: BTreeMap<String, f64>,
    pub rules: BTreeMap<String, InstrumentRule>,
    pub foreign_owned: BTreeSet<String>,
}

impl PlannerFacts {
    pub fn held_symbols(&self) -> Vec<String> {
        self.held.keys().cloned().collect()
    }
}

impl SymbolFacts for PlannerFacts {
    fn held(&self, symbol: &str) -> Option<Held> {
        self.held.get(symbol).copied()
    }

    fn price(&self, symbol: &str) -> Option<f64> {
        self.prices.get(symbol).copied()
    }

    fn rule(&self, symbol: &str) -> Option<InstrumentRule> {
        self.rules.get(symbol).copied()
    }

    fn foreign_owned(&self, symbol: &str) -> bool {
        self.foreign_owned.contains(symbol)
    }
}

/// One exact planner step, enriched only with fields the position planner does
/// not own. `leverage` is present only for position-growing work.
#[derive(Clone, Debug, Serialize, PartialEq)]
pub struct OrderEffect {
    pub step: Step,
    pub leverage: Option<f64>,
    pub tag: &'static str,
}

/// Durable cross-sleeve event emitted by CARRY and consumed by Exodus.
#[derive(Clone, Debug, Deserialize, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct CarryPresettlementFire {
    pub event_id: String,
    pub environment: String,
    pub source_profile: String,
    pub source_config_id: String,
    pub decision_ts_ms: i64,
    pub fired_ts_ms: i64,
    pub settlement_ts_ms: i64,
    pub symbol: String,
    pub mark_px: Option<f64>,
    pub carry_side: Option<String>,
    pub carry_qty: Option<f64>,
}

/// Effects are already ordered. The adapter must not regroup them.
#[derive(Clone, Debug, Serialize, PartialEq)]
#[serde(tag = "kind", rename_all = "snake_case")]
pub enum Effect {
    PersistCheckpoint {
        symbol: String,
        config_fingerprint: String,
        payload: Vec<u8>,
    },
    AppendCarryFire(CarryPresettlementFire),
    ConsumeSignal {
        source: String,
        sequence: u64,
        observation_id: String,
    },
    ConsumeCarryFire {
        source_strategy_name: String,
        event_id: String,
    },
    ConsumeRuntimeControl {
        request_id: String,
    },
    CancelOwned {
        symbol: String,
        client_order_id: String,
    },
    Order(OrderEffect),
}

#[derive(Clone, Debug, Default, Serialize, PartialEq)]
pub struct ExecutionOutput {
    pub effects: Vec<Effect>,
    pub skipped: Vec<Skipped>,
}

pub fn order_effects(
    steps: Vec<Step>,
    targets: &[PlannedTarget],
    tag: &'static str,
) -> Vec<Effect> {
    order_effects_tagged(steps, targets, |_| tag)
}

/// `order_effects` with the log tag chosen per symbol, so an entry that came
/// through a different trigger is graded apart in the order log.
pub fn order_effects_tagged(
    steps: Vec<Step>,
    targets: &[PlannedTarget],
    tag_for: impl Fn(&str) -> &'static str,
) -> Vec<Effect> {
    let leverage_by_symbol: BTreeMap<&str, f64> = targets
        .iter()
        .map(|target| (target.target.symbol.as_str(), target.leverage))
        .collect();
    steps
        .into_iter()
        .map(|step| {
            let leverage = match &step {
                Step::Enter { symbol, .. }
                | Step::Resize {
                    symbol,
                    reduce_only: false,
                    ..
                } => leverage_by_symbol.get(symbol.as_str()).copied(),
                Step::Exit { .. }
                | Step::Resize {
                    reduce_only: true, ..
                }
                | Step::Restop { .. } => None,
            };
            let tag = tag_for(step.symbol());
            Effect::Order(OrderEffect {
                step,
                leverage,
                tag,
            })
        })
        .collect()
}

/// Stable JSON fingerprint. `serde_json::Map` is key-sorted without the
/// preserve-order feature, so the resulting bytes match canonical object-key
/// ordering and do not depend on Rust field declaration order.
pub fn config_fingerprint<T: Serialize>(config: &T) -> String {
    let value = serde_json::to_value(config).expect("directional config must serialize");
    hex_digest(&serde_json::to_vec(&value).expect("directional config JSON must serialize"))
}

pub fn checkpoint_payload<T: Serialize>(state: &T) -> Vec<u8> {
    let value = serde_json::to_value(state).expect("directional state must serialize");
    serde_json::to_vec(&value).expect("directional state JSON must serialize")
}

pub fn hex_digest(bytes: &[u8]) -> String {
    hex::encode(Sha256::digest(bytes))
}

pub fn valid_sha256(value: &str) -> bool {
    value.len() == 64
        && value
            .bytes()
            .all(|byte| byte.is_ascii_digit() || (b'a'..=b'f').contains(&byte))
}

pub fn valid_symbol(value: &str) -> bool {
    !value.is_empty()
        && value
            .bytes()
            .all(|byte| byte.is_ascii_uppercase() || byte.is_ascii_digit())
}

/// Stable identity of public feature construction. Runtime cadence, retry,
/// timeout, destination names, and account-operational settings are excluded.
pub fn signal_feature_contract_sha256(signal_json: &[u8], sleeve: &str) -> Result<String, String> {
    let value: serde_json::Value = serde_json::from_slice(signal_json)
        .map_err(|error| format!("signal config JSON: {error}"))?;
    let required = |path: &[&str]| -> Result<serde_json::Value, String> {
        let mut current = &value;
        for key in path {
            current = current
                .get(*key)
                .ok_or_else(|| format!("signal config is missing {}", path.join(".")))?;
        }
        Ok(current.clone())
    };
    let feature_physics = match sleeve {
        "long" => required(&["long", "features"]),
        "carry" => required(&["carry_feature_physics"]),
        _ => Err("signal feature sleeve must be long or carry".to_owned()),
    }?;
    let contract = serde_json::json!({
        "schema_version": required(&["schema_version"])? ,
        "kind": required(&["kind"])? ,
        "routing_source": required(&["routing", "source"])? ,
        "sources": required(&["sources"])? ,
        "public_market_realm": required(&["live", "public_market_realm"])? ,
        "sleeve": sleeve,
        "feature_physics": feature_physics,
    });
    let bytes = serde_json::to_vec(&contract).map_err(|error| error.to_string())?;
    Ok(hex_digest(&bytes))
}

pub fn signed(side: Side, qty: f64) -> f64 {
    match side {
        Side::Buy => qty,
        Side::Sell => -qty,
    }
}

/// Translate already-decided effects into the engine's action language. No
/// gate, sizing rule, or retry decision belongs here.
pub fn emit_effects(
    effects: Vec<Effect>,
    strategy: StrategyId,
    cross_event_destination: Option<&str>,
    entry_work: Option<WorkPolicy>,
    ctx: &mut dyn StrategyCtx,
) -> Result<(), &'static str> {
    for effect in effects {
        match effect {
            Effect::PersistCheckpoint {
                config_fingerprint,
                payload,
                ..
            } => ctx.emit(Action::SetStrategyGlobalCheckpoint {
                strategy,
                checkpoint: StrategyCheckpoint {
                    schema_version: DIRECTIONAL_CHECKPOINT_SCHEMA_VERSION,
                    decision_fingerprint: config_fingerprint,
                    payload,
                },
            }),
            Effect::AppendCarryFire(event) => {
                let destination_name =
                    cross_event_destination.ok_or("CARRY event destination is not configured")?;
                let destination = ctx
                    .strategy_id(destination_name)
                    .ok_or("CARRY event destination strategy is absent")?;
                let event_id = event.event_id.clone();
                let payload = checkpoint_payload(&event);
                ctx.emit(Action::PublishStrategyEvent {
                    event: StrategyEvent {
                        source: strategy,
                        destination,
                        kind: "carry_presettlement_fire".to_owned(),
                        event_id,
                        payload,
                    },
                });
            }
            Effect::ConsumeSignal {
                source,
                sequence,
                observation_id,
            } => ctx.emit(Action::ConsumeSignalObservation {
                strategy,
                source,
                sequence,
                observation_id,
            }),
            Effect::ConsumeCarryFire {
                source_strategy_name,
                event_id,
            } => {
                let source = ctx
                    .strategy_id(&source_strategy_name)
                    .ok_or("CARRY source strategy is absent")?;
                ctx.emit(Action::ConsumeStrategyEvent {
                    source,
                    destination: strategy,
                    event_id,
                });
            }
            Effect::ConsumeRuntimeControl { request_id } => {
                ctx.emit(Action::ConsumeRuntimeControl {
                    strategy,
                    request_id,
                });
            }
            Effect::CancelOwned {
                symbol,
                client_order_id,
            } => {
                let symbol = ctx
                    .symbol_id(&symbol)
                    .ok_or("native cancel symbol was not admitted")?;
                ctx.cancel(symbol, &client_order_id);
            }
            Effect::Order(order) => {
                let symbol_name = order.step.symbol();
                let symbol = ctx
                    .symbol_id(symbol_name)
                    .ok_or("native order symbol was not admitted")?;
                let decided_ns = ctx.now_ns();
                match order.step {
                    Step::Restop { stop_px, .. } => ctx.emit(Action::SetStop {
                        symbol,
                        trigger_px: stop_px,
                    }),
                    Step::Enter {
                        side, qty, stop_px, ..
                    } => ctx.place(Intent {
                        strategy,
                        symbol,
                        side,
                        qty,
                        kind: OrderKind::Market,
                        stop: Some(StopSpec {
                            trigger_px: stop_px,
                        }),
                        reduce_only: false,
                        tag: order.tag.to_owned(),
                        decided_ns,
                        work: entry_work,
                        leverage: order.leverage,
                    }),
                    Step::Exit { side, qty, .. } => ctx.place(Intent {
                        strategy,
                        symbol,
                        side,
                        qty,
                        kind: OrderKind::Market,
                        stop: None,
                        reduce_only: true,
                        tag: order.tag.to_owned(),
                        decided_ns,
                        work: None,
                        leverage: None,
                    }),
                    Step::Resize {
                        side,
                        qty,
                        reduce_only,
                        stop_px,
                        ..
                    } => ctx.place(Intent {
                        strategy,
                        symbol,
                        side,
                        qty,
                        kind: OrderKind::Market,
                        stop: stop_px.map(|trigger_px| StopSpec { trigger_px }),
                        reduce_only,
                        tag: order.tag.to_owned(),
                        decided_ns,
                        work: (!reduce_only).then_some(entry_work).flatten(),
                        leverage: (!reduce_only).then_some(order.leverage).flatten(),
                    }),
                }
            }
        }
    }
    Ok(())
}

/// Drive one sleeve to zero while its durable flatten request is pending.
/// The checkpoint always precedes cancellation, exit, and acknowledgement.
pub struct FlattenExecutionInput<'a> {
    pub config_fingerprint: String,
    pub facts: &'a PlannerFacts,
    pub owned_opening_order_ids: &'a BTreeMap<String, Vec<String>>,
    pub now_ms: i64,
    pub request_id: &'a str,
    pub tag: &'static str,
    pub conclusively_flat: bool,
}

pub fn flatten_execution<T: Serialize>(
    state: &T,
    input: FlattenExecutionInput<'_>,
) -> (ExecutionOutput, bool) {
    let flat = input.conclusively_flat && input.owned_opening_order_ids.values().all(Vec::is_empty);
    let mut effects = vec![Effect::PersistCheckpoint {
        symbol: String::new(),
        config_fingerprint: input.config_fingerprint,
        payload: checkpoint_payload(state),
    }];
    if flat {
        effects.push(Effect::ConsumeRuntimeControl {
            request_id: input.request_id.to_owned(),
        });
        return (
            ExecutionOutput {
                effects,
                skipped: Vec::new(),
            },
            true,
        );
    }
    for (symbol, order_ids) in input.owned_opening_order_ids {
        for client_order_id in order_ids {
            effects.push(Effect::CancelOwned {
                symbol: symbol.clone(),
                client_order_id: client_order_id.clone(),
            });
        }
    }
    let planned = crate::position_plan::plan(
        &[],
        &input.facts.held_symbols(),
        input.facts,
        input.now_ms,
        input.now_ms.saturating_add(1),
        PlanRules::FLEET,
    );
    effects.extend(order_effects(planned.steps, &[], input.tag));
    (
        ExecutionOutput {
            effects,
            skipped: planned.skipped,
        },
        false,
    )
}

/// Gather the target planner's exact live picture for a known symbol set.
pub fn planner_facts(ctx: &dyn StrategyCtx, symbols: &BTreeSet<String>) -> PlannerFacts {
    let mut facts = PlannerFacts::default();
    for name in symbols {
        let Some(symbol) = ctx.symbol_id(name) else {
            continue;
        };
        let quote = ctx.quote(symbol);
        let ticker = ctx.ticker(symbol);
        let mark = if quote.bid_px > 0.0 && quote.ask_px > 0.0 {
            (quote.bid_px + quote.ask_px) / 2.0
        } else if ticker.mark_px.is_finite() && ticker.mark_px > 0.0 {
            ticker.mark_px
        } else if ticker.last_px.is_finite() && ticker.last_px > 0.0 {
            ticker.last_px
        } else {
            0.0
        };
        if mark.is_finite() && mark > 0.0 {
            facts.prices.insert(name.clone(), mark);
        }
        if let Some(rule) = ctx.instrument(symbol) {
            facts.rules.insert(name.clone(), rule);
        }
        if ctx.foreign_position(symbol) {
            facts.foreign_owned.insert(name.clone());
        }
        let venue = ctx.position(symbol);
        let own = ctx.my_position_facts(symbol);
        let allocation = own.as_ref().and_then(|facts| facts.allocated.as_ref());
        let in_flight = if allocation.is_some() {
            own.as_ref()
                .map_or(0.0, |position| position.in_flight_signed_qty)
        } else {
            ctx.in_flight(symbol)
        };
        // The account reading is the account's whole holding, the owner's
        // hand trades included, so it is not what a sleeve sizes against. Its
        // own fills are; the reading only caps them, and flat at the venue is
        // the fact whatever the fills sum to.
        let signed_qty = if allocation.is_some() {
            ctx.my_position(symbol) + in_flight
        } else {
            match venue.as_ref() {
                None => in_flight,
                Some(position) => {
                    let at_venue = signed(position.side, position.qty);
                    let own = ctx.my_position(symbol) + in_flight;
                    let step = facts.rules.get(name).map_or(0.0, |rule| rule.qty_step);
                    let own = if step > 0.0 {
                        round_clean(own.abs(), step).copysign(own)
                    } else {
                        own
                    };
                    if own.abs() <= f64::EPSILON || own.signum() != at_venue.signum() {
                        0.0
                    } else if at_venue.abs() <= own.abs() {
                        at_venue
                    } else {
                        own
                    }
                }
            }
        };
        if signed_qty.abs() <= f64::EPSILON {
            continue;
        }
        let entry_px = allocation.map_or_else(
            || venue.as_ref().map_or(mark, |position| position.entry_px),
            |position| position.entry_px.unwrap_or(0.0),
        );
        let px = if mark > 0.0 { mark } else { entry_px };
        facts.held.insert(
            name.clone(),
            Held {
                qty: signed_qty.abs(),
                side: if signed_qty > 0.0 {
                    Side::Buy
                } else {
                    Side::Sell
                },
                px,
                entry_px,
                stop_px: allocation.map_or_else(
                    || venue.as_ref().map_or(0.0, |position| position.stop_px),
                    |position| position.stop_px.unwrap_or(0.0),
                ),
            },
        );
    }
    facts
}

/// Snapshot this strategy's live order ownership without leaking borrowed
/// engine rows into a reducer input.
pub fn owned_order_state(
    ctx: &dyn StrategyCtx,
) -> (BTreeSet<String>, BTreeMap<String, Vec<String>>) {
    let mut rows = Vec::new();
    ctx.resting(&mut rows);
    let mut working = BTreeSet::new();
    let mut opening = BTreeMap::<String, Vec<String>>::new();
    for row in rows {
        let Some(symbol) = ctx.symbol_name(row.symbol) else {
            continue;
        };
        working.insert(symbol.to_owned());
        if !row.reduce_only {
            opening
                .entry(symbol.to_owned())
                .or_default()
                .push(row.client_order_id.to_owned());
        }
    }
    for ids in opening.values_mut() {
        ids.sort();
        ids.dedup();
    }
    (working, opening)
}

pub fn attributed_symbols(ctx: &dyn StrategyCtx) -> BTreeSet<String> {
    let mut positions = Vec::new();
    ctx.my_positions(&mut positions);
    positions
        .into_iter()
        .filter_map(|position| ctx.symbol_name(position.symbol).map(str::to_owned))
        .collect()
}

pub fn attributed_exposure_is_flat(ctx: &dyn StrategyCtx, symbols: &BTreeSet<String>) -> bool {
    symbols.iter().all(|name| {
        let Some(symbol) = ctx.symbol_id(name) else {
            return false;
        };
        if let Some(position) = ctx
            .my_position_facts(symbol)
            .filter(|position| position.allocated.is_some())
        {
            position.attributed_signed_qty == 0.0 && position.open_order_count == 0
        } else {
            ctx.my_position(symbol).abs() <= f64::EPSILON
                && ctx.in_flight(symbol).abs() <= f64::EPSILON
        }
    })
}

/// Historical deduplication and cooldown keys do not require a live market route.
pub(crate) fn retained_market_subscriptions(
    symbols: std::collections::BTreeSet<String>,
) -> Vec<engine_types::Subscription> {
    symbols
        .into_iter()
        .flat_map(|symbol| {
            [engine_types::Feed::Quote, engine_types::Feed::Ticker].map(|feed| {
                engine_types::Subscription {
                    symbol: symbol.clone(),
                    feed,
                }
            })
        })
        .collect()
}

#[cfg(test)]
mod tests {
    use super::*;

    use crate::mock_ctx::MockCtx;

    const PEPE: &str = "1000PEPEUSDT";

    #[test]
    fn exact_allocated_quantity_below_binary64_epsilon_remains_nonflat() {
        for quantity in [1e-200, -1e-200] {
            let (mut ctx, symbols) = pepe_ctx();
            ctx.set_allocated_position(PEPE, quantity, Some(0.004), Some(0.003));
            assert!(
                !attributed_exposure_is_flat(&ctx, &symbols),
                "nonzero owned quantity was treated as flat: {quantity}"
            );
        }
    }

    #[test]
    fn exact_flat_position_with_offsetting_open_orders_remains_nonflat() {
        let (mut ctx, symbols) = pepe_ctx();
        ctx.set_allocated_position(PEPE, 0.0, None, None);
        let symbol = ctx.symbol_id(PEPE).unwrap();
        for side in [Side::Buy, Side::Sell] {
            ctx.resting.push(crate::mock_ctx::RestingSeed {
                client_order_id: format!("{side:?}"),
                symbol,
                side,
                kind: engine_types::OrderKind::Market,
                qty: 1e-200,
                filled_qty: 0.0,
                reduce_only: false,
                acked: true,
            });
        }
        assert!(!attributed_exposure_is_flat(&ctx, &symbols));
        ctx.resting.clear();
        assert!(attributed_exposure_is_flat(&ctx, &symbols));
    }

    #[test]
    fn sleeve_flatness_does_not_inherit_another_sleeves_holding() {
        let (mut ctx, symbols) = pepe_ctx();
        ctx.set_foreign_position(PEPE, Side::Buy, 100_000.0, 0.004);
        assert!(attributed_exposure_is_flat(&ctx, &symbols));
    }

    #[test]
    fn opposing_sleeve_remains_nonflat_when_venue_nets_to_zero() {
        let (mut ctx, symbols) = pepe_ctx();
        ctx.set_position(PEPE, Side::Buy, 0.0, 0.004);
        ctx.set_my_position(PEPE, -100_000.0);
        assert!(!attributed_exposure_is_flat(&ctx, &symbols));
    }

    #[test]
    fn allocated_sleeve_keeps_its_own_quantity_basis_and_stop_across_venue_net_changes() {
        for (side, net) in [
            (Side::Buy, 50_000.0),
            (Side::Sell, 50_000.0),
            (Side::Buy, 0.0),
        ] {
            let (mut ctx, symbols) = pepe_ctx();
            ctx.set_position(PEPE, side, net, 0.008);
            ctx.set_allocated_position(PEPE, -100_000.0, Some(0.004), Some(0.005));
            let held = planner_facts(&ctx, &symbols)
                .held(PEPE)
                .expect("virtual short remains held");
            assert_eq!(held.side, Side::Sell);
            assert_eq!(held.qty, 100_000.0);
            assert_eq!(held.entry_px, 0.004);
            assert_eq!(held.stop_px, 0.005);
        }
    }

    #[test]
    fn unknown_allocated_basis_is_not_borrowed_from_another_sleeve() {
        let (mut ctx, symbols) = pepe_ctx();
        ctx.set_position(PEPE, Side::Buy, 200_000.0, 0.008);
        ctx.set_allocated_position(PEPE, 100_000.0, None, Some(0.003));
        let held = planner_facts(&ctx, &symbols)
            .held(PEPE)
            .expect("quantity is known");
        assert_eq!(
            held.entry_px, 0.0,
            "legacy unknown is not the account basis"
        );
        assert_eq!(held.stop_px, 0.003);
        let plan = plan_pepe_target(&ctx, 0.0);
        assert!(matches!(
            plan.steps.as_slice(),
            [Step::Exit { qty: 100_000.0, .. }]
        ));
    }

    fn pepe_ctx() -> (MockCtx, BTreeSet<String>) {
        let mut ctx = MockCtx::new();
        ctx.add_symbol(PEPE);
        ctx.set_rule(
            PEPE,
            InstrumentRule {
                tick_size: 0.000001,
                qty_step: 100.0,
                min_qty: 100.0,
                min_notional: 5.0,
            },
        );
        (ctx, BTreeSet::from([PEPE.to_owned()]))
    }

    // 2026-08-22 08:40 UTC, funded account: the venue held 33,180,700
    // 1000PEPE, of which LONG's own fills were 222,000; the rest was the
    // owner's hand position. The planner sized against the venue's whole
    // holding and sold all of it in two reduce-only market orders.
    #[test]
    fn a_hand_position_on_top_of_the_sleeves_own_is_not_the_sleeves_to_size() {
        let (mut ctx, symbols) = pepe_ctx();
        ctx.set_position(PEPE, Side::Buy, 33_180_700.0, 0.0040);
        ctx.set_my_position(PEPE, 222_000.0);

        let held = planner_facts(&ctx, &symbols)
            .held(PEPE)
            .expect("the sleeve's own 222,000 is a holding");
        assert_eq!(held.side, Side::Buy);
        assert_eq!(
            held.qty, 222_000.0,
            "own fills, not the venue's whole position"
        );
    }

    #[test]
    fn a_position_only_the_owner_placed_is_nobodys_to_plan_against() {
        let (mut ctx, symbols) = pepe_ctx();
        ctx.set_hand_position(PEPE, Side::Buy, 33_180_700.0, 0.0040);

        let facts = planner_facts(&ctx, &symbols);
        assert!(facts.held(PEPE).is_none(), "{:?}", facts.held);
    }

    fn plan_pepe_target(ctx: &MockCtx, notional_usdt: f64) -> crate::position_plan::Plan {
        let symbols = BTreeSet::from([PEPE.to_owned()]);
        let mut facts = planner_facts(ctx, &symbols);
        facts.prices.insert(PEPE.to_owned(), 0.004);
        crate::position_plan::plan(
            &[Target {
                symbol: PEPE.to_owned(),
                notional_usdt,
                stop_loss_fraction: 0.1,
                entry_valid_until_ms: None,
                target_qty: None,
            }],
            &facts.held_symbols(),
            &facts,
            1_000,
            2_000_000,
            PlanRules::FLEET,
        )
    }

    #[test]
    fn a_foreign_position_is_not_a_flat_entry_opportunity() {
        for held_side in [Side::Buy, Side::Sell] {
            for target_sign in [1.0, -1.0] {
                let (mut ctx, _) = pepe_ctx();
                ctx.set_foreign_position(PEPE, held_side, 100_000.0, 0.004);
                let planned = plan_pepe_target(&ctx, target_sign * 40.0);
                assert!(
                    planned.steps.is_empty(),
                    "foreign {held_side:?}, target {target_sign}: {:?}",
                    planned.steps
                );
                assert!(matches!(
                    planned.skipped.as_slice(),
                    [Skipped::ForeignOwner { symbol }] if symbol == PEPE
                ));
            }
        }
    }

    #[test]
    fn a_foreign_owner_does_not_hide_our_own_reduction() {
        for held_side in [Side::Buy, Side::Sell] {
            let (mut ctx, _) = pepe_ctx();
            ctx.set_foreign_position(PEPE, held_side, 100_000.0, 0.004);
            let sign = if held_side == Side::Buy { 1.0 } else { -1.0 };
            ctx.set_my_position(PEPE, sign * 20_000.0);
            let planned = plan_pepe_target(&ctx, sign * 40.0);
            assert!(
                matches!(
                    planned.steps.as_slice(),
                    [Step::Resize { side, qty, reduce_only: true, .. }]
                        if *side == held_side.flipped() && *qty == 10_000.0
                ),
                "foreign {held_side:?}: {:?}",
                planned.steps
            );
            let exit = plan_pepe_target(&ctx, 0.0);
            assert!(matches!(
                exit.steps.as_slice(),
                [Step::Exit { side, qty, .. }]
                    if *side == held_side.flipped() && *qty == 20_000.0
            ));
        }
    }

    #[test]
    fn a_foreign_owner_blocks_growth_but_preserves_our_stop_tightening() {
        for side in [Side::Buy, Side::Sell] {
            let (mut ctx, symbols) = pepe_ctx();
            let sign = if side == Side::Buy { 1.0 } else { -1.0 };
            ctx.set_foreign_position(PEPE, side, 100_000.0, 0.004);
            ctx.set_my_position(PEPE, sign * 20_000.0);
            let mut facts = planner_facts(&ctx, &symbols);
            facts.prices.insert(PEPE.into(), 0.004);
            let held = facts.held.get_mut(PEPE).unwrap();
            held.stop_px = if side == Side::Buy { 0.003 } else { 0.005 };
            let plan = crate::position_plan::plan(
                &[Target {
                    symbol: PEPE.into(),
                    notional_usdt: sign * 160.0,
                    stop_loss_fraction: 0.1,
                    entry_valid_until_ms: None,
                    target_qty: None,
                }],
                &facts.held_symbols(),
                &facts,
                1_000,
                2_000_000,
                PlanRules::FLEET,
            );
            assert!(matches!(plan.steps.as_slice(), [Step::Restop { .. }]));
            assert!(matches!(
                plan.skipped.as_slice(),
                [Skipped::ForeignOwner { .. }]
            ));
        }
    }

    #[test]
    fn a_symbol_becomes_available_after_the_foreign_claim_ends() {
        let (mut ctx, _) = pepe_ctx();
        ctx.set_foreign_position(PEPE, Side::Buy, 100_000.0, 0.004);
        assert!(plan_pepe_target(&ctx, 40.0).steps.is_empty());
        ctx.set_position(PEPE, Side::Buy, 0.0, 0.004);
        assert!(matches!(
            plan_pepe_target(&ctx, 40.0).steps.as_slice(),
            [Step::Enter { .. }]
        ));
    }

    #[test]
    fn the_account_reading_caps_what_the_sleeve_thinks_it_holds() {
        // A hand close took part of it: the venue holds less than our fills
        // sum to. The account reading is the fact.
        let (mut ctx, symbols) = pepe_ctx();
        ctx.set_position(PEPE, Side::Buy, 200_000.0, 0.0040);
        ctx.set_my_position(PEPE, 300_000.0);

        let held = planner_facts(&ctx, &symbols).held(PEPE).expect("held");
        assert_eq!(held.qty, 200_000.0);
    }

    #[test]
    fn a_venue_position_against_the_sleeves_own_side_is_not_its_holding() {
        let (mut ctx, symbols) = pepe_ctx();
        ctx.set_position(PEPE, Side::Sell, 500_000.0, 0.0040);
        ctx.set_my_position(PEPE, 222_000.0);

        assert!(planner_facts(&ctx, &symbols).held(PEPE).is_none());
    }

    #[test]
    fn a_holding_the_log_and_the_venue_agree_on_keeps_the_venues_exact_quantity() {
        let (mut ctx, symbols) = pepe_ctx();
        ctx.set_position(PEPE, Side::Buy, 222_000.0, 0.0040);
        // Summing fills leaves float dust; shaved at the step's precision, the
        // two agree and the venue's figure is the one used.
        ctx.set_my_position(PEPE, 222_000.0 - 1e-7);

        let held = planner_facts(&ctx, &symbols).held(PEPE).expect("held");
        assert_eq!(held.qty, 222_000.0);
        assert_eq!(held.entry_px, 0.0040);
    }

    #[derive(Serialize)]
    struct Config {
        z: u8,
        a: u8,
    }

    #[test]
    fn fingerprint_is_canonical_and_lowercase() {
        let fingerprint = config_fingerprint(&Config { z: 2, a: 1 });
        assert!(valid_sha256(&fingerprint));
        assert_eq!(fingerprint, hex_digest(br#"{"a":1,"z":2}"#),);
    }

    #[test]
    fn invalid_hashes_and_symbols_fail_closed() {
        assert!(!valid_sha256(&"A".repeat(64)));
        assert!(!valid_sha256("abc"));
        assert!(valid_symbol("BTCUSDT"));
        assert!(!valid_symbol("btcUSDT"));
        assert!(!valid_symbol("BTC-USDT"));
    }

    #[test]
    fn directional_account_requires_an_observed_finite_positive_snapshot() {
        let healthy = StrategyAccountSummary {
            equity_usdt: 1_000.0,
            available_margin_usdt: 500.0,
            observed_ns: 1,
        };
        assert!(directional_account_is_healthy(healthy));
        assert!(!directional_account_is_healthy(StrategyAccountSummary {
            observed_ns: 0,
            ..healthy
        }));
        assert!(!directional_account_is_healthy(StrategyAccountSummary {
            equity_usdt: f64::NAN,
            ..healthy
        }));
        assert!(!directional_account_is_healthy(StrategyAccountSummary {
            available_margin_usdt: -1.0,
            ..healthy
        }));
    }

    #[test]
    fn feature_coverage_is_an_exact_partition_of_the_declared_population() {
        let eligible = vec!["AUSDT".to_owned(), "BUSDT".to_owned()];
        assert_eq!(
            validate_exact_symbol_coverage(&eligible, &["AUSDT".to_owned()], &["BUSDT".to_owned()]),
            Ok(())
        );
        assert_eq!(
            validate_exact_symbol_coverage(
                &eligible,
                &["AUSDT".to_owned(), "AUSDT".to_owned()],
                &["BUSDT".to_owned()]
            ),
            Err("batch symbol is accepted or rejected more than once")
        );
        assert_eq!(
            validate_exact_symbol_coverage(&eligible, &["AUSDT".to_owned()], &["AUSDT".to_owned()]),
            Err("batch symbol is accepted or rejected more than once")
        );
        assert_eq!(
            validate_exact_symbol_coverage(&eligible, &["AUSDT".to_owned()], &["CUSDT".to_owned()]),
            Err("batch symbol escapes declared eligible population")
        );
        assert_eq!(
            validate_exact_symbol_coverage(&eligible, &["AUSDT".to_owned()], &[]),
            Err("batch omits members of declared eligible population")
        );
        assert_eq!(
            validate_exact_symbol_coverage(
                &["AUSDT".to_owned(), "AUSDT".to_owned()],
                &["AUSDT".to_owned()],
                &[]
            ),
            Err("declared eligible population contains duplicates")
        );
    }

    #[test]
    fn flatten_checkpoints_before_exit_and_acknowledges_only_when_flat() {
        let mut facts = PlannerFacts::default();
        facts.held.insert(
            "BTCUSDT".into(),
            Held {
                qty: 1.0,
                side: Side::Buy,
                px: 10.0,
                entry_px: 10.0,
                stop_px: 8.0,
            },
        );
        let (active, flat) = flatten_execution(
            &serde_json::json!({"schema_version": 1}),
            FlattenExecutionInput {
                config_fingerprint: "a".repeat(64),
                facts: &facts,
                owned_opening_order_ids: &BTreeMap::new(),
                now_ms: 1,
                request_id: "flatten-1",
                tag: "test-flatten",
                conclusively_flat: false,
            },
        );
        assert!(!flat);
        assert!(matches!(
            active.effects.as_slice(),
            [
                Effect::PersistCheckpoint { .. },
                Effect::Order(OrderEffect {
                    step: Step::Exit { .. },
                    ..
                })
            ]
        ));

        let (done, flat) = flatten_execution(
            &serde_json::json!({"schema_version": 1}),
            FlattenExecutionInput {
                config_fingerprint: "a".repeat(64),
                facts: &PlannerFacts::default(),
                owned_opening_order_ids: &BTreeMap::new(),
                now_ms: 1,
                request_id: "flatten-1",
                tag: "test-flatten",
                conclusively_flat: true,
            },
        );
        assert!(flat);
        assert!(matches!(
            done.effects.as_slice(),
            [
                Effect::PersistCheckpoint { .. },
                Effect::ConsumeRuntimeControl { request_id }
            ] if request_id == "flatten-1"
        ));
    }
}
