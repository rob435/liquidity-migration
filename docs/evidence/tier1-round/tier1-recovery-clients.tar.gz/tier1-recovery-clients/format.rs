#[tokio::test]
async fn independent_account_recovery_uses_requested_ids_and_preserves_protection() {
    // This venue keeps no stop on the position row, so the account read has to
    // look at the open orders — and a position with no stop must come back
    // unprotected, which is what holds new risk back.
    let server = TestServer::start(|request, _| answer(request)).await;
    let gw = gateway(&server);
    let view = gw
        .account_recovery_client()
        .expect("independent account recovery client")
        .account_view(&["ETHUSDT".into(), "BTCUSDT".into()])
        .await
        .unwrap();
    assert_eq!(view.positions[0].symbol, SymbolId(1));
    assert_eq!(view.equity_usdt, 1500.25);
    assert_eq!(view.available_usdt, 1200.5);
    assert_eq!(view.positions.len(), 1);
    assert!(view.positions[0].stop_attached);
    assert_eq!(view.positions[0].stop_px, 93_000.0);
    assert_eq!(view.positions[0].leverage, Some(20.0));

    let bare = TestServer::start(|request, _| {
        let body: Value = request.json();
        if request.path == "/info" && body["type"] == "frontendOpenOrders" {
            return (200, "[]".to_string());
        }
        answer(request)
    })
    .await;
    let gw = gateway(&bare);
    let view = gw
        .account_recovery_client()
        .expect("independent account recovery client")
        .account_view(&["ETHUSDT".into(), "BTCUSDT".into()])
        .await
        .unwrap();
    assert_eq!(view.positions[0].symbol, SymbolId(1));
    assert!(
        !view.positions[0].stop_attached,
        "a position with no stop order read as protected"
    );
}
