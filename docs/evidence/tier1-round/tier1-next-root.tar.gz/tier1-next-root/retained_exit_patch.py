from pathlib import Path
p=Path('engine/engine-types/src/portfolio_control.rs');s=p.read_text().replace('    pub trigger_price: Exact,','    pub position_side: crate::Side,\n    pub target_remaining: Exact,\n    pub trigger_price: Option<Exact>,');p.write_text(s)
p=Path('engine/engine-core/src/portfolio_control.rs');s=p.read_text();s=s.replace('state.trigger_price != old.trigger_price || state.started_ms != old.started_ms || state.attempt < old.attempt', 'state.trigger_price != old.trigger_price || state.position_side != old.position_side || state.target_remaining > old.target_remaining || state.started_ms != old.started_ms || state.attempt < old.attempt');s=s.replace('if state.id == 0 || !state.trigger_price.is_positive()', 'if state.id == 0 || state.target_remaining.is_negative() || state.trigger_price.as_ref().is_some_and(|price| !price.is_positive())');s=s.replace('    state.trigger_price.validate_storage().map_err(|e| e.to_string())?;', '    state.target_remaining.validate_storage().map_err(|e| e.to_string())?;\n    if let Some(price) = &state.trigger_price { price.validate_storage().map_err(|e| e.to_string())?; }');p.write_text(s)
p=Path('engine/engine-core/src/engine/intent_admission.rs');s=p.read_text().replace('        let Some(approval) = self.assess_intent(intent, client_order_id)? else {', '        self.retain_portfolio_reduction(&intent)?;\n        let Some(approval) = self.assess_intent(intent, client_order_id)? else {',1);p.write_text(s)
p=Path('engine/engine-core/src/engine/portfolio_runtime.rs');s=p.read_text();s=s.replace('            if self.portfolio_controls.blocked(row.strategy, symbol) { continue; }', '            if self.portfolio_controls.emergencies.contains_key(&symbol) { continue; }');a=s.index('                let id = self.portfolio_controls.next_id()');b=s.index('\n            }',a);s=s[:a]+'''                self.request_portfolio_exit(row.strategy, symbol, if row.signed_qty.is_positive() { Side::Buy } else { Side::Sell }, Exact::zero(), Some(price))?;'''+s[b:]
a=s.index('    pub(super) fn start_portfolio_emergency');s=s[:a]+'''    pub(super) fn retain_portfolio_reduction(&mut self, intent: &Intent) -> Result<(), EngineError> {
        if !intent.reduce_only || !intent.qty.is_finite() || intent.qty <= 0.0 || !self.instrument_specs.contains_key(&intent.symbol) {
            return Ok(());
        }
        let state = self.books.attribution.snapshot();
        let Some(held) = state.positions.iter().find(|row| row.strategy == intent.strategy && row.symbol == intent.symbol) else { return Ok(()); };
        let side = if held.signed_qty.is_positive() { Side::Buy } else { Side::Sell };
        if intent.side != side.flipped() { return Ok(()); }
        let requested = engine_types::order_terms::strategy_decimal(intent.qty).map_err(|e| EngineError::State(e.to_string()))?;
        let quantity = held.signed_qty.abs();
        let target = &quantity - &requested.min(quantity.clone());
        let price = self.reference_px(intent.symbol, &OrderKind::Market).map(engine_types::order_terms::strategy_decimal)
            .transpose().map_err(|e| EngineError::State(e.to_string()))?;
        self.request_portfolio_exit(intent.strategy, intent.symbol, side, target, price)
    }

    fn request_portfolio_exit(&mut self, strategy: StrategyId, symbol: SymbolId, side: Side, target: Exact, price: Option<Exact>) -> Result<(), EngineError> {
        if self.portfolio_controls.emergencies.contains_key(&symbol) { return Ok(()); }
        let state = if let Some(old) = self.portfolio_controls.exits.get(&(strategy, symbol)) {
            if old.target_remaining <= target || old.position_side != side { return Ok(()); }
            let mut state = old.clone();
            state.target_remaining = target;
            state
        } else { PortfolioExit { id: self.portfolio_controls.next_id().map_err(EngineError::State)?,
            strategy, symbol, position_side: side, target_remaining: target, trigger_price: price,
            started_ms: clock::wall_ms(), attempt: 0, order_id: None } };
        self.append_portfolio_control(WalRecord::PortfolioExitChanged { state })
    }

'''+s[a:]
a=s.index('        let qty = self.books.attribution.signed(exit.strategy, exit.symbol);');b=s.index('        if exit.order_id.as_ref()',a)
s=s[:a]+'''        let state = self.books.attribution.snapshot();
        let held = state.positions.iter().find(|row| row.strategy == exit.strategy && row.symbol == exit.symbol);
        let remaining = held.filter(|row| row.signed_qty.is_positive() == (exit.position_side == Side::Buy))
            .map(|row| row.signed_qty.abs()).unwrap_or_else(Exact::zero);
        if remaining <= exit.target_remaining {
            return self.append_portfolio_control(WalRecord::PortfolioExitCompleted { id: exit.id, strategy: exit.strategy, symbol: exit.symbol });
        }
        let qty = (remaining - &exit.target_remaining).to_f64().map_err(|e| EngineError::State(e.to_string()))?
            * if exit.position_side == Side::Buy { 1.0 } else { -1.0 };
'''+s[b:]
s=s.replace('            self.start_portfolio_emergency(exit.symbol, exit.trigger_price, PortfolioEmergencyReason::ExitUnavailable)?;', '''            let price = exit.trigger_price.or_else(|| self.reference_px(exit.symbol, &OrderKind::Market)
                .and_then(|price| engine_types::order_terms::strategy_decimal(price).ok()));
            if let Some(price) = price { self.start_portfolio_emergency(exit.symbol, price, PortfolioEmergencyReason::ExitUnavailable)?; }''')
s=s.replace('id: 2, strategy: StrategyId(0), symbol: ready, trigger_price: Exact::parse_decimal("90").unwrap(),','id: 2, strategy: StrategyId(0), symbol: ready, position_side: Side::Buy, target_remaining: Exact::zero(), trigger_price: Some(Exact::parse_decimal("90").unwrap()),');p.write_text(s)
