from pathlib import Path
p=Path('engine/engine-types/src/orders.rs');s=p.read_text().replace('    Increase { stop: StopSpec },\n    Reduce,','    Increase { stop: StopSpec },\n    Reduce,\n    EmergencyNetReduction { emergency_id: u64 },')
s=s.replace('    pub fn is_sleeve_reduction(&self) -> bool {','    pub fn is_portfolio_reduction(&self) -> bool {\n        matches!(self.sleeve_effect, Some(SleeveOrderEffect::EmergencyNetReduction { .. }))\n    }\n\n    pub fn sleeve_owner(&self) -> Option<StrategyId> {\n        (!self.is_portfolio_reduction()).then_some(self.strategy)\n    }\n\n    pub fn is_sleeve_reduction(&self) -> bool {').replace('Some(SleeveOrderEffect::Reduce) => true,','Some(SleeveOrderEffect::Reduce | SleeveOrderEffect::EmergencyNetReduction { .. }) => true,').replace('Some(SleeveOrderEffect::Reduce) => None,','Some(SleeveOrderEffect::Reduce | SleeveOrderEffect::EmergencyNetReduction { .. }) => None,');p.write_text(s)
p=Path('engine/engine-core/src/attribution/allocated.rs');s=p.read_text().replace('    forced_close: Option<ForcedClose>,','    forced_close: Option<ForcedClose>,\n    engine_net: bool,')
for kind in ['update','recovered']:
    typ='OrderUpdate' if kind=='update' else 'WalRecord';arg='update' if kind=='update' else 'record'
    marker=f'    pub(crate) fn prepare_portfolio_{kind}(\n'
    wrappers=f'''    pub(crate) fn prepare_portfolio_{kind}_for_order(
        &self, request: Option<&engine_types::OrderRequest>, names: &[String], {arg}: &{typ},
    ) -> Result<Option<PreparedPortfolioFill>, String> {{
        self.prepare_portfolio_{kind}_authorized(request.and_then(|r| r.sleeve_owner()), names, {arg}, request.is_some_and(|r| r.is_portfolio_reduction()))
    }}

    pub(crate) fn prepare_portfolio_{kind}(
        &self, owner: Option<StrategyId>, names: &[String], {arg}: &{typ},
    ) -> Result<Option<PreparedPortfolioFill>, String> {{
        self.prepare_portfolio_{kind}_authorized(owner, names, {arg}, false)
    }}

    fn prepare_portfolio_{kind}_authorized(
'''
    s=s.replace(marker,wrappers).replace(f'        {arg}: &{typ},\n    ) -> Result<Option<PreparedPortfolioFill>, String> {{',f'        {arg}: &{typ},\n        engine_net: bool,\n    ) -> Result<Option<PreparedPortfolioFill>, String> {{',1)
s=s.replace('                forced_close: *forced_close,','                forced_close: *forced_close,\n                engine_net,').replace('let forced = execution.client_order_id.is_empty() && execution.forced_close.is_some();','let forced = execution.engine_net || (execution.client_order_id.is_empty() && execution.forced_close.is_some());')
# record folding accepts the actual parent role in addition to legacy forced owner
s=s.replace('        owner: Option<StrategyId>,\n        names: &[String],\n    ) -> Result<bool, String> {','        owner: Option<StrategyId>,\n        request: Option<&engine_types::OrderRequest>,\n        names: &[String],\n    ) -> Result<bool, String> {')
s=s.replace('self.prepare_portfolio_update(owner, names, update)?','self.prepare_portfolio_update_authorized(owner, names, update, request.is_some_and(|r| r.is_portfolio_reduction()))?').replace('self.prepare_portfolio_recovered(owner, names, record)?','self.prepare_portfolio_recovered_authorized(owner, names, record, request.is_some_and(|r| r.is_portfolio_reduction()))?')
s=s.replace('        let Some(owner) = owner else {\n            return Ok(false);','        if request.is_some_and(|r| r.is_portfolio_reduction()) {\n            return Err("engine net execution is missing its durable allocation".into());\n        }\n        let Some(owner) = owner else {\n            return Ok(false);');p.write_text(s)
p=Path('engine/engine-core/src/attribution.rs');s=p.read_text().replace('.prepare_portfolio_update(\n                                request.map(|request| request.strategy),','.prepare_portfolio_update_for_order(\n                                request,').replace('.prepare_portfolio_recovered(\n                                request.map(|request| request.strategy),','.prepare_portfolio_recovered_for_order(\n                                request,');s=s.replace('                    let strategy = request.map(|request| request.strategy).or_else(|| {','                    if request.is_some_and(|request| request.is_portfolio_reduction()) {\n                        return Err("engine net execution is missing its durable allocation".into());\n                    }\n                    let strategy = request.and_then(|request| request.sleeve_owner()).or_else(|| {');p.write_text(s)
p=Path('engine/engine-core/src/inflight.rs');s=p.read_text().replace('.map(|order| order.request.strategy)','.and_then(|order| order.request.sleeve_owner())');p.write_text(s)
p=Path('engine/engine-core/src/engine/venue_completion.rs');s=p.read_text().replace('allocation = attribution.prepare_portfolio_update(\n                        fill_owner,','allocation = attribution.prepare_portfolio_update_for_order(\n                        fill_request.as_ref(),');p.write_text(s)
p=Path('engine/engine-core/src/reconcile.rs');s=p.read_text().replace('sent.insert(request.client_order_id.clone(), request.strategy);','sent.insert(request.client_order_id.clone(), request.clone());').replace('sent.get(client_order_id).copied().or_else(|| {','sent.get(client_order_id).and_then(|request| request.sleeve_owner()).or_else(|| {').replace('claims.fold_record_fill(record, owner, &strategy_names)','claims.fold_record_fill(record, owner, sent.get(client_order_id), &strategy_names)').replace('request.map(|request| request.strategy)','request.and_then(|request| request.sleeve_owner())');p.write_text(s)
p=Path('engine/engine-core/src/ctx.rs');s=p.read_text().replace('order.request.strategy == self.strategy','order.request.sleeve_owner() == Some(self.strategy)').replace('order.request.strategy != self.strategy','order.request.sleeve_owner() != Some(self.strategy)');p.write_text(s)
p=Path('engine/engine-core/src/engine/boot_recovery/reservations.rs');s=p.read_text().replace('        registry.own(&order.request.client_order_id, order.request.strategy);','        if let Some(owner) = order.request.sleeve_owner() {\n            registry.own(&order.request.client_order_id, owner);\n        }');p.write_text(s)
