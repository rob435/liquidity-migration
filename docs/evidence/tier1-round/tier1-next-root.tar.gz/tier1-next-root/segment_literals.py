from pathlib import Path
import re
for path in Path('engine').rglob('*.rs'):
    if 'target' in path.parts:
        continue
    text=path.read_text()
    new=re.sub(r'(WalRecord::SegmentBase\s*\{\s*\n)(\s*)(wall_ts_ms:)',r'\1\2signal_producers: Vec::new(),\n\2portfolio: None,\n\2\3',text)
    if new!=text:
        path.write_text(new)
        print(path)
