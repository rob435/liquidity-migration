from pathlib import Path
p=Path('engine/engine-core/src/engine/intent_admission.rs');s=p.read_text();a=s.index('        let planned = (|| {',s.index('    fn translate_physical_order'));b=s.index('        let plan = match planned',a);old=s[a:b];s=s[:a]+'        let planned = self.physical_order_plan(&request, spec, None);\n'+s[b:]
a=s.index('    async fn confirm_order_protection(')
helper='''    pub(super) fn physical_order_plan(
        &mut self,
        request: &OrderRequest,
        spec: &engine_types::numeric::ExactInstrumentSpec,
        excluding: Option<&str>,
    ) -> Result<crate::portfolio_protection::ProtectionPlan, String> {
        let interval = match excluding {
            Some(id) => self.risk.physical_exposure_interval_excluding(id, request.symbol, &self.books.account),
            None => self.risk.physical_exposure_interval(request.symbol, &self.books.account),
        }.map_err(|reason| format!("{reason:?}"))?;
        let reference = self.reference_px(request.symbol, &OrderKind::Market)
            .or_else(|| self.reference_px(request.symbol, &request.kind)).ok_or("no reference price for physical protection")?;
        let reference = engine_types::order_terms::strategy_decimal(reference).map_err(|e| e.to_string())?;
        let mut stops = Vec::new();
        for order in self.books.orders.in_flight().into_iter().filter(|order| order.request.symbol == request.symbol
            && excluding != Some(order.request.client_order_id.as_str()) && !order.request.is_sleeve_reduction()) {
            if let Some(stop) = order.request.exact_terms.as_ref().and_then(|terms| terms.stop_trigger_price.clone()) {
                stops.push((order.request.side, stop));
            } else if let Some(stop) = order.request.sleeve_stop() {
                stops.push((order.request.side, engine_types::numeric::Exact::from_legacy_f64(stop.trigger_px).map_err(|e| e.to_string())?));
            }
        }
        for position in self.books.account.positions.iter().filter(|position| position.symbol == request.symbol && position.stop_attached) {
            stops.push((position.side, engine_types::numeric::Exact::from_legacy_f64(position.stop_px).map_err(|e| e.to_string())?));
        }
        let plan = crate::portfolio_protection::plan(&self.books.attribution.snapshot(), request, interval, spec, &reference, stops)?;
        if !plan.reduce_only {
            if !self.private_stream_ready || !self.may_open || !self.dispatches.unresolved.is_empty() {
                return Err("physical growth requires reconciled private state and resolved order outcomes".into());
            }
            if self.symbol_admission.refresh_required() || !self.symbol_admission.listed(self.books.market.table.name(request.symbol)) {
                return Err("physical growth requires a current listed instrument".into());
            }
            let quote_ns = self.books.market.quote(request.symbol).recv_ns;
            if quote_ns == 0 || clock::now_ns().saturating_sub(quote_ns) > self.max_quote_age_ns {
                return Err("physical growth requires a fresh quote".into());
            }
        }
        Ok(plan)
    }

'''
s=s[:a]+helper+s[a:];p.write_text(s)
p=Path('engine/engine-core/src/engine/order_dispatch.rs');s=p.read_text();s=s.replace('        let refusal = if !order.intent.reduce_only {','        let mut refusal = if !order.intent.reduce_only {',1);a=s.index('        if let Some(reason) = refusal {');s=s[:a]+'''        if refusal.is_none() && order.request.exact_terms.is_some() {
            let mut intent = order.intent.clone();
            intent.qty = order.request.qty;
            refusal = match self.risk.reassess_portfolio_order(id, &intent, &self.books.account, &self.books.attribution.snapshot()) {
                engine_types::risk::PortfolioRiskVerdict::Allow { qty, .. } if qty == order.request.qty => None,
                other => Some(format!("portfolio risk changed before dispatch: {other:?}")),
            };
            if refusal.is_none() {
                refusal = match self.instrument_specs.get(&intent.symbol).cloned() {
                    Some(spec) => match self.physical_order_plan(&order.request, &spec, Some(id)) {
                        Ok(plan) if plan.reduce_only == order.request.reduce_only
                            && plan.native_stop.as_ref().map(|stop| &stop.trigger_price)
                                == order.request.exact_terms.as_ref().and_then(|terms| terms.physical_stop_trigger_price.as_ref()) => None,
                        Ok(_) => Some("physical direction or aggregate protection changed before dispatch".into()),
                        Err(reason) => Some(reason),
                    },
                    None => Some("exact instrument metadata disappeared before dispatch".into()),
                };
            }
        }
'''+s[a:];p.write_text(s)
p=Path('engine/engine-core/src/tests.rs');s=p.read_text();a=s.index('    fn physical_exposure_interval(',s.index('impl RiskKernel for MockRisk'));s=s[:a]+'''    fn reassess_portfolio_order(&mut self, _id: &str, intent: &Intent, account: &AccountView, portfolio: &engine_types::portfolio::PortfolioState) -> engine_types::risk::PortfolioRiskVerdict {
        self.assess_portfolio(intent, account, portfolio)
    }
    fn physical_exposure_interval_excluding(&mut self, _id: &str, symbol: SymbolId, account: &AccountView) -> Result<engine_types::risk::PhysicalExposureInterval, DenyReason> {
        self.physical_exposure_interval(symbol, account)
    }
'''+s[a:];p.write_text(s)
