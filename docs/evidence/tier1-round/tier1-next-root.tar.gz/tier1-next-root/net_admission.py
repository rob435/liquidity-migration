from pathlib import Path
p=Path('engine/engine-core/src/engine/intent_admission.rs');s=p.read_text();marker='    fn journal_and_admit_intent(\n'
method='''    pub(super) fn emergency_order_refusal(&mut self, request: &OrderRequest, excluding: Option<&str>) -> Option<String> {
        use engine_types::orders::SleeveOrderEffect;
        use engine_types::portfolio_control::PortfolioEmergencyPhase;
        let Some(SleeveOrderEffect::EmergencyNetReduction { emergency_id }) = request.sleeve_effect else {
            return Some("order has no engine emergency owner".into());
        };
        let valid_control = self.portfolio_controls.emergencies.get(&request.symbol).is_some_and(|state|
            state.id == emergency_id && state.phase == PortfolioEmergencyPhase::CloseNet
                && state.order_id.as_deref() == Some(request.client_order_id.as_str()));
        if !valid_control { return Some("emergency order no longer belongs to the active control".into()); }
        let Some(terms) = request.exact_terms.as_ref() else { return Some("emergency order has no exact terms".into()); };
        let net = self.books.attribution.snapshot().positions.into_iter().filter(|row| row.symbol == request.symbol)
            .fold(engine_types::numeric::Exact::zero(), |sum, row| sum + row.signed_qty);
        if !request.reduce_only || request.stop.is_some() || net.is_zero()
            || net.is_positive() == (request.side == Side::Buy) || terms.quantity > net.abs() {
            return Some("emergency order exceeds the owned physical net".into());
        }
        let interval = match excluding {
            Some(id) => self.risk.physical_exposure_interval_excluding(id, request.symbol, &self.books.account),
            None => self.risk.physical_exposure_interval(request.symbol, &self.books.account),
        };
        if !interval.is_ok_and(|interval| interval.certainly_reduces(request.side, request.qty)
            && (!request.close_position || (interval.low() == interval.high() && interval.low().abs() == request.qty))) {
            return Some("emergency order no longer certainly reduces the physical position".into());
        }
        if !self.instrument_specs.contains_key(&request.symbol) { return Some("emergency instrument metadata is unavailable".into()); }
        None
    }

    pub(super) fn prepare_emergency_net_order(
        &mut self, state: &engine_types::portfolio_control::PortfolioEmergency,
    ) -> Result<Option<PreparedOrder>, EngineError> {
        use engine_types::numeric::Exact;
        use engine_types::order_terms::{quantize_order, QuantityPolicy};
        use engine_types::orders::SleeveOrderEffect;
        let Some(client_order_id) = state.order_id.clone() else { return Ok(None); };
        let rows = self.books.attribution.snapshot().positions;
        let net = rows.iter().filter(|row| row.symbol == state.symbol).fold(Exact::zero(), |sum, row| sum + &row.signed_qty);
        if net.is_zero() { return Ok(None); }
        let Some(owner) = rows.iter().filter(|row| row.symbol == state.symbol && row.signed_qty.is_positive() == net.is_positive())
            .min_by_key(|row| row.strategy).map(|row| row.strategy) else { return Ok(None); };
        let interval = match self.risk.physical_exposure_interval(state.symbol, &self.books.account) { Ok(value) => value, Err(_) => return Ok(None) };
        let side = if net.is_positive() { Side::Sell } else { Side::Buy };
        let physical = if side == Side::Sell { interval.low().max(0.0) } else { (-interval.high()).max(0.0) };
        let qty = net.abs().to_f64().map_err(|e| EngineError::State(e.to_string()))?.min(physical);
        if qty <= 0.0 { return Ok(None); }
        let Some(spec) = self.instrument_specs.get(&state.symbol) else { return Ok(None); };
        let reference = self.reference_px(state.symbol, &OrderKind::Market);
        let mut policy = QuantityPolicy::Normal;
        let mut terms = quantize_order(spec, side, qty, OrderKind::Market, None, reference, policy);
        if terms.is_err() && self.venue.caps().close_position_below_minimum
            && interval.low() == interval.high() && qty == interval.low().abs() {
            policy = QuantityPolicy::CloseEntirePosition;
            terms = quantize_order(spec, side, qty, OrderKind::Market, None, reference, policy);
        }
        let Ok(terms) = terms else { return Ok(None); };
        let mut request = OrderRequest { client_order_id: client_order_id.clone(), strategy: owner, symbol: state.symbol, side, qty,
            kind: OrderKind::Market, stop: None, reduce_only: true, close_position: policy == QuantityPolicy::CloseEntirePosition,
            exact_terms: None, sleeve_effect: Some(SleeveOrderEffect::EmergencyNetReduction { emergency_id: state.id }) };
        terms.apply_projection(&mut request).map_err(|e| EngineError::State(e.to_string()))?;
        if self.emergency_order_refusal(&request, None).is_some() { return Ok(None); }
        let decided_ns = clock::now_ns();
        let intent = Intent { strategy: owner, symbol: state.symbol, side, qty: request.qty, kind: request.kind, stop: None,
            reduce_only: true, tag: format!("portfolio-emergency:{}", state.id), decided_ns, work: None, leverage: None };
        self.wal.append(&WalRecord::Intent { intent: intent.clone() })?;
        self.wal.append(&WalRecord::Verdict { client_order_id: Some(client_order_id.clone()), verdict: RiskVerdict::Allow { qty: request.qty } })?;
        let approval = RiskApprovedIntent { allowed_qty: request.qty, intent, client_order_id, work: None };
        self.commit_prepared_order(ProtectedOrder(LegalOrder { request, approval }), decided_ns, decided_ns).map(Some)
    }

'''
assert marker in s;s=s.replace(marker,method+marker)
s=s.replace('        self.retain_portfolio_reduction(&intent)?;','        self.retain_portfolio_reduction(&intent)?;\n        if self.portfolio_controls.emergencies.contains_key(&intent.symbol) { return Ok(None); }')
s=s.replace('        self.books.registry.own(&client_order_id, intent.strategy);','        if let Some(owner) = request.sleeve_owner() {\n            self.books.registry.own(&client_order_id, owner);\n        }')
s=s.replace('        if request.is_sleeve_reduction() {\n            self.books.covers.register_reduce(','        if request.is_portfolio_reduction() {\n            // Its real fills are allocated across the contributing sleeves.\n        } else if request.is_sleeve_reduction() {\n            self.books.covers.register_reduce(');p.write_text(s)
p=Path('engine/engine-core/src/engine/portfolio_runtime.rs');s=p.read_text();start=s.index('                let portfolio = self.books.attribution.snapshot();',s.index('PortfolioEmergencyPhase::CloseNet =>'))
end=s.index('                if state.order_id.as_ref()',start);s=s[:start]+s[end:]
start=s.index('                let intent = self.portfolio_exit_intent(owner.strategy, state.symbol,');end=s.index('                    if !order.request.reduce_only',start)
s=s[:start]+'                if let Some(order) = self.prepare_emergency_net_order(&state)? {\n'+s[end:];p.write_text(s)
p=Path('engine/engine-core/src/engine/order_dispatch.rs');s=p.read_text().replace('        let mut refusal = if !order.intent.reduce_only {','        let mut refusal = if order.request.is_portfolio_reduction() {\n            self.emergency_order_refusal(&order.request, Some(id))\n        } else if !order.intent.reduce_only {').replace('if refusal.is_none() && order.request.exact_terms.is_some() {','if refusal.is_none() && order.request.exact_terms.is_some() && !order.request.is_portfolio_reduction() {');p.write_text(s)
p=Path('engine/engine-core/src/engine/boot_recovery.rs');s=p.read_text().replace('recovered_attribution.prepare_portfolio_recovered(\n                owner,','recovered_attribution.prepare_portfolio_recovered_for_order(\n                recovered_orders.orders.get(&client_order_id).map(|order| &order.request),').replace('self.books.attribution.prepare_portfolio_recovered(\n                owner,','self.books.attribution.prepare_portfolio_recovered_for_order(\n                owned_request.as_ref(),');p.write_text(s)
