use super::*;
use engine_risk::{EnvelopeConfig, Kernel, KernelConfig};
use engine_types::numeric::{AssetId, Exact, ExactInstrumentSpec, PricePrecision};

fn kernel() -> Kernel {
    Kernel::new(KernelConfig {
        max_account_view_age_ns: 120_000_000_000,
        envelope: EnvelopeConfig { tracks_equity: false, reference_usdt: 1000.0,
            equity_fraction: 1.0, floor_usdt: 100.0, expand_dead_band_fraction: 0.05,
            gross_notional_multiple: 2.0, disaster_stop_fraction: 0.35,
            max_component_gross_notional_usdt: 2000.0, max_initial_margin_usdt: 1000.0 },
        leverage: 2.0, qty_tolerance: 1e-12, max_rolling_loss_fraction: 0.1,
    }).unwrap()
}

fn spec() -> ExactInstrumentSpec {
    let d = |s| Some(Exact::parse_decimal(s).unwrap());
    ExactInstrumentSpec { native_symbol: "BTCUSDT".into(), base_asset: AssetId::Named("BTC".into()),
        quote_asset: AssetId::Named("USDT".into()), settlement_asset: AssetId::Named("USDT".into()),
        tick_size: d("0.1"), min_price: None, max_price: None, price_precision: PricePrecision::Tick,
        qty_step: d("0.1"), min_qty: d("0.1"), market_qty_step: d("0.1"), market_min_qty: d("0.1"),
        max_qty: None, max_market_qty: None, min_notional: d("5"), contract_multiplier: d("1"), fee_assets: None, fee_step: None }
}

struct Once { name: &'static str, side: Side, qty: f64, stop: Option<f64>, done: bool }
impl Strategy for Once {
    fn name(&self) -> &str { self.name }
    fn subscriptions(&self) -> Vec<Subscription> { vec![Subscription { symbol: "BTCUSDT".into(), feed: Feed::Quote }] }
    fn on_market(&mut self, event: &MarketEvent, ctx: &mut dyn StrategyCtx) {
        let MarketEvent::Quote { symbol, .. } = event else { return };
        if self.done { return; }
        self.done = true;
        ctx.place(Intent { strategy: StrategyId(0), symbol: *symbol, side: self.side, qty: self.qty,
            kind: OrderKind::Market, stop: self.stop.map(|trigger_px| StopSpec { trigger_px }), reduce_only: self.stop.is_none(),
            tag: self.name.into(), decided_ns: ctx.now_ns(), work: None, leverage: None });
    }
}
fn sleeve(name: &'static str, side: Side, stop: Option<f64>) -> Box<dyn Strategy> {
    Box::new(Once { name, side, qty: 1.0, stop, done: false })
}

fn quote() -> ScriptFeed {
    ScriptFeed { events: VecDeque::from([MarketEvent::Quote { symbol: SymbolId(0), quote: Quote {
        bid_px: 99.9, ask_px: 100.1, bid_qty: 10.0, ask_qty: 10.0, recv_ns: clock::now_ns(), ..Default::default()
    }}]), close_at_end: true, known: 1, admits_wrongly: false, admitted: Default::default() }
}

#[tokio::test]
async fn same_ticker_sleeves_keep_separate_logical_stops_and_one_native_stop() {
    let tape = tape();
    let (wal, records) = MockWal::new(tape.clone());
    let (mut venue, sends) = MockVenue::new(tape, &["BTCUSDT"]);
    venue.exact_specs = Some(vec![("BTCUSDT".into(), spec())]);
    let mut engine = Engine::boot(&settings(), "0", wal, kernel(), venue,
        vec![sleeve("left", Side::Buy, Some(90.0)), sleeve("right", Side::Buy, Some(85.0))], &[]).await.unwrap();
    engine.run(&mut quote(), &mut ScriptOrderFeed::empty(), std::future::pending::<()>()).await.unwrap();
    let sends = sends.lock().unwrap();
    assert_eq!(sends.len(), 2, "both durable sleeves must be admitted on the same ticker: {:?}", *records.lock().unwrap());
    assert_eq!(sends.iter().map(|r| r.strategy).collect::<Vec<_>>(), [StrategyId(0), StrategyId(1)]);
    assert_eq!(sends[0].sleeve_stop().unwrap().trigger_px, 90.0);
    assert_eq!(sends[1].sleeve_stop().unwrap().trigger_px, 85.0);
    assert_eq!(sends[0].stop.unwrap().trigger_px, 90.0);
    assert_eq!(sends[1].stop.unwrap().trigger_px, 90.0);
    assert!(sends.iter().all(|r| !r.reduce_only));
    for request in sends.iter() { request.exact_terms.as_ref().unwrap().validate_projection(request).unwrap(); }
}
