from pathlib import Path
p=Path('engine/engine-core/src/tests.rs');s=p.read_text().replace('mod shared_sleeves;', 'pub(crate) mod shared_sleeves;');p.write_text(s)
p=Path('engine/engine-core/src/tests/shared_sleeves.rs');s=p.read_text();
for name in ['kernel','spec','idle','owned_records','physical_long']:
 s=s.replace(f'fn {name}(',f'pub(crate) fn {name}(')
p.write_text(s)
p=Path('engine/engine-core/src/engine/order_dispatch.rs');s=p.read_text();s+='''
#[cfg(test)]
mod portfolio_tests {
    use super::*;
    use crate::tests::shared_sleeves::{kernel, spec, idle, owned_records};

    async fn fixture() -> Engine<crate::tests::MockWal, engine_risk::Kernel, crate::tests::MockVenue> {
        let tape = crate::tests::tape();
        let (wal, _) = crate::tests::MockWal::new(tape.clone());
        let (mut venue, _) = crate::tests::MockVenue::new(tape, &["BTCUSDT"]);
        venue.exact_specs = Some(vec![("BTCUSDT".into(), spec())]);
        let mut engine = Engine::boot(&crate::tests::settings(), "0", wal, kernel(), venue,
            vec![idle("left"), idle("right")], &owned_records("1", "1")).await.unwrap();
        engine.books.market.apply(&MarketEvent::Quote { symbol: SymbolId(0), quote: Quote {
            bid_px: 99.9, ask_px: 100.1, bid_qty: 10.0, ask_qty: 10.0, recv_ns: clock::now_ns(), ..Default::default()
        }});
        engine.risk.observe_price(SymbolId(0), 100.0);
        engine
    }

    async fn exit(engine: &mut Engine<crate::tests::MockWal, engine_risk::Kernel, crate::tests::MockVenue>) -> PreparedOrder {
        engine.prepare_intent(Intent { strategy: StrategyId(0), symbol: SymbolId(0), side: Side::Sell, qty: 1.0,
            kind: OrderKind::Market, stop: None, reduce_only: true, tag: "owned-exit".into(), decided_ns: clock::now_ns(), work: None, leverage: None },
            Some("eng-exit-recheck".into()), clock::now_ns(), &mut HashMap::new()).await.unwrap().unwrap()
    }

    #[tokio::test]
    async fn queued_shared_exit_rechecks_surviving_stop_and_excludes_its_own_reservation() {
        let mut engine = fixture().await;
        let order = exit(&mut engine).await;
        assert!(!order.request.reduce_only, "closing the long sleeve exposes the short sleeve");
        assert_eq!(order.request.stop.unwrap().trigger_px, 110.0);
        assert!(!engine.refuse_changed_dispatch(&order.request.client_order_id).await.unwrap(), "the unchanged order must not double count itself");
        engine.books.attribution.set_sleeve_stop_exact(StrategyId(1), SymbolId(0), Side::Sell, engine_types::numeric::Exact::parse_decimal("105").unwrap()).unwrap();
        assert!(engine.refuse_changed_dispatch(&order.request.client_order_id).await.unwrap(), "durability wait retained a weaker physical stop than the surviving sleeve owns");
    }

    #[tokio::test]
    async fn queued_virtual_exit_cannot_create_physical_growth_after_private_gap() {
        let mut engine = fixture().await;
        let order = exit(&mut engine).await;
        engine.private_stream_ready = false;
        assert!(engine.refuse_changed_dispatch(&order.request.client_order_id).await.unwrap(), "virtual reduction became unprotected physical growth during private recovery");
    }
}
''';p.write_text(s)
