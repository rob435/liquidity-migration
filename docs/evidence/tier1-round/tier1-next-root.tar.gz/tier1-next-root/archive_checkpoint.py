import gzip,hashlib,json,pathlib,re,shutil,subprocess
out=pathlib.Path('docs/evidence/tier1-foundation');out.mkdir(parents=True,exist_ok=True)
items=[]
def capture(src,group):
 src=pathlib.Path(src)
 if not src.is_file(): return
 dest=out/group/src.name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dest)
 data=dest.read_bytes();s=data.decode(errors='replace')
 if dest.suffix == '.log':
  dest.unlink();dest=dest.with_suffix('.log.gz');dest.write_bytes(gzip.compress(data,mtime=0))
 items.append({'path':str(dest),'sha256':hashlib.sha256(data).hexdigest(),'bytes_uncompressed':len(data),'sha256_archive':hashlib.sha256(dest.read_bytes()).hexdigest(),'results':re.findall(r'^test result:.*$',s,re.M),'assertions':re.findall(r"^thread .*panicked at.*$",s,re.M)})
effects=pathlib.Path('/tmp/tier1-next-effects'); manifest=json.loads((effects/'checkpoint-evidence.json').read_text())
capture(effects/'checkpoint-evidence.json','effects')
for name in manifest['sha256']: capture(effects/name,'effects')
for name in ['amend-expiry-before.log','amend-expiry-after.log','amend-expiry-before.rs']: capture(effects/name,'effects')
inputs=pathlib.Path('/tmp/tier1-next-inputs')
for folder in ['proof','proof-late','proof-routes','proof-final-routes','proof-footprint','proof-manifests-final']:
 src=inputs/folder/'manifest.json'
 if src.exists():
  dest=out/'inputs'/f'{folder}.json';dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dest)
  items.append({'path':str(dest),'sha256':hashlib.sha256(dest.read_bytes()).hexdigest()})
for stem in ['core-lifecycle','worker-lifecycle','producer-retirement','close-barrier','late-controls','market-retirement','pending-route','empty-demand','footprint','manifests-final']:
 for when in ['before','after']: capture(inputs/f'{stem}-{when}.log','inputs')
capture(inputs/'evidence.json','inputs')
venue=pathlib.Path('/tmp/tier1-next-venue')
for stem in ['underflow','provenance','inventory','lighter-pagination','lighter-decimals','lighter-scale','hl-precision','mexc-cap','bybit-error','accounting','accounting-marker','order-wire','order-integer','rounded-stop']:
 capture(venue/f'{stem}-before.log','venue')
for name in ['accounting-unit.log','accounting-integration-after.log','exact-wire-after.log','rounded-stop-after.log','exact-wire-clippy.log']:capture(venue/name,'venue')
root=pathlib.Path('/tmp/tier1-next-root')
for stem in ['attribution','pending','portfolio-risk','shared-drop','shared-fill','allocated-facts','flatness','market-lot','portfolio-projection']:
 capture(root/f'{stem}-before.log','root')
for name in ['attribution-before.rs','portfolio-risk-kernel-before.rs','shared-drop-before.rs','native-common-before.rs','pending-ctx-tests-before.rs','allocated-facts-tests-before.rs']:capture(root/name,'root')
for name in ['checkpoint-clippy.log','checkpoint-debug.log','checkpoint-linux-debug.log','checkpoint-python.log','checkpoint-linux-amend-clock.log','checkpoint-fmt.log']:capture(root/name,'integrated')
excluded={'engine/engine-types/src/identity.rs','engine/engine-core/src/identities.rs','engine/engine-core/src/identities_tests.rs'}
files=subprocess.check_output(['git','ls-files','-co','--exclude-standard','engine'],text=True).splitlines()
hashes={f:hashlib.sha256(pathlib.Path(f).read_bytes()).hexdigest() for f in sorted(set(files)-excluded) if pathlib.Path(f).is_file()}
summary={'complete':False,'scope':'Local foundation checkpoint; shared admission, physical/virtual stops, emergency settlement, stable identities and final resource/recovery integration remain open.','parent_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'compiler':'Rust 1.90.0; macOS and disposable Linux ARM64 VM','source_sha256':hashes,'evidence':items,'limitations':['Before scopes are identified mutations of evolving candidates unless the individual manifest explicitly names a historical commit.','Early proof snapshots without a retained source hash remain identified by test and mutation scope; no pristine baseline is claimed.','Release and complete developer qualification remain required after final integration.','Log artifacts are gzip compressed without changing original bytes; sha256 refers to decompressed bytes and sha256_archive to stored bytes.','Temporary VM disk exhaustion and machine-load timer failures are setup/test-harness outcomes, not production regression evidence.','No funded deployment, live venue/account validation, push, credentials or capital mutation.']}
pathlib.Path('docs/tier1-foundation-evidence.json').write_text(json.dumps(summary,indent=2)+'\n')
print(len(items),'artifacts',sum(p.stat().st_size for p in out.rglob('*') if p.is_file()),'bytes')
