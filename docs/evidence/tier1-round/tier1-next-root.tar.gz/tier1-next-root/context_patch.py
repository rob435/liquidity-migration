from pathlib import Path
p=Path('engine/engine-core/src/ctx.rs');s=p.read_text();s=s.replace('pub rules: Vec<Option<InstrumentRule>>,','pub rules: Vec<Option<InstrumentRule>>,\n    pub portfolio_symbols: BTreeSet<SymbolId>,')
s=s.replace('            rules: rules.to_vec(),','            rules: rules.to_vec(),\n            portfolio_symbols: BTreeSet::new(),').replace('            rules: Vec::new(),','            rules: Vec::new(),\n            portfolio_symbols: BTreeSet::new(),')
pos=s.index('    #[test]\n    fn a_flat_row_in_the_account_reading_is_not_a_position()')
s=s[:pos]+'''    #[test]
    fn typed_portfolio_context_distinguishes_another_sleeve_from_foreign_inventory() {
        let mut books = books_over(MarketState::default(), LedgerOfOrders::default(), OrderRegistry::default());
        books.portfolio_symbols.insert(SymbolId(0));
        books.attribution.note(StrategyId(1), SymbolId(0), Side::Buy, 1.0);
        let mut actions = VecDeque::new();
        let mut timers = Timers::default();
        let ctx = ctx_over(&books, &mut actions, &mut timers, StrategyId(0));
        assert!(!ctx.foreign_position(SymbolId(0)), "a known sleeve must not suppress another sleeve's decisions");
        assert_eq!(ctx.my_position(SymbolId(0)), 0.0);
        books.portfolio_symbols.clear();
        let ctx = ctx_over(&books, &mut actions, &mut timers, StrategyId(0));
        assert!(ctx.foreign_position(SymbolId(0)), "legacy exclusive instruments retain their ownership contract");
    }

'''+s[pos:];p.write_text(s)
p=Path('engine/engine-core/src/engine/boot_recovery.rs');s=p.read_text().replace('            books: Books {\n                market,','            books: Books {\n                portfolio_symbols: instrument_specs.keys().copied().collect(),\n                market,');p.write_text(s)
