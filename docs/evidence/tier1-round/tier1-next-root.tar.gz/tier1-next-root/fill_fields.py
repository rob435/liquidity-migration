import json, hashlib
from pathlib import Path
changes={}
hashes=json.loads(Path("/tmp/tier1-next-root/check-source-hashes.json").read_text())
for line in Path('/tmp/tier1-next-root/check.jsonl').read_text().splitlines():
 try: data=json.loads(line)
 except ValueError: continue
 if data.get('reason')!='compiler-message': continue
 m=data['message']
 if not m['message'].startswith('missing field `amounts`'): continue
 for span in m['spans']:
  if not span['is_primary']: continue
  path=Path('engine')/span['file_name']
  if 'engine-venue' in path.parts: continue
  changes.setdefault(path,set()).add(span['line_start'])
for path,numbers in changes.items():
 if hashes.get(str(path)) != hashlib.sha256(path.read_bytes()).hexdigest():
  print("skip changed",path)
  continue
 lines=path.read_text().splitlines(True)
 for number in sorted(numbers,reverse=True):
  index=number-1
  if any('amounts:' in row for row in lines[index+1:index+5]): continue
  assert '{' in lines[index], (path,number)
  indent=lines[index][:len(lines[index])-len(lines[index].lstrip())]+'    '
  lines.insert(index+1, indent+'amounts: None,\n')
 path.write_text(''.join(lines))
 print(path)
