use std::fs::File;
use std::io::{self, BufReader, Read};
use std::os::unix::fs::FileExt;

use engine_types::strategy_process::{CallbackWalCursor, CallbackWalReader, CallbackWalRecord};
use engine_types::{OrderUpdate, StrategyId};

use crate::{WalError, FRAME_HEADER_LEN, HEADER_LEN};

pub(crate) struct Reader {
    pub file: File,
    pub segment: u64,
}

struct Window<'a> {
    file: &'a File,
    offset: u64,
    left: u64,
    crc: u32,
}

impl Read for Window<'_> {
    fn read(&mut self, bytes: &mut [u8]) -> io::Result<usize> {
        let count = bytes.len().min(self.left as usize);
        if count == 0 { return Ok(0); }
        let read = self.file.read_at(&mut bytes[..count], self.offset)?;
        if read == 0 { return Err(io::Error::new(io::ErrorKind::UnexpectedEof, "callback WAL frame is incomplete")); }
        self.crc = crc32c::crc32c_append(self.crc, &bytes[..read]);
        self.offset += read as u64;
        self.left -= read as u64;
        Ok(read)
    }
}

#[derive(serde::Deserialize)]
struct Envelope {
    kind: String,
    callbacks: Option<Vec<StrategyId>>,
    update: Option<serde_json::Value>,
    strategy: Option<StrategyId>,
    event: Option<engine_types::strategy_process::CallbackEvent>,
}

impl CallbackWalReader for Reader {
    fn start(&self) -> CallbackWalCursor {
        CallbackWalCursor { segment: self.segment, sequence: 1, offset: HEADER_LEN }
    }

    fn next(&mut self, cursor: CallbackWalCursor) -> Result<Option<CallbackWalRecord>, WalError> {
        let corrupt = |detail: &str| WalError::Corrupt { offset: cursor.offset, detail: detail.into() };
        if cursor.segment != self.segment || cursor.offset < HEADER_LEN || cursor.sequence == 0 {
            return Err(corrupt("callback cursor belongs to another WAL segment"));
        }
        let length = self.file.metadata()?.len();
        if cursor.offset == length { return Ok(None); }
        if cursor.offset > length || length - cursor.offset < FRAME_HEADER_LEN as u64 {
            return Err(corrupt("callback cursor is outside a complete WAL frame"));
        }
        let mut header = [0; FRAME_HEADER_LEN];
        self.file.read_exact_at(&mut header, cursor.offset)?;
        let payload_len = u32::from_le_bytes(header[..4].try_into().expect("four-byte length")) as u64;
        let expected_crc = u32::from_le_bytes(header[4..].try_into().expect("four-byte checksum"));
        if payload_len == 0 || length - cursor.offset - (FRAME_HEADER_LEN as u64) < payload_len {
            return Err(corrupt("callback WAL source frame is incomplete"));
        }
        let window = Window { file: &self.file, offset: cursor.offset + FRAME_HEADER_LEN as u64, left: payload_len, crc: 0 };
        let mut reader = BufReader::with_capacity(64 * 1024, window);
        let envelope: Envelope = serde_json::from_reader(&mut reader).map_err(crate::json_error)?;
        let consumed = reader.into_inner();
        if consumed.left != 0 || consumed.crc != expected_crc {
            return Err(corrupt("callback WAL source checksum does not match"));
        }
        let source = if envelope.kind == "order_update_v2" {
            let owners = envelope.callbacks.ok_or_else(|| corrupt("order callback source has no owner metadata"))?;
            let mut update = envelope.update.ok_or_else(|| corrupt("order callback source has no parent update"))?;
            if let Some(fill) = update.get_mut("Fill").and_then(serde_json::Value::as_object_mut) {
                if fill.get("fee_known") == Some(&serde_json::Value::Bool(false)) {
                    fill.insert("fee".into(), serde_json::Value::Null);
                }
            }
            let update: OrderUpdate = serde_json::from_value(update).map_err(crate::json_error)?;
            Some((owners, engine_types::strategy_process::CallbackEvent::Order { update }))
        } else if envelope.kind == "strategy_callback_source" {
            Some((vec![envelope.strategy.ok_or_else(|| corrupt("callback source has no owner"))?], envelope.event.ok_or_else(|| corrupt("callback source has no event"))?))
        } else { None };
        Ok(Some(CallbackWalRecord { next: CallbackWalCursor {
            segment: cursor.segment,
            sequence: cursor.sequence.checked_add(1).ok_or_else(|| corrupt("callback source sequence exhausted"))?,
            offset: consumed.offset,
        }, source }))
    }
}
