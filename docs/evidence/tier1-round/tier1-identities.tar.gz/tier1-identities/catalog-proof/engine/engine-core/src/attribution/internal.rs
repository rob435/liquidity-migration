use super::*;
use std::collections::BTreeMap;
use engine_types::numeric::{AssetId, Exact};
use engine_types::portfolio_control::{InternalSettlementTotals, PortfolioOffsetSettlement};

type Key = (StrategyId, SymbolId, AssetId);
#[derive(Debug, Default)]
pub(super) struct InternalAccounting(BTreeMap<Key, InternalSettlementTotals>);

pub(crate) struct PreparedInternalSettlement {
    inventory: crate::inventory::InventoryBatchChange,
    totals: Vec<(Key, Option<InternalSettlementTotals>, InternalSettlementTotals)>,
}
impl InternalAccounting {
    pub(super) fn restore(rows: &[InternalSettlementTotals]) -> Result<Self, String> {
        let mut out = Self::default();
        for row in rows {
            row.cash_flow.validate_storage().map_err(|e| e.to_string())?;
            row.realized_gross.validate_storage().map_err(|e| e.to_string())?;
            if matches!(&row.asset, AssetId::Named(asset) if asset.is_empty()) { return Err("invalid internal settlement asset".into()); }
            let key = (row.strategy, row.symbol, row.asset.clone());
            if out.0.insert(key, row.clone()).is_some() { return Err("duplicate internal settlement total".into()); }
        }
        Ok(out)
    }
    pub(super) fn snapshot(&self) -> Vec<InternalSettlementTotals> { self.0.values().cloned().collect() }
}

impl Attribution {
    pub(crate) fn prepare_internal_settlement(&self, settlement: &PortfolioOffsetSettlement) -> Result<PreparedInternalSettlement, String> {
        crate::portfolio_control::validate_settlement(settlement)?;
        let holdings: Vec<_> = self.inventory.rows().filter(|row| row.symbol == settlement.symbol).collect();
        if holdings.len() != settlement.slices.len() { return Err("internal settlement must close every remaining sleeve on the symbol".into()); }
        let mut fills = Vec::new();
        for slice in &settlement.slices {
            let held = self.inventory.position(slice.strategy, settlement.symbol).ok_or("internal settlement names an unowned position")?;
            if &held.signed_qty + &slice.signed_quantity != Exact::zero()
                || (held.settlement_asset != AssetId::Unknown && held.settlement_asset != slice.settlement_asset) {
                return Err("internal settlement disagrees with durable inventory or asset".into());
            }
            fills.push(crate::inventory::InventoryFill { strategy: slice.strategy, symbol: settlement.symbol,
                side: if slice.signed_quantity.is_positive() { Side::Buy } else { Side::Sell },
                qty: slice.signed_quantity.abs(), px: Some(settlement.price.clone()), stop: None,
                settlement_asset: slice.settlement_asset.clone() });
        }
        let inventory = self.inventory.prepare_batch(fills)?;
        let mut totals = Vec::new();
        for (slice, (_, _, realized)) in settlement.slices.iter().zip(&inventory.realized) {
            let key = (slice.strategy, settlement.symbol, slice.settlement_asset.clone());
            let prior = self.internal.0.get(&key).cloned();
            let mut next = prior.clone().unwrap_or(InternalSettlementTotals { strategy: slice.strategy, symbol: settlement.symbol,
                asset: slice.settlement_asset.clone(), cash_flow: Exact::zero(), realized_gross: Exact::zero(), unvalued_realized_events: 0 });
            next.cash_flow -= &slice.signed_quantity * &settlement.price;
            match &realized.amount {
                Some(value) if realized.asset == slice.settlement_asset => next.realized_gross += value,
                Some(value) if value.is_zero() => (),
                _ => next.unvalued_realized_events = next.unvalued_realized_events.checked_add(1).ok_or("internal settlement uncertainty count exhausted")?,
            }
            next.cash_flow.validate_storage().map_err(|e| e.to_string())?;
            next.realized_gross.validate_storage().map_err(|e| e.to_string())?;
            totals.push((key, prior, next));
        }
        Ok(PreparedInternalSettlement { inventory, totals })
    }
    pub(crate) fn commit_internal_settlement(&mut self, prepared: PreparedInternalSettlement) -> Result<(), String> {
        self.inventory.validate_batch(&prepared.inventory)?;
        if prepared.totals.iter().any(|(key, prior, _)| self.internal.0.get(key) != prior.as_ref()) { return Err("internal settlement was prepared against different totals".into()); }
        self.inventory.apply_batch(prepared.inventory)?;
        for (key, _, next) in prepared.totals { self.internal.0.insert(key, next); }
        Ok(())
    }
    pub(crate) fn set_sleeve_stop_exact(&mut self, strategy: StrategyId, symbol: SymbolId, side: Side, trigger: Exact) -> Result<(), String> {
        trigger.validate_storage().map_err(|e| e.to_string())?;
        if !trigger.is_positive() { return Err("sleeve stop is not positive".into()); }
        let held = self.inventory.position(strategy, symbol).ok_or("sleeve stop has no owned position")?;
        if held.signed_qty.is_positive() != (side == Side::Buy) { return Err("sleeve stop has the wrong position direction".into()); }
        self.inventory.tighten_stop(strategy, symbol, side, trigger);
        Ok(())
    }
}
