from pathlib import Path
r=Path('/Users/jhbvdnsbkvnsd/Desktop/liquidity-migration/engine')
p=r/'engine-types/src/orders.rs';s=p.read_text().replace('pub struct InstrumentCatalog {','pub struct InstrumentCatalog {\n    pub cache: Option<std::sync::Arc<dyn InstrumentCatalogCache>>,');s+='''
pub trait InstrumentCatalogCache: std::any::Any + Send + Sync + std::fmt::Debug {
    fn as_any(&self) -> &dyn std::any::Any;
}
impl<T: std::any::Any + Send + Sync + std::fmt::Debug> InstrumentCatalogCache for T {
    fn as_any(&self) -> &dyn std::any::Any { self }
}
''';p.write_text(s)
p=r/'engine-types/src/lib.rs';s=p.read_text();pos=s.index('    fn instrument_catalog_client(');s=s[:pos]+'''    fn install_instrument_catalog(&mut self, _catalog: &crate::orders::InstrumentCatalog) -> Result<(), VenueError> {
        Err(VenueError::Unsupported("instrument catalog installation is unavailable".into()))
    }
'''+s[pos:];p.write_text(s)
for venue,cachetype,assign,origin in [
 ('bybit','()','', 'self.rest.base()'),
 ('binance','HashMap<String, MarketQtyRule>','self.market_qty_rules = snapshot.data.clone();','self.rest.base()'),
 ('mexc','Contracts','self.contracts = snapshot.data.clone();','self.rest.base()'),
 ('lighter','Markets','self.markets = snapshot.data.clone();','self.http.base()'),
 ('hyperliquid','Assets','self.assets = snapshot.data.clone();','self.http.base()')]:
 p=r/f'engine-venue/src/venues/{venue}/gateway.rs';s=p.read_text();pos=s.index('    fn instrument_catalog_client(');method=f'''    fn install_instrument_catalog(&mut self, catalog: &engine_types::orders::InstrumentCatalog) -> Result<(), VenueError> {{
        let snapshot = catalog.cache.as_ref().and_then(|cache| cache.as_ref().as_any().downcast_ref::<CatalogSnapshot>())
            .ok_or_else(|| VenueError::BadRequest("catalog belongs to another adapter".into()))?;
        if snapshot.base != {origin} {{ return Err(VenueError::BadRequest("catalog belongs to another venue endpoint".into())); }}
        {assign}
        Ok(())
    }}

''';s=s[:pos]+method+s[pos:];pos=s.index('#[engine_types::async_trait]\nimpl engine_types::orders::InstrumentCatalogClient');s=s[:pos]+f'''#[derive(Debug)]
struct CatalogSnapshot {{ base: String, data: {cachetype} }}

'''+s[pos:]
 if venue=='bybit':
  s=s.replace('if next.is_empty() { return Ok(out); }','if next.is_empty() { out.cache = Some(std::sync::Arc::new(CatalogSnapshot { base: self.rest.base().to_owned(), data: () })); return Ok(out); }')
 elif venue=='binance':
  s=s.replace('let rules = parse_exchange_info(&value)?.instruments;\n        Ok(engine_types::orders::InstrumentCatalog { rules, specs })','let parsed = parse_exchange_info(&value)?;\n        Ok(engine_types::orders::InstrumentCatalog { rules: parsed.instruments, specs, cache: Some(std::sync::Arc::new(CatalogSnapshot { base: self.rest.base().to_owned(), data: parsed.market_qty })) })')
 elif venue=='mexc':
  s=s.replace('engine_types::orders::InstrumentCatalog { rules: catalog.rules(), specs: catalog.instrument_specs() }','engine_types::orders::InstrumentCatalog { rules: catalog.rules(), specs: catalog.instrument_specs(), cache: Some(std::sync::Arc::new(CatalogSnapshot { base: self.rest.base().to_owned(), data: catalog })) }')
 else:
  s=s.replace('engine_types::orders::InstrumentCatalog { rules: catalog.instrument_rules(), specs: catalog.instrument_specs()? }','engine_types::orders::InstrumentCatalog { rules: catalog.instrument_rules(), specs: catalog.instrument_specs()?, cache: Some(std::sync::Arc::new(CatalogSnapshot { base: self.http.base().to_owned(), data: catalog })) }')
 p.write_text(s)
p=r/'engine-venue/src/registry.rs';s=p.read_text();pos=s.index('    fn instrument_catalog_client(');s=s[:pos]+'''    fn install_instrument_catalog(&mut self, catalog: &engine_types::orders::InstrumentCatalog) -> Result<(), VenueError> {
        match self {
            Venue::Bybit(gw) => gw.install_instrument_catalog(catalog),
            Venue::Hyperliquid(gw) => gw.install_instrument_catalog(catalog),
            Venue::Lighter(gw) => gw.install_instrument_catalog(catalog),
            Venue::Mexc(gw) => gw.install_instrument_catalog(catalog),
            Venue::Binance(gw) => gw.install_instrument_catalog(catalog),
            Venue::Variational(gw) => gw.install_instrument_catalog(catalog),
        }
    }

'''+s[pos:];p.write_text(s)
