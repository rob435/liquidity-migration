from pathlib import Path
r=Path('/Users/jhbvdnsbkvnsd/Desktop/liquidity-migration/engine')
p=r/'engine-types/src/orders.rs';s=p.read_text();s+='''
#[derive(Clone, Debug, Default)]
pub struct InstrumentCatalog {
    pub rules: Vec<(crate::Symbol, crate::InstrumentRule)>,
    pub specs: Vec<(crate::Symbol, crate::numeric::ExactInstrumentSpec)>,
}
#[crate::async_trait]
pub trait InstrumentCatalogClient: Send + Sync + 'static {
    async fn fetch(&self) -> Result<InstrumentCatalog, VenueError>;
}
''';p.write_text(s)
p=r/'engine-types/src/lib.rs';s=p.read_text();pos=s.index('    fn order_lookup_client(');s=s[:pos]+'''    fn instrument_catalog_client(&self) -> Option<Box<dyn crate::orders::InstrumentCatalogClient>> { None }
'''+s[pos:];p.write_text(s)
methods={
'bybit':'''        let mut out = engine_types::orders::InstrumentCatalog::default();
        let mut cursor = String::new();
        for _ in 0..MAX_PAGES {
            let query = if cursor.is_empty() { format!("category={CATEGORY}&limit=1000") } else { format!("category={CATEGORY}&limit=1000&cursor={}", percent_encode(&cursor)) };
            let raw: Box<serde_json::value::RawValue> = self.rest.get_public_as(PATH_INSTRUMENTS, &query).await?;
            let (specs, next) = engine_public::venues::bybit::spec::parse_page(raw.get())?;
            let envelope: Value = serde_json::from_str(raw.get()).map_err(|e| VenueError::BadReply(e.to_string()))?;
            let (rules, legacy_next) = parse_instruments(&venue_result(envelope)?)?;
            if next != legacy_next { return Err(VenueError::BadReply("catalog parsers disagree on cursor".into())); }
            out.specs.extend(specs); out.rules.extend(rules);
            if next.is_empty() { return Ok(out); }
            cursor = next;
        }
        Err(VenueError::BadReply(format!("instrument listing still had pages after {MAX_PAGES}")))''',
'binance':'''        let _reservation = self.budget.reserve(WEIGHT_EXCHANGE_INFO).await;
        let raw: Box<serde_json::value::RawValue> = self.rest.get_public_as(PATH_EXCHANGE_INFO, "").await?;
        let specs = engine_public::venues::binance::spec::parse(raw.get())?;
        let value: Value = serde_json::from_str(raw.get()).map_err(|e| VenueError::BadReply(e.to_string()))?;
        let rules = parse_exchange_info(&value)?.instruments;
        Ok(engine_types::orders::InstrumentCatalog { rules, specs })''',
'mexc':'''        let raw: Box<serde_json::value::RawValue> = self.rest.get_public_as(PATH_CONTRACT_DETAIL, "").await?;
        let catalog = Contracts::parse_raw(raw.get())?;
        Ok(engine_types::orders::InstrumentCatalog { rules: catalog.rules(), specs: catalog.instrument_specs() })''',
'lighter':'''        let raw: Box<serde_json::value::RawValue> = self.http.get_as(PATH_MARKETS, "", &[]).await?;
        let catalog = Markets::from_rows(engine_public::venues::lighter::parse::parse_markets_raw(raw.get())?);
        Ok(engine_types::orders::InstrumentCatalog { rules: catalog.instrument_rules(), specs: catalog.instrument_specs()? })''',
'hyperliquid':'''        let raw: Box<serde_json::value::RawValue> = self.http.post_as(PATH_INFO, r#"{"type":"meta"}"#, "application/json", &[]).await?;
        let catalog = Assets::from_rows(parse_meta_raw(raw.get())?);
        Ok(engine_types::orders::InstrumentCatalog { rules: catalog.instrument_rules(), specs: catalog.instrument_specs()? })''',
}
for venue,body in methods.items():
 p=r/f'engine-venue/src/venues/{venue}/gateway.rs';s=p.read_text();start=s.index('    fn order_lookup_client(');i=s.index('\n    }',start)+6;method=s[start:i].replace('fn order_lookup_client','fn instrument_catalog_client').replace('engine_types::orders::OrderLookupClient','engine_types::orders::InstrumentCatalogClient');s=s[:start]+method+'\n\n'+s[start:];pos=s.index('struct LookupClient');s=s[:pos]+f'''#[engine_types::async_trait]
impl engine_types::orders::InstrumentCatalogClient for LookupClient {{
    async fn fetch(&self) -> Result<engine_types::orders::InstrumentCatalog, VenueError> {{
{body}
    }}
}}

'''+s[pos:];p.write_text(s)
p=r/'engine-venue/src/registry.rs';s=p.read_text();start=s.index('    fn order_lookup_client(');i=s.index('\n    }',start)+6;method=s[start:i].replace('fn order_lookup_client','fn instrument_catalog_client').replace('engine_types::orders::OrderLookupClient','engine_types::orders::InstrumentCatalogClient').replace('.order_lookup_client()', '.instrument_catalog_client()');s=s[:start]+method+'\n\n'+s[start:];p.write_text(s)
