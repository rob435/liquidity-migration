from pathlib import Path
r=Path('/tmp/tier1-next-venue/risk-work')
p=r/'engine-risk/src/lib.rs';s=p.read_text().replace('mod loss_window;','mod loss_window;\nmod margin;');p.write_text(s)
p=r/'engine-risk/src/kernel.rs';s=p.read_text().replace('use crate::loss_window::LossWindow;','use crate::loss_window::LossWindow;\nuse crate::margin::MarginBook;').replace('    loss_window: LossWindow,','    loss_window: LossWindow,\n    margin: MarginBook,').replace('            loss_window: LossWindow::default(),','            loss_window: LossWindow::default(),\n            margin: MarginBook::default(),')
s=s.replace('    pub fn capital_reference_usdt(&self)', '''    pub fn register_order_with_account(&mut self, id: &str, intent: &Intent, qty: f64, account: &AccountView) {
        let quantity = if intent.reduce_only {
            ViewFacts::read(account, 0.0).ok().and_then(|view| {
                let physical = view.net_qty(intent.symbol) + self.book.fills_after(account.observed_ns)
                    .get(&intent.symbol.0).map_or(0.0, |row| row.signed_qty);
                self.incremental_physical_quantity(intent, qty, physical).ok()
            })
        } else { Some(qty) };
        self.register_order(id, intent, qty);
        self.margin.set_quantity(id, quantity);
    }

    pub fn mark_order_attempted(&mut self, id: &str) { self.margin.attempted(id); }

    pub fn mark_order_accepted(&mut self, id: &str, confirmed_ns: u64) { self.margin.accepted(id, confirmed_ns); }

    pub fn capital_reference_usdt(&self)''')
s=s.replace('        self.book.register(\n            client_order_id,','        self.margin.register(client_order_id, intent.symbol, Some(approved_qty), px);\n        self.book.register(\n            client_order_id,',1)
s=s.replace('''        // Available margin is what is left AFTER the standing book's margin is
        // deducted, so only the increase is new money — charging the whole book
        // against it would count the standing book twice. This order is the
        // whole increase, because nothing above nets it against the book.
        let additional_margin_usdt = notional / leverage;''','''        let additional_margin_usdt = notional / leverage + self.unreflected_margin(view)?;
        if !additional_margin_usdt.is_finite() { return Err(unknown("required margin is unreadable")); }''')
s=s.replace('    /// The lowest and highest price this order could reasonably fill at,', '''    fn unreflected_margin(&self, view: &ViewFacts) -> Result<f64, DenyReason> {
        self.margin.required(view.observed_ns, self.cfg.leverage, |symbol| self.price_for(symbol, view)).map_err(unknown)
    }

    /// The lowest and highest price this order could reasonably fill at,''')
s=s.replace('''        // Judge the replacement, not old+replacement.''','''        let previous_margin = self.margin.take(client_order_id);
        // Judge the replacement, not old+replacement.''')
s=s.replace('''        self.book.register(client_order_id, previous);
        verdict''','''        self.book.register(client_order_id, previous);
        self.margin.restore(client_order_id, previous_margin);
        verdict''')
s=s.replace('''                self.book
                    .on_fill(client_order_id, *symbol, signed(*side, qty.abs()), *recv_ns);
            }
            OrderUpdate::Cancelled {
                client_order_id, ..
            } => self.book.forget(client_order_id),
            OrderUpdate::Reject {
                client_order_id, ..
            } => self.book.forget(client_order_id),
            OrderUpdate::Ack(_)
            | OrderUpdate::FastFill { .. }''','''                self.book
                    .on_fill(client_order_id, *symbol, signed(*side, qty.abs()), *recv_ns);
                if self.book.contains(client_order_id) { self.margin.accepted(client_order_id, *recv_ns); }
                else { self.margin.retire(client_order_id, *recv_ns); }
            }
            OrderUpdate::Cancelled { client_order_id, recv_ns } => {
                self.book.forget(client_order_id);
                self.margin.retire(client_order_id, *recv_ns);
            }
            OrderUpdate::Reject { client_order_id, .. } => {
                self.book.forget(client_order_id);
                self.margin.retire(client_order_id, engine_types::clock::mono_ns());
            }
            OrderUpdate::Ack(ack) => self.margin.accepted(&ack.client_order_id, ack.ack_ns),
            OrderUpdate::FastFill { .. }''')
s=s.replace('''        self.book.prune_through(account.observed_ns);''','''        if ViewFacts::read(account, 0.0).is_ok() { self.margin.observe(account.observed_ns); }
        self.book.prune_through(account.observed_ns);''')
pos=s.index('    fn register_order_price_range(\n',s.index('impl RiskKernel for Kernel'))
s=s[:pos]+'''    fn register_order_with_account(&mut self, id: &str, intent: &Intent, qty: f64, account: &AccountView) {
        Kernel::register_order_with_account(self, id, intent, qty, account);
    }
    fn mark_order_attempted(&mut self, id: &str) { Kernel::mark_order_attempted(self, id); }
    fn mark_order_accepted(&mut self, id: &str, ns: u64) { Kernel::mark_order_accepted(self, id, ns); }

'''+s[pos:]
s=s.replace('struct ViewFacts {\n','struct ViewFacts {\n    observed_ns: u64,\n')
# inspect initialization uses below before target replacement
s=s.replace('''        Ok(Self {
            equity_usdt: account.equity_usdt,''','''        Ok(Self {
            observed_ns: account.observed_ns,
            equity_usdt: account.equity_usdt,''')
p.write_text(s)
p=r/'engine-risk/src/exposure.rs';s=p.read_text().replace('    pub(crate) fn forget(&mut self, client_order_id: &str) {','    pub(crate) fn contains(&self, id: &str) -> bool { self.pending.contains_key(id) }\n\n    pub(crate) fn forget(&mut self, client_order_id: &str) {');p.write_text(s)
p=r/'engine-risk/src/kernel/portfolio.rs';s=p.read_text();start=s.index('        let endpoint = if delta < 0.0');end=s.index('        if additional_margin_usdt > view.available_usdt',start)
s=s[:start]+'''        let additional_margin_usdt = self.incremental_physical_quantity(intent, qty, physical_qty)? * price / self.cfg.leverage + self.unreflected_margin(view)?;
        if !additional_margin_usdt.is_finite() { return Err(unknown("portfolio reduction produces unreadable margin")); }
'''+s[end:]
pos=s.index('    pub(super) fn check_virtual_reduction')
s=s[:pos]+'''    pub(super) fn incremental_physical_quantity(&self, intent: &Intent, qty: f64, physical_qty: f64) -> Result<f64, DenyReason> {
        let delta = signed(intent.side, qty);
        let (low, high) = self.book.physical_interval(intent.symbol, physical_qty);
        if !qty.is_finite() || qty <= 0.0 || !low.is_finite() || !high.is_finite() {
            return Err(unknown("unreadable physical margin reservation"));
        }
        let endpoint = if delta < 0.0 { low } else { high };
        // Maximize this order's increase over all earlier pending fill orderings.
        Ok(if endpoint == 0.0 || endpoint.is_sign_positive() == delta.is_sign_positive() {
            delta.abs()
        } else if endpoint.abs() >= delta.abs() / 2.0 { 0.0 }
        else { delta.abs() - 2.0 * endpoint.abs() })
    }

'''+s[pos:];p.write_text(s)
