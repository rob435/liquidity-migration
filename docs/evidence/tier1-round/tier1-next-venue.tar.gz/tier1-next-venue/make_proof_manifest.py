from pathlib import Path
import re, json, hashlib
root=Path('/Users/jhbvdnsbkvnsd/Desktop/liquidity-migration'); base=Path('/tmp/tier1-next-venue')
logs=['underflow-before','provenance-before','inventory-before','lighter-pagination-before','lighter-decimals-before','lighter-scale-before','hl-precision-before','mexc-cap-before','bybit-error-before','accounting-before','accounting-marker-before','order-wire-before','order-integer-before','rounded-stop-before']
files=list((root/'engine').glob('*/src/**/*.rs'))+list((root/'engine').glob('*/tests/**/*.rs'))
text={p:p.read_text() for p in files}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
rows=[]
for log in logs:
 p=base/(log+'.log');tests=re.findall(r'^test (.+) \.\.\. FAILED$',p.read_text(),re.M); refs=[]
 for test in tests:
  fn=test.rsplit('::',1)[-1]
  found=[{'path':str(f.relative_to(root)),'sha256_current':sha(f)} for f,s in text.items() if 'fn '+fn+'(' in s]
  refs.append({'test':test,'current_test_sources':found})
 rows.append({'before_log':p.name,'before_log_sha256':sha(p),'failing_tests':refs,'provenance':'Failing test executed before applying the corresponding fix; no immutable pre-fix source image was retained for this individual run.' if log!='rounded-stop-before' else 'Isolated risk-work source variant before tightening rounded stop geometry; isolated source subsequently fixed.'})
(base/'integrated-regression-manifest.json').write_text(json.dumps({'scope':'Integrated numeric, execution metadata, accounting, exact wire regressions; isolated risk and margin excluded','rust_toolchain':'1.90.0','limitations':['Log hashes bind observed failures; current source hashes identify retained regressions, not pre-fix binaries.','Before runs during newly introduced DTO/API work are not claims that equivalent code existed in the original audit commit.','No funded or live execution evidence.'],'regressions':rows},indent=2)+'\n')
print(base/'integrated-regression-manifest.json')
