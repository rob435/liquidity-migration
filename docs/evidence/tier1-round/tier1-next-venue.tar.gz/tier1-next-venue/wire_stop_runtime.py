from pathlib import Path
p=Path('engine/engine-core/src/engine.rs');s=p.read_text();start=s.index('    /// Keep a venue-global position stop');end=s.index('    /// Stop trusting the account snapshot',start);s=s[:start]+s[end:];s=s.replace('enum PendingMutation {','enum PendingMutation {\n    SetStop { stop: stop_runtime::DurableStop, queued_ns: u64 },',1);s=s.replace('mod venue_completion;','mod venue_completion;\nmod stop_runtime;',1);s=s.replace('    confirmed_stop_moves:', '    confirmed_native_stops: std::collections::BTreeMap<SymbolId, engine_types::order_terms::ExactStopTerms>,\n    confirmed_stop_moves:',1);s=s.replace('        self.confirmed_stop_moves.clear();','        self.confirmed_stop_moves.clear();\n        self.confirmed_native_stops.clear();',1);p.write_text(s)
p=Path('engine/engine-core/src/engine/boot_recovery.rs');s=p.read_text().replace('            confirmed_stop_moves:', '            confirmed_native_stops: std::collections::BTreeMap::new(),\n            confirmed_stop_moves:',1);p.write_text(s)
p=Path('engine/engine-core/src/engine/scheduling.rs');s=p.read_text().replace('matches!(pending.action, Action::Place(_) | Action::Amend { .. })','matches!(pending.action, Action::Place(_) | Action::Amend { .. } | Action::SetStop { .. })',1).replace('self.process_set_stop(symbol, trigger_px)','self.process_set_stop(caller, symbol, trigger_px)',1).replace('self.books.attribution.sole_owner(*symbol) == Some(caller)','if self.instrument_specs.contains_key(symbol) { self.books.attribution.signed(caller, *symbol) != 0.0 } else { self.books.attribution.sole_owner(*symbol) == Some(caller) }',1);p.write_text(s)
p=Path('engine/engine-core/src/order_dispatch.rs');s=p.read_text().replace('pub(crate) enum DispatchWrite {','pub(crate) enum DispatchWrite {\n    Stop(Vec<crate::engine::stop_runtime::DurableStop>),',1);p.write_text(s)
p=Path('engine/engine-core/src/engine.rs');s=p.read_text().replace('mod stop_runtime;','pub(crate) mod stop_runtime;',1);p.write_text(s)
p=Path('engine/engine-core/src/engine/stop_runtime.rs');s=p.read_text().replace('pub(super) struct DurableStop','pub(crate) struct DurableStop',1);p.write_text(s)
p=Path('engine/engine-core/src/engine/order_dispatch.rs');s=p.read_text().replace('            DispatchWrite::Amend(amend) =>','            DispatchWrite::Stop(stops) => self.dispatch_durable_stops(stops)?,\n            DispatchWrite::Amend(amend) =>',1);p.write_text(s)
p=Path('engine/engine-core/src/venue_runtime.rs');s=p.read_text().replace('pub enum MutationCompletion {','pub enum MutationCompletion {\n    SetStop { command_id: u64, started_ns: u64, completed_ns: u64, rate_wait_ns: Option<u64>, reply: Result<(), VenueError> },',1).replace('enum Command {','enum Command {\n    DispatchStop { command_id: u64, symbol: SymbolId, trigger_px: f64, exact: Option<engine_types::order_terms::ExactStopTerms> },',1)
s=s.replace('    pub fn dispatch_order_status(','''    pub fn dispatch_stop(&mut self, symbol: SymbolId, trigger_px: f64, exact: Option<engine_types::order_terms::ExactStopTerms>) -> Result<u64, VenueError> {
        let command_id = self.mint_command_id();
        self.send(Command::DispatchStop { command_id, symbol, trigger_px, exact })?;
        Ok(command_id)
    }

    pub fn dispatch_order_status(''',1)
s=s.replace('            Command::SendOrdersWait { requests, reply } => {','''            Command::DispatchStop { command_id, symbol, trigger_px, exact } => {
                let started_ns = engine_types::clock::mono_ns();
                let reply = match exact { Some(terms) => venue.set_stop_exact(symbol, &terms).await, None => venue.set_stop(symbol, trigger_px).await };
                let rate_wait_ns = venue.take_rate_wait_ns();
                let completed_ns = engine_types::clock::mono_ns();
                let _ = completions.send(MutationCompletion::SetStop { command_id, started_ns, completed_ns, rate_wait_ns, reply }).await;
            }
            Command::SendOrdersWait { requests, reply } => {''',1);p.write_text(s)
p=Path('engine/engine-core/src/engine/venue_completion.rs');s=p.read_text();start=s.index('    /// Move a position');end=s.index('    /// Record a bounded cancel group',start);s=s[:start]+s[end:]
s=s.replace('enum CompletedMutation {','enum CompletedMutation {\n    SetStop { clocks: CompletionClocks, stop: stop_runtime::DurableStop, reply: Result<(), VenueError> },',1)
s=s.replace('        match (pending, completion) {','''        match (pending, completion) {
            (PendingMutation::SetStop { stop, queued_ns }, MutationCompletion::SetStop { started_ns, completed_ns, rate_wait_ns, reply, .. }) => {
                Ok(Self::SetStop { clocks: CompletionClocks { command_id, queued_ns, started_ns, completed_ns, rate_wait_ns }, stop, reply })
            },''',1).replace('                    PendingMutation::Amend { .. } => "amend",','                    PendingMutation::Amend { .. } => "amend",\n                    PendingMutation::SetStop { .. } => "stop",',1).replace('                    MutationCompletion::Amend { .. } => "amend",','                    MutationCompletion::Amend { .. } => "amend",\n                    MutationCompletion::SetStop { .. } => "stop",',1).replace('| MutationCompletion::Amend { command_id, .. } => *command_id,','| MutationCompletion::Amend { command_id, .. }\n            | MutationCompletion::SetStop { command_id, .. } => *command_id,',1)
s=s.replace('        match CompletedMutation::bind(pending, completion, command_id)? {','''        match CompletedMutation::bind(pending, completion, command_id)? {
            CompletedMutation::SetStop { clocks, stop, reply } => {
                self.record_quota_hold(&clocks);
                self.journal_venue_timing(&clocks, "stop", "", None, None)?;
                self.complete_stop(stop, reply)
            },''',1);p.write_text(s)
