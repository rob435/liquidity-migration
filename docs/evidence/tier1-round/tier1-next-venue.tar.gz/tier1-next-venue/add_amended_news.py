from pathlib import Path
import re
r=Path('/Users/jhbvdnsbkvnsd/Desktop/liquidity-migration/engine')
p=r/'engine-types/src/order_terms.rs';s=p.read_text();pos=s.index('#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]\npub struct ExactStopTerms');s=s[:pos]+'''#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
pub struct ExactAmendedTerms {
    pub price: crate::numeric::ExactNumber,
    pub quantity: crate::numeric::ExactNumber,
}
impl ExactAmendedTerms {
    pub fn validate_projection(&self, px: f64, qty: f64) -> Result<(), OrderLegalityError> {
        self.price.validate_provenance()?; self.quantity.validate_provenance()?;
        if !self.price.value.is_positive() || self.quantity.value.is_negative() { return Err(OrderLegalityError::Constraint("amended order amounts")); }
        if self.price.value.to_f64()? != px || self.quantity.value.to_f64()? != qty { return Err(OrderLegalityError::Projection); }
        Ok(())
    }
}

'''+s[pos:];p.write_text(s)
p=r/'engine-types/src/orders.rs';s=p.read_text();pos=s.index('    Amended {');start=s.index('\n        client_order_id:',pos);s=s[:start]+'''
        #[serde(default, skip_serializing_if = "Option::is_none")]
        exact_terms: Option<Box<crate::order_terms::ExactAmendedTerms>>,'''+s[start:];p.write_text(s)
changed=[]
for p in r.glob('**/*.rs'):
 if 'target' in p.parts: continue
 s=p.read_text(); out=[];at=0;count=0
 for m in list(re.finditer(r'\bOrderUpdate::Amended\s*\{',s)):
  start=m.end();depth=1;i=start
  while depth and i<len(s):
   if s[i]=='{':depth+=1
   elif s[i]=='}':depth-=1
   i+=1
  body=s[start:i-1]
  if 'exact_terms' in body or '..' in body: continue
  pattern=bool(re.match(r'\s*=>',s[i:]))
  out.append(s[at:start]);out.append(' ..,' if pattern else ' exact_terms: None,');at=start;count+=1
 if count: out.append(s[at:]);p.write_text(''.join(out));changed.append((str(p.relative_to(r)),count))
print(changed)
