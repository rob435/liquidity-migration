from pathlib import Path
r=Path('/Users/jhbvdnsbkvnsd/Desktop/liquidity-migration/engine/engine-venue/src')
for venue,classname in [('bybit','BybitGateway'),('binance','BinanceGateway'),('mexc','MexcGateway'),('lighter','LighterGateway'),('hyperliquid','HyperliquidGateway')]:
 p=r/f'venues/{venue}/gateway.rs';s=p.read_text();start=s.index('    async fn set_stop(&mut self, symbol: SymbolId, trigger_px: f64)');end=s.index('\n    }',start)+6;body=s[start:end];body=body.replace('async fn set_stop(&mut self, symbol: SymbolId, trigger_px: f64)', 'async fn set_stop_terms(&mut self, symbol: SymbolId, trigger_px: f64, exact: Option<&engine_types::order_terms::ExactStopTerms>)')
 if venue=='bybit':
  body=body.replace('        self.require_one_way(symbol).await?;','''        self.require_one_way(symbol).await?;
        if let Some(terms) = exact {
            let name = self.name_of(symbol)?;
            let query = format!("category={CATEGORY}&symbol={}&limit=200", percent_encode(name));
            let raw: Box<serde_json::value::RawValue> = self.rest.get_signed_as(PATH_POSITIONS, &query).await?;
            let (side, _) = crate::stop_state::bybit(raw.get(), name)?;
            if side != terms.position_side { return Err(VenueError::BadRequest("native position changed side before stop".into())); }
        }''').replace('body.insert("stopLoss".into(), venue_num(trigger_px)?.into());','body.insert("stopLoss".into(), match exact { Some(terms) => engine_types::order_terms::decimal_wire(&terms.trigger_price).map_err(crate::order_wire::error)?, None => venue_num(trigger_px)? }.into());')
 elif venue=='binance':
  body=body.replace('let position_side = self.held_position_side(&name).await?;','''let position_side = if let Some(terms) = exact {
            self.spend_weight(WEIGHT_ACCOUNT).await;
            let raw: Result<Box<serde_json::value::RawValue>, VenueError> = self.rest.get_signed_as(PATH_ACCOUNT, &[]).await;
            self.settle_weight(WEIGHT_ACCOUNT);
            let (side, _) = crate::stop_state::binance(raw?.get(), &name)?;
            if side != terms.position_side { return Err(VenueError::BadRequest("native position changed side before stop".into())); }
            side
        } else { self.held_position_side(&name).await? };''').replace('let params = Self::stop_params(&name, position_side, trigger_px, stop_id.clone())?;','''let params = match exact {
            Some(terms) => Self::stop_params_text(&name, position_side, engine_types::order_terms::decimal_wire(&terms.trigger_price).map_err(crate::order_wire::error)?, stop_id.clone()),
            None => Self::stop_params(&name, position_side, trigger_px, stop_id.clone())?,
        };''')
 elif venue=='mexc':
  first=body.index('        let position_id =');last=body.index('\n\n        // A stop already',first)
  old=body[first:last].replace('        let position_id =','')
  body=body[:first]+'''        let position_id = if let Some(terms) = exact {
            let venue_symbol = self.contracts.tradable(&name)?.venue_symbol.clone();
            let raw: Box<serde_json::value::RawValue> = self.rest.get_signed_as(PATH_POSITIONS, &[]).await?;
            let (id, side) = crate::stop_state::mexc(raw.get(), &venue_symbol)?;
            if side != terms.position_side { return Err(VenueError::BadRequest("native position changed side before stop".into())); }
            id
        } else { '''+old.rstrip().removesuffix(';')+''' };'''+body[last:]
  body=body.replace('let price = venue_num(trigger_px)?;','let price = match exact { Some(terms) => engine_types::order_terms::decimal_wire(&terms.trigger_price).map_err(crate::order_wire::error)?, None => venue_num(trigger_px)? };')
 elif venue=='hyperliquid':
  first=body.index('        let state =');last=body.index('\n\n        // Which stops',first)
  body=body[:first]+'''        let raw: Box<serde_json::value::RawValue> = self.info_as(json!({"type": "clearinghouseState", "user": self.address_text()})).await?;
        let (position_side, exact_qty) = crate::stop_state::hyperliquid(raw.get(), &coin)?;
        if exact.is_some_and(|terms| terms.position_side != position_side) { return Err(VenueError::BadRequest("native position changed side before stop".into())); }
'''+body[last:]
  body=body.replace('let stop = self.stop_wire(&asset, position_side, qty, trigger_px)?;','''let stop = match exact {
            Some(terms) => {
                let step = engine_types::numeric::Exact::parse_decimal(&format!("1e-{}", asset.sz_decimals)).map_err(crate::order_wire::error)?;
                if !exact_qty.is_multiple_of(&step).map_err(crate::order_wire::error)? { return Err(VenueError::BadReply("native stop quantity violates asset precision".into())); }
                let text = engine_types::order_terms::decimal_wire(&terms.trigger_price).map_err(crate::order_wire::error)?;
                OrderWire { asset: asset.index, is_buy: position_side.flipped() == Side::Buy, px: text.clone(), sz: engine_types::order_terms::decimal_wire(&exact_qty).map_err(crate::order_wire::error)?, reduce_only: true, kind: OrderKindWire::Trigger { is_market: true, trigger_px: text, tpsl: TPSL_STOP }, cloid: None }
            }
            None => self.stop_wire(&asset, position_side, exact_qty.to_f64().map_err(crate::order_wire::error)?, trigger_px)?,
        };''')
 elif venue=='lighter':
  first=body.index('        let account =');last=body.index('\n\n        // Which stops',first)
  body=body[:first]+'''        let raw: Box<serde_json::value::RawValue> = self.http.get_as(PATH_ACCOUNT, &format!("by=index&value={}", self.account.account_index), &[]).await?;
        let (position_side, exact_qty) = crate::stop_state::lighter(raw.get(), market.index, &market.symbol, self.account.account_index)?;
        if exact.is_some_and(|terms| terms.position_side != position_side) { return Err(VenueError::BadRequest("native position changed side before stop".into())); }
'''+body[last:]
  first=body.index('        let exit_side =');last=body.index('\n\n        for index in old',first)
  body=body[:first]+'''        let exit_side = position_side.flipped();
        let stop_id = format!("stop-{}-{}", market.index, wall_ms());
        if let Some(terms) = exact {
            let qty_units = crate::order_wire::scaled(&exact_qty, market.size_decimals, (1u64 << 48)-1)?;
            let price_units = crate::order_wire::scaled(&terms.trigger_price, market.price_decimals, u64::from(u32::MAX))?;
            self.send_stop_units(&market, exit_side, qty_units as i64, price_units as u32, &stop_id).await?;
        } else {
            self.send_stop(&market, exit_side, exact_qty.to_f64().map_err(crate::order_wire::error)?, trigger_px, &stop_id).await?;
        }
'''+body[last:]
 validation={'bybit':'self.exact_specs.get(self.name_of(symbol)?).ok_or_else(|| VenueError::Unsupported("exact stop metadata is not installed".into()))?',
 'binance':'self.exact_specs.get(self.name_of(symbol)?).ok_or_else(|| VenueError::Unsupported("exact stop metadata is not installed".into()))?',
 'mexc':'&self.contracts.tradable(self.name_of(symbol)?)?.exact_spec',
 'lighter':'self.markets.for_symbol(self.name_of(symbol)?)?.exact_spec.as_ref().ok_or_else(|| VenueError::Unsupported("exact stop metadata is not installed".into()))?',
 'hyperliquid':'&self.assets.for_symbol(self.name_of(symbol)?)?.exact_spec()?'}[venue]
 wrapper=f'''    async fn set_stop(&mut self, symbol: SymbolId, trigger_px: f64) -> Result<(), VenueError> {{
        self.set_stop_terms(symbol, trigger_px, None).await
    }}

    async fn set_stop_exact(&mut self, symbol: SymbolId, terms: &engine_types::order_terms::ExactStopTerms) -> Result<(), VenueError> {{
        terms.validate_wire_grid({validation}).map_err(crate::order_wire::error)?;
        self.set_stop_terms(symbol, terms.trigger_price.to_f64().map_err(crate::order_wire::error)?, Some(terms)).await
    }}'''
 s=s[:start]+wrapper+s[end:];pos=s.index(f'impl {classname} {{')+len(f'impl {classname} {{');s=s[:pos]+'\n'+body+'\n'+s[pos:]
 if venue in ('bybit','binance'):
  s=s.replace('    symbols: engine_public::symbols::SymbolCatalog,','    symbols: engine_public::symbols::SymbolCatalog,\n    exact_specs: HashMap<Symbol, engine_types::numeric::ExactInstrumentSpec>,',1)
  s=s.replace('            symbols: engine_public::symbols::SymbolCatalog::from_names(symbols),','            symbols: engine_public::symbols::SymbolCatalog::from_names(symbols),\n            exact_specs: HashMap::new(),',1)
  pos=s.index('    fn install_instrument_catalog(');last=s.index('\n    }',pos);chunk=s[pos:last];chunk=chunk.replace('        Ok(())','        self.exact_specs = catalog.specs.iter().cloned().collect();\n        Ok(())');s=s[:pos]+chunk+s[last:]
 p.write_text(s)
p=r/'registry.rs';s=p.read_text();pos=s.index('    async fn set_stop(');s=s[:pos]+'''    async fn set_stop_exact(&mut self, symbol: SymbolId, terms: &engine_types::order_terms::ExactStopTerms) -> Result<(), VenueError> {
        match self {
            Venue::Bybit(gw) => gw.set_stop_exact(symbol, terms).await,
            Venue::Hyperliquid(gw) => gw.set_stop_exact(symbol, terms).await,
            Venue::Lighter(gw) => gw.set_stop_exact(symbol, terms).await,
            Venue::Mexc(gw) => gw.set_stop_exact(symbol, terms).await,
            Venue::Binance(gw) => gw.set_stop_exact(symbol, terms).await,
            Venue::Variational(gw) => gw.set_stop_exact(symbol, terms).await,
        }
    }

'''+s[pos:];p.write_text(s)
