use std::collections::BTreeMap;
use std::time::{Duration, Instant};

use engine_types::strategy_process::{CallbackOrderOrigin, CallbackWalCursor, CallbackWalReader, CallbackWalRecord};
use engine_types::{OrderUpdate, StrategyId, WalError, WalRecord};

pub struct ReadCompletion {
    reader: Box<dyn CallbackWalReader>,
    pub strategy: StrategyId,
    pub cursor: CallbackWalCursor,
    pub result: Result<Option<CallbackWalRecord>, WalError>,
}

pub struct OrderNews {
    reader: Option<Box<dyn CallbackWalReader>>,
    start: Option<CallbackWalCursor>,
    cursors: BTreeMap<StrategyId, CallbackWalCursor>,
    latest: BTreeMap<StrategyId, u64>,
    through: BTreeMap<StrategyId, u64>,
    retry_after: BTreeMap<StrategyId, Instant>,
    last_read: Option<StrategyId>,
    pending: bool,
    pub completed: tokio::sync::mpsc::Receiver<ReadCompletion>,
    completion: tokio::sync::mpsc::Sender<ReadCompletion>,
}

impl Default for OrderNews {
    fn default() -> Self {
        let (completion, completed) = tokio::sync::mpsc::channel(1);
        Self { reader: None, start: None, cursors: BTreeMap::new(), latest: BTreeMap::new(), through: BTreeMap::new(), retry_after: BTreeMap::new(), last_read: None, pending: false, completed, completion }
    }
}

impl OrderNews {
    pub fn attach(&mut self, reader: Box<dyn CallbackWalReader>, records: &[WalRecord], strategy_count: usize) -> Result<(), String> {
        if self.pending { return Err("cannot replace an owned callback WAL read".into()); }
        *self = Self::default();
        self.start = Some(reader.start());
        self.reader = Some(reader);
        for (index, record) in records.iter().enumerate() {
            let owners = match record {
                WalRecord::OrderUpdate { callbacks: Some(owners), .. } => owners.clone(),
                WalRecord::StrategyCallbackSource { strategy, .. } => vec![*strategy],
                _ => continue,
            };
            {
                if owners.iter().any(|owner| owner.idx() >= strategy_count) { return Err("order callback source escapes configured owners".into()); }
                self.record(index as u64 + 1, &owners)?;
            }
        }
        for record in records {
            if let WalRecord::StrategyCallbackQueued { input } = record {
                if let Some(origin) = input.order_origin.filter(|origin| Some(origin.segment) == self.start.map(|start| start.segment)) {
                    let source = origin.sequence.checked_sub(1).and_then(|index| records.get(index as usize)).ok_or("callback order origin has no parent frame")?;
                    let expected = match source {
                        WalRecord::OrderUpdate { update, callbacks: Some(owners) } if owners.contains(&input.strategy) => engine_types::strategy_process::CallbackEvent::Order { update: Self::slice(update, input.strategy)? },
                        WalRecord::StrategyCallbackSource { strategy, event } if *strategy == input.strategy => event.clone(),
                        _ => return Err("callback source origin has no matching durable owner".into()),
                    };
                    if input.event != expected { return Err("callback view differs from its durable parent".into()); }
                    self.accepted(input.strategy, origin);
                }
            }
        }
        Ok(())
    }

    pub fn slice(update: &OrderUpdate, strategy: StrategyId) -> Result<OrderUpdate, String> {
        match crate::portfolio_allocation::slice_updates(update)? {
            Some(slices) => slices.into_iter().find_map(|(owner, update)| (owner == strategy).then_some(update)).ok_or_else(|| "allocated execution has no callback slice for its recorded owner".into()),
            None => Ok(update.clone()),
        }
    }

    pub fn origin(&self, sequence: u64) -> Result<CallbackOrderOrigin, String> {
        Ok(CallbackOrderOrigin { segment: self.start.ok_or("isolated callbacks have no WAL source reader")?.segment, sequence })
    }

    pub fn record(&mut self, sequence: u64, owners: &[StrategyId]) -> Result<(), String> {
        if sequence == 0 { return Err("order callback source has zero sequence".into()); }
        for owner in owners { self.latest.entry(*owner).and_modify(|known| *known = (*known).max(sequence)).or_insert(sequence); }
        Ok(())
    }

    pub fn unread_for(&self, strategy: StrategyId) -> bool {
        self.latest.get(&strategy).copied().unwrap_or_default() > self.through.get(&strategy).copied().unwrap_or_default()
    }

    pub fn has_reader(&self) -> bool { self.start.is_some() }
    pub fn source_due(&self, strategy: StrategyId, sequence: u64) -> bool { sequence > self.through.get(&strategy).copied().unwrap_or_default() }
    pub fn pending(&self) -> bool { self.pending }
    pub fn unread(&self) -> bool { self.pending || self.latest.keys().any(|owner| self.unread_for(*owner)) }

    pub fn accepted(&mut self, strategy: StrategyId, origin: CallbackOrderOrigin) {
        if Some(origin.segment) == self.start.map(|cursor| cursor.segment) {
            self.through.entry(strategy).and_modify(|through| *through = (*through).max(origin.sequence)).or_insert(origin.sequence);
            self.retry_after.remove(&strategy);
        }
    }

    pub fn start_read(&mut self) {
        if self.pending || self.reader.is_none() { return; }
        let now = Instant::now();
        let mut owners: Vec<_> = self.latest.keys().copied().filter(|owner| self.unread_for(*owner) && self.retry_after.get(owner).is_none_or(|after| *after <= now)).collect();
        if let Some(previous) = self.last_read { let next = owners.partition_point(|owner| *owner <= previous); owners.rotate_left(next); }
        let Some(strategy) = owners.first().copied() else { return; };
        let cursor = self.cursors.get(&strategy).copied().or(self.start).expect("configured callback reader");
        let mut reader = self.reader.take().expect("available callback reader");
        self.pending = true;
        self.last_read = Some(strategy);
        let completed = self.completion.clone();
        tokio::task::spawn_blocking(move || {
            let result = reader.next(cursor);
            let _ = completed.blocking_send(ReadCompletion { reader, strategy, cursor, result });
        });
    }

    pub fn returned(&mut self, completion: ReadCompletion) -> Result<(StrategyId, CallbackWalCursor, CallbackWalRecord), String> {
        if !self.pending || self.reader.is_some() { return Err("callback WAL read completion has no owner".into()); }
        self.pending = false;
        self.reader = Some(completion.reader);
        let record = completion.result.map_err(|error| error.to_string())?.ok_or("callback source disappeared before its recorded frontier")?;
        Ok((completion.strategy, completion.cursor, record))
    }

    pub fn advance(&mut self, strategy: StrategyId, cursor: CallbackWalCursor) { self.cursors.insert(strategy, cursor); }
    pub fn refused(&mut self, strategy: StrategyId) { self.retry_after.insert(strategy, Instant::now() + Duration::from_secs(1)); }
}
