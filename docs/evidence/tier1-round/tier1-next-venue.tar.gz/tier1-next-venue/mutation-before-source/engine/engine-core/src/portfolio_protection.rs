use engine_types::numeric::{Exact, ExactInstrumentSpec};
use engine_types::order_terms::ExactStopTerms;
use engine_types::portfolio::PortfolioState;
use engine_types::risk::PhysicalExposureInterval;
use engine_types::{OrderKind, OrderRequest, Side};

pub(crate) struct ProtectionPlan {
    pub reduce_only: bool,
    pub native_stop: Option<ExactStopTerms>,
}

/// Outstanding orders contribute their logical stop only on the resulting net side.
pub(crate) fn plan(
    portfolio: &PortfolioState,
    request: &OrderRequest,
    before: PhysicalExposureInterval,
    spec: &ExactInstrumentSpec,
    reference: &Exact,
    other_stops: impl IntoIterator<Item = (Side, Exact)>,
) -> Result<ProtectionPlan, String> {
    if before.certainly_reduces(request.side, request.qty) {
        return Ok(ProtectionPlan { reduce_only: true, native_stop: None });
    }
    let after = before.after(request.side, request.qty).map_err(|e| format!("{e:?}"))?;
    let side = if after.low() >= 0.0 && after.high() > 0.0 {
        Side::Buy
    } else if after.high() <= 0.0 && after.low() < 0.0 {
        Side::Sell
    } else if after.low() == 0.0 && after.high() == 0.0 {
        return Ok(ProtectionPlan { reduce_only: true, native_stop: None });
    } else {
        return Err("outstanding orders leave the physical position direction unresolved".into());
    };
    if side != request.side {
        return Err("a physical growth order must protect the direction it can create".into());
    }
    let quantity = request.exact_terms.as_ref().map(|terms| Ok(terms.quantity.clone()))
        .unwrap_or_else(|| Exact::from_legacy_f64(request.qty)).map_err(|e| e.to_string())?;
    let delta = if request.side == Side::Buy { quantity } else { Exact::zero() - quantity };
    let logical_stop = request.exact_terms.as_ref().and_then(|terms| terms.stop_trigger_price.clone())
        .or_else(|| request.sleeve_stop().and_then(|stop| Exact::from_legacy_f64(stop.trigger_px).ok()));
    let mut candidates = Vec::new();
    let mut owner_seen = false;
    for row in portfolio.positions.iter().filter(|row| row.symbol == request.symbol) {
        let mut quantity = row.signed_qty.clone();
        let mut stop = row.stop_px.clone();
        if row.strategy == request.strategy {
            owner_seen = true;
            quantity += &delta;
            if !request.is_sleeve_reduction() {
                stop = if row.signed_qty.signum() == delta.signum() {
                    tighter(side, stop, logical_stop.clone())
                } else { logical_stop.clone() };
            }
        }
        if quantity.is_zero() || quantity.is_positive() != (side == Side::Buy) {
            continue;
        }
        candidates.push(stop.ok_or("a surviving sleeve has no durable stop")?);
    }
    if !owner_seen && !request.is_sleeve_reduction() {
        candidates.push(logical_stop.ok_or("the new sleeve has no durable stop")?);
    }
    candidates.extend(other_stops.into_iter().filter(|(stop_side, _)| *stop_side == side).map(|(_, stop)| stop));
    let trigger = candidates.into_iter().reduce(|a, b| match side {
        Side::Buy => a.max(b), Side::Sell => a.min(b),
    }).ok_or("physical growth has no surviving sleeve protection")?;
    let mut reference = reference.clone();
    if let OrderKind::Limit { px, .. } = request.kind {
        let limit = request.exact_terms.as_ref().and_then(|terms| terms.limit_price.clone())
            .map(Ok).unwrap_or_else(|| Exact::from_legacy_f64(px)).map_err(|e| e.to_string())?;
        reference = match side { Side::Buy => reference.min(limit), Side::Sell => reference.max(limit) };
    }
    let native_stop = ExactStopTerms::quantize(spec, side, &trigger, &reference).map_err(|e| e.to_string())?;
    Ok(ProtectionPlan { reduce_only: false, native_stop: Some(native_stop) })
}

fn tighter(side: Side, a: Option<Exact>, b: Option<Exact>) -> Option<Exact> {
    match (a, b) {
        (Some(a), Some(b)) => Some(match side { Side::Buy => a.max(b), Side::Sell => a.min(b) }),
        (a, b) => a.or(b),
    }
}
