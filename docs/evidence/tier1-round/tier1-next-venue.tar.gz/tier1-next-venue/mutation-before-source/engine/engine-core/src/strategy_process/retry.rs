use std::collections::BTreeSet;

use engine_types::{EngineEvent, MarketEvent, MarketState, StrategyId, SymbolId};

#[derive(Clone, Copy, Debug, PartialEq, Eq, PartialOrd, Ord)]
pub enum MarketSlot {
    Quote(SymbolId),
    Depth(SymbolId),
    Trades(SymbolId),
    Ticker(SymbolId),
    Reset,
}

impl MarketSlot {
    fn from_event(event: &MarketEvent) -> Self {
        match event {
            MarketEvent::Quote { symbol, .. } => Self::Quote(*symbol),
            MarketEvent::Depth { symbol, .. } => Self::Depth(*symbol),
            MarketEvent::Trades { symbol, .. } => Self::Trades(*symbol),
            MarketEvent::Ticker { symbol, .. } => Self::Ticker(*symbol),
            MarketEvent::FeedReset { .. } => Self::Reset,
        }
    }

    pub fn latest(self, market: &MarketState, reset_ns: u64) -> MarketEvent {
        match self {
            Self::Quote(symbol) => MarketEvent::Quote { symbol, quote: *market.quote(symbol) },
            Self::Depth(symbol) => MarketEvent::Depth { symbol, depth: *market.depth(symbol) },
            Self::Trades(symbol) => MarketEvent::Trades { symbol, trades: *market.trade_flow(symbol) },
            Self::Ticker(symbol) => MarketEvent::Ticker { symbol, ticker: *market.ticker(symbol) },
            Self::Reset => MarketEvent::FeedReset { recv_ns: reset_ns },
        }
    }
}

#[derive(Default)]
pub struct RetryInputs {
    pub market: BTreeSet<(StrategyId, MarketSlot)>,
    pub reset_ns: u64,
    pub strategy_events: BTreeSet<(StrategyId, String)>,
    pub controls: BTreeSet<(StrategyId, String)>,
}

impl RetryInputs {
    pub fn remember(&mut self, strategy: StrategyId, event: &EngineEvent) {
        match event {
            EngineEvent::Market(event) => {
                if let MarketEvent::FeedReset { recv_ns } = event { self.reset_ns = self.reset_ns.max(*recv_ns); }
                self.market.insert((strategy, MarketSlot::from_event(event)));
            }
            EngineEvent::StrategyEvent(event) => { self.strategy_events.insert((event.source, event.event_id.clone())); }
            EngineEvent::EntryPermission { request_id, .. } | EngineEvent::FlattenDirectional { request_id } => { self.controls.insert((strategy, request_id.clone())); }
            _ => (),
        }
    }

    pub fn forget(&mut self, strategy: StrategyId, event: &EngineEvent) {
        match event {
            EngineEvent::Market(event) => { self.market.remove(&(strategy, MarketSlot::from_event(event))); }
            EngineEvent::StrategyEvent(event) => { self.strategy_events.remove(&(event.source, event.event_id.clone())); }
            EngineEvent::EntryPermission { request_id, .. } | EngineEvent::FlattenDirectional { request_id } => { self.controls.remove(&(strategy, request_id.clone())); }
            _ => (),
        }
    }
}
