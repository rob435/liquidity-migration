from pathlib import Path
r=Path('/Users/jhbvdnsbkvnsd/Desktop/liquidity-migration/engine')
p=r/'engine-types/src/order_terms.rs';s=p.read_text().replace('use crate::orders::{OrderKind, OrderRequest, Side, SleeveOrderEffect, StopSpec};','use crate::orders::{AmendSpec, OrderKind, OrderRequest, Side, SleeveOrderEffect, StopSpec};');pos=s.index('#[derive(Clone, Copy, Debug, PartialEq, Eq)]\npub enum QuantityPolicy')
s=s[:pos]+'''#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
pub struct ExactAmendTerms {
    pub quantity: Option<Exact>,
    pub limit_price: Option<Exact>,
    pub input_policy: OrderInputPolicy,
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
pub struct ExactStopTerms {
    pub trigger_price: Exact,
    pub position_side: Side,
    pub reference_price: Exact,
}

'''+s[pos:];pos=s.index('#[cfg(test)]')
s=s[:pos]+'''impl ExactAmendTerms {
    pub fn validate_projection(&self, amendment: &AmendSpec) -> Result<(), OrderLegalityError> {
        if self.quantity.is_none() && self.limit_price.is_none() { return Err(OrderLegalityError::Constraint("empty amendment")); }
        for value in self.quantity.iter().chain(self.limit_price.iter()) { decimal_wire(value)?; value.to_f64()?; }
        if self.quantity.as_ref().map(Exact::to_f64).transpose()? != amendment.qty
            || self.limit_price.as_ref().map(Exact::to_f64).transpose()? != amendment.px {
            return Err(OrderLegalityError::Projection);
        }
        Ok(())
    }

    pub fn apply_projection(&self, amendment: &mut AmendSpec) -> Result<(), OrderLegalityError> {
        amendment.qty = self.quantity.as_ref().map(Exact::to_f64).transpose()?;
        amendment.px = self.limit_price.as_ref().map(Exact::to_f64).transpose()?;
        self.validate_projection(amendment)?;
        amendment.exact_terms = Some(Box::new(self.clone()));
        Ok(())
    }
}

pub fn quantize_amend(spec: &ExactInstrumentSpec, current: &OrderRequest, amendment: &AmendSpec, reference_px: Option<f64>) -> Result<ExactAmendTerms, OrderLegalityError> {
    if amendment.px.is_none() && amendment.qty.is_none() { return Err(OrderLegalityError::Constraint("empty amendment")); }
    let OrderKind::Limit { px: current_px, .. } = current.kind else { return Err(OrderLegalityError::Constraint("only limit orders can be amended")); };
    if let Some(terms) = current.exact_terms.as_deref() { terms.validate_projection(current)?; }
    let quantity = amendment.qty.map(|qty| {
        strategy_decimal(qty)?.floor_to(required_positive(&spec.qty_step, "quantity step")?).map_err(OrderLegalityError::from)
    }).transpose()?;
    let limit_price = amendment.px.map(|px| quantize_price(&strategy_decimal(px)?, current.side, spec)).transpose()?;
    let full_quantity = match &quantity {
        Some(qty) => qty.clone(),
        None => match &current.exact_terms { Some(terms) => terms.quantity.clone(), None => strategy_decimal(current.qty)? },
    };
    let full_price = match &limit_price {
        Some(px) => px.clone(),
        None => match &current.exact_terms { Some(terms) => terms.limit_price.clone().ok_or(OrderLegalityError::Projection)?, None => strategy_decimal(current_px)? },
    };
    let projected = ExactOrderTerms { quantity: full_quantity, limit_price: Some(full_price.clone()), stop_trigger_price: None, physical_stop_trigger_price: None, input_policy: OrderInputPolicy::StrategyShortestDecimal };
    projected.validate_wire_grid(spec, current.kind, QuantityPolicy::Normal)?;
    if let Some(min) = &spec.min_notional {
        min.validate_storage()?;
        if min.is_negative() { return Err(OrderLegalityError::Constraint("negative minimum notional")); }
        if &projected.quantity * &full_price < *min { return Err(OrderLegalityError::Constraint("minimum notional")); }
    }
    if let Some(stop) = current.sleeve_stop() {
        let trigger = match current.exact_terms.as_deref().and_then(|terms| terms.stop_trigger_price.as_ref()) {
            Some(trigger) => trigger.clone(), None => strategy_decimal(stop.trigger_px)?,
        };
        let reference = reference_px.map(strategy_decimal).transpose()?.ok_or(OrderLegalityError::Unavailable("stop reference price"))?;
        if match current.side { Side::Buy => trigger >= full_price || trigger >= reference, Side::Sell => trigger <= full_price || trigger <= reference } {
            return Err(OrderLegalityError::Constraint("amend crosses protective stop"));
        }
    }
    Ok(ExactAmendTerms { quantity, limit_price, input_policy: OrderInputPolicy::StrategyShortestDecimal })
}

impl ExactStopTerms {
    pub fn quantize(spec: &ExactInstrumentSpec, position_side: Side, trigger: &Exact, reference: &Exact) -> Result<Self, OrderLegalityError> {
        let terms = Self { trigger_price: quantize_price(trigger, position_side.flipped(), spec)?, position_side, reference_price: reference.clone() };
        terms.validate_storage()?;
        Ok(terms)
    }

    pub fn validate_storage(&self) -> Result<(), OrderLegalityError> {
        decimal_wire(&self.trigger_price)?; decimal_wire(&self.reference_price)?;
        self.trigger_price.to_f64()?; self.reference_price.to_f64()?;
        if match self.position_side { Side::Buy => self.trigger_price >= self.reference_price, Side::Sell => self.trigger_price <= self.reference_price } {
            return Err(OrderLegalityError::Constraint("stop crosses current reference"));
        }
        Ok(())
    }

    pub fn validate_wire_grid(&self, spec: &ExactInstrumentSpec) -> Result<(), OrderLegalityError> {
        self.validate_storage()?;
        if quantize_price(&self.trigger_price, Side::Buy, spec)? != self.trigger_price {
            return Err(OrderLegalityError::Constraint("stop price grid"));
        }
        Ok(())
    }
}

'''+s[pos:];p.write_text(s)
p=r/'engine-types/src/orders.rs';s=p.read_text().replace('''#[derive(Copy, Clone, Debug, PartialEq, Serialize, Deserialize)]
pub struct AmendSpec {
    pub px: Option<f64>,
    pub qty: Option<f64>,
}''','''#[derive(Clone, Debug, PartialEq, Serialize, Deserialize)]
pub struct AmendSpec {
    pub px: Option<f64>,
    pub qty: Option<f64>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub exact_terms: Option<Box<crate::order_terms::ExactAmendTerms>>,
}''');p.write_text(s)
p=r/'engine-types/src/lib.rs';s=p.read_text();needle='    async fn set_stop(&mut self, symbol: SymbolId, trigger_px: f64) -> Result<(), VenueError>;';assert needle in s;s=s.replace(needle,needle+'''
    async fn set_stop_exact(&mut self, _symbol: SymbolId, _terms: &crate::order_terms::ExactStopTerms) -> Result<(), VenueError> {
        Err(VenueError::Unsupported("exact standalone stops are unavailable".into()))
    }
''');p.write_text(s)
# Add fields to literal bodies only, leaving patterns with .. and the type declaration alone.
changed=[]
for p in r.glob('**/*.rs'):
 if 'target' in p.parts: continue
 s=p.read_text();out=[];at=0;count=0
 import re
 for m in list(re.finditer(r'\bAmendSpec\s*\{',s)):
  start=m.end();depth=1;i=start
  while depth and i<len(s):
   if s[i]=='{':depth+=1
   elif s[i]=='}':depth-=1
   i+=1
  body=s[start:i-1]
  if 'exact_terms' in body or '..' in body or 'pub px:' in body or not re.search(r'\b(px|qty)\s*:',body): continue
  out.append(s[at:start]);out.append(' exact_terms: None,');at=start;count+=1
 if count:
  out.append(s[at:]);p.write_text(''.join(out));changed.append((str(p.relative_to(r)),count))
print(changed)
