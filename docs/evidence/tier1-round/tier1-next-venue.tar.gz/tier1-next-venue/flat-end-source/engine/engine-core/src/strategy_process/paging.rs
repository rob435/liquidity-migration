use std::collections::BTreeMap;

use engine_types::strategy_process::{CallbackPreparation, CallbackQueueSlot, CallbackWalCursor, CallbackWalReader, StrategyCallbackInput};
use engine_types::{StrategyId, WalRecord};
use sha2::{Digest, Sha256};

use super::state::CallbackState;

pub struct PageCompletion {
    reader: Box<dyn CallbackWalReader>,
    pub callback_id: u64,
    pub input: Result<StrategyCallbackInput, engine_types::WalError>,
}

pub struct CallbackPages {
    pub slots: BTreeMap<u64, CallbackQueueSlot>,
    reader: Option<Box<dyn CallbackWalReader>>,
    loading: Option<u64>,
    last_owner: Option<StrategyId>,
    sender: tokio::sync::mpsc::Sender<PageCompletion>,
    pub completed: tokio::sync::mpsc::Receiver<PageCompletion>,
}

impl Default for CallbackPages {
    fn default() -> Self {
        let (sender, completed) = tokio::sync::mpsc::channel(1);
        Self { slots: BTreeMap::new(), reader: None, loading: None, last_owner: None, sender, completed }
    }
}

impl CallbackPages {
    pub fn hash(input: &StrategyCallbackInput) -> Result<[u8; 32], String> {
        struct HashWriter(Sha256);
        impl std::io::Write for HashWriter {
            fn write(&mut self, bytes: &[u8]) -> std::io::Result<usize> { self.0.update(bytes); Ok(bytes.len()) }
            fn flush(&mut self) -> std::io::Result<()> { Ok(()) }
        }
        let mut writer = HashWriter(Sha256::new());
        serde_json::to_writer(&mut writer, &(&input.event, input.order_origin)).map_err(|error| error.to_string())?;
        Ok(writer.0.finalize().into())
    }

    pub fn enabled(&self) -> bool { self.reader.is_some() || self.loading.is_some() }
    pub fn loading(&self) -> bool { self.loading.is_some() }
    pub fn owner_pending(&self, owner: StrategyId) -> bool { self.slots.values().any(|slot| slot.strategy == owner) }
    pub fn attach(&mut self, reader: Box<dyn CallbackWalReader>) { self.reader = Some(reader); }

    pub fn queued(&mut self, input: &StrategyCallbackInput, cursor: CallbackWalCursor) -> Result<(), String> {
        let slot = CallbackQueueSlot { callback_id: input.callback_id, strategy: input.strategy, queued: cursor, prepared: input.snapshot().map(|_| cursor), event_sha256: Self::hash(input)? };
        self.insert(slot)
    }

    fn insert(&mut self, slot: CallbackQueueSlot) -> Result<(), String> {
        if self.slots.contains_key(&slot.callback_id) { return Err("callback queue slot is repeated".into()); }
        self.slots.insert(slot.callback_id, slot);
        if let Err(error) = CallbackState::encoded_size(&self.slots) { self.slots.pop_last(); return Err(error); }
        Ok(())
    }

    pub fn prepared(&mut self, input: &StrategyCallbackInput, cursor: CallbackWalCursor) -> Result<(), String> {
        let first = self.slots.values().find(|slot| slot.strategy == input.strategy).ok_or("prepared callback has no durable queue slot")?;
        if first.callback_id != input.callback_id || first.prepared.is_some() || input.snapshot().is_none() || first.event_sha256 != Self::hash(input)? { return Err("prepared callback changes or overtakes its queued input".into()); }
        self.slots.get_mut(&input.callback_id).expect("checked slot").prepared = Some(cursor);
        Ok(())
    }

    pub fn start_load(&mut self, state: &CallbackState, active: &std::collections::BTreeSet<StrategyId>) {
        if self.loading.is_some() || self.reader.is_none() { return; }
        let mut heads = BTreeMap::new();
        for slot in self.slots.values() { heads.entry(slot.strategy).or_insert(slot); }
        let mut choices: Vec<_> = heads.values().filter(|slot| active.contains(&slot.strategy) && !state.inputs.values().any(|input| input.strategy == slot.strategy)).copied().collect();
        if let Some(previous) = self.last_owner { let next = choices.partition_point(|slot| slot.strategy <= previous); choices.rotate_left(next); }
        let Some(slot) = choices.first() else { return; };
        let id = slot.callback_id;
        let cursor = slot.prepared.unwrap_or(slot.queued);
        let mut reader = self.reader.take().expect("available callback page reader");
        self.loading = Some(id);
        self.last_owner = Some(slot.strategy);
        let sender = self.sender.clone();
        tokio::task::spawn_blocking(move || { let input = reader.read_callback(cursor, id); let _ = sender.blocking_send(PageCompletion { reader, callback_id: id, input }); });
    }

    pub fn returned(&mut self, completion: PageCompletion, state: &mut CallbackState) -> Result<(), String> {
        if self.loading.take() != Some(completion.callback_id) || self.reader.is_some() { return Err("callback page completion has no reader owner".into()); }
        self.reader = Some(completion.reader);
        let input = completion.input.map_err(|error| error.to_string())?;
        let slot = self.slots.get(&completion.callback_id).ok_or("loaded callback lost its queue slot")?;
        if input.callback_id != slot.callback_id || input.strategy != slot.strategy || Self::hash(&input)? != slot.event_sha256 || input.snapshot().is_some() != slot.prepared.is_some() { return Err("callback page differs from its durable queue authority".into()); }
        state.accept(input)
    }

    pub fn replay(records: &[WalRecord], count: usize, segment: u64) -> Result<(CallbackState, Self), String> {
        let mut state = CallbackState::default();
        let mut pages = Self::default();
        for (index, record) in records.iter().enumerate() {
            let cursor = CallbackWalCursor { segment, sequence: index as u64 + 1, offset: 0 };
            match record {
                WalRecord::SegmentBase { strategy_processes, strategy_callbacks, strategy_callback_queues, .. } => {
                    state = CallbackState::default();
                    pages.slots.clear();
                    for process in strategy_processes { state.restore_process(process.clone(), count)?; }
                    for slot in strategy_callback_queues {
                        if slot.strategy.idx() >= count || slot.queued.segment == 0 || slot.queued.sequence == 0 || slot.prepared.is_some_and(|prepared| prepared.segment == 0 || prepared.sequence == 0) { return Err("invalid callback queue restatement".into()); }
                        state.next_id = state.next_id.max(slot.callback_id.checked_add(1).ok_or("callback identity exhausted")?);
                        pages.insert(slot.clone())?;
                    }
                    for input in strategy_callbacks {
                        state.validate_input(input, count)?;
                        state.retire_timer(input)?;
                        state.next_id = state.next_id.max(input.callback_id.checked_add(1).ok_or("callback identity exhausted")?);
                        pages.queued(input, cursor)?;
                    }
                }
                WalRecord::StrategyCallbackQueued { input } => {
                    state.validate_input(input, count)?;
                    CallbackState::size(input)?;
                    if input.callback_id < state.next_id || !matches!(input.preparation, CallbackPreparation::Queued) { return Err("callback queue reuses an identity or arrives prepared".into()); }
                    state.next_id = input.callback_id.checked_add(1).ok_or("callback identity exhausted")?;
                    state.retire_timer(input)?;
                    pages.queued(input, cursor)?;
                }
                WalRecord::StrategyCallbackPrepared { input } => { state.validate_input(input, count)?; pages.prepared(input, cursor)?; }
                WalRecord::StrategyProcessTransitionQueued { input_id, process, .. } => {
                    let slot = pages.slots.values().find(|slot| slot.strategy == process.strategy).ok_or("process commit has no queued callback")?;
                    if slot.callback_id != *input_id || process.last_callback_id != *input_id || slot.prepared.is_none() { return Err("process commit changes or overtakes callback authority".into()); }
                    pages.slots.remove(input_id);
                    state.restore_process(process.clone(), count)?;
                }
                _ => (),
            }
        }
        Ok((state, pages))
    }
}
