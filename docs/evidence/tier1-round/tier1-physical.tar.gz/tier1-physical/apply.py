from pathlib import Path
p=Path('engine/engine-core/src/reconcile.rs');s=p.read_text();s=s.replace('use crate::inflight::LedgerOfOrders;','use crate::inflight::LedgerOfOrders;\nuse engine_types::numeric::{Exact, ExecutionAmounts};\n\npub(crate) type PhysicalExposure = BTreeMap<SymbolId, Exact>;')
s=s.replace('fn side_of(signed_qty: f64) -> Option<Side> {\n    if signed_qty > QTY_EPS {','fn side_of(signed_qty: &Exact) -> Option<Side> {\n    if signed_qty.is_positive() {').replace('    } else if signed_qty < -QTY_EPS {','    } else if signed_qty.is_negative() {')
s=s.replace('    exposure: &mut BTreeMap<SymbolId, f64>,','    exposure: &mut PhysicalExposure,').replace('    qty: f64,\n) {\n    if !qty.is_finite() || qty <= 0.0 {\n        return;\n    }\n\n    let prior = exposure.get(&symbol).copied().unwrap_or(0.0);\n    let next = prior + signed(side, qty);\n    if side_of(next).is_none() {','    qty: &Exact,\n) -> Result<(), String> {\n    if !qty.is_positive() {\n        return Err("physical fill quantity must be positive".into());\n    }\n\n    let prior = exposure.get(&symbol).cloned().unwrap_or_default();\n    let next = &prior + &match side { Side::Buy => qty.clone(), Side::Sell => -qty };\n    next.validate_storage().map_err(|e| e.to_string())?;\n    next.to_f64().map_err(|e| e.to_string())?;\n    if side_of(&next).is_none() {')
s=s.replace('''        intended.remove(&symbol);
        return;
    }

    exposure.insert(symbol, next);
    let next_side = side_of(next).expect("non-flat quantity has a side");
    let crossed_or_opened = side_of(prior) != Some(next_side);
    let grew = next.abs() > prior.abs() + QTY_EPS;''','''        intended.remove(&symbol);
        return Ok(());
    }

    exposure.insert(symbol, next.clone());
    let next_side = side_of(&next).expect("non-flat quantity has a side");
    let crossed_or_opened = side_of(&prior) != Some(next_side);
    let grew = next.abs() > prior.abs();''')
s=s.replace('''        intended.remove(&symbol);
    }
}

fn matching_intended_stop''','''        intended.remove(&symbol);
    }
    Ok(())
}

pub(crate) fn fill_quantity(qty: f64, amounts: Option<&ExecutionAmounts>) -> Result<Exact, String> {
    let quantity = match amounts {
        Some(amounts) => {
            amounts.quantity.validate_provenance().map_err(|e| e.to_string())?;
            if amounts.quantity.value.to_f64().map_err(|e| e.to_string())? != qty {
                return Err("physical fill quantity disagrees with its exact amount".into());
            }
            amounts.quantity.value.clone()
        }
        None => Exact::from_legacy_f64(qty).map_err(|e| e.to_string())?,
    };
    if !quantity.is_positive() { return Err("physical fill quantity must be positive".into()); }
    Ok(quantity)
}

fn restored_exposure(rows: &[engine_types::SymbolTotal]) -> Result<PhysicalExposure, String> {
    let mut exposure = PhysicalExposure::new();
    let mut seen = std::collections::BTreeSet::new();
    for row in rows {
        if !seen.insert(row.symbol) { return Err("repeated physical exposure symbol".into()); }
        let quantity = row.exact_quantity().map_err(|e| e.to_string())?;
        if !quantity.is_zero() { exposure.insert(row.symbol, quantity); }
    }
    Ok(exposure)
}

pub(crate) fn snapshot_exposure(exposure: &PhysicalExposure) -> Vec<engine_types::SymbolTotal> {
    exposure.iter().map(|(symbol, quantity)| engine_types::SymbolTotal {
        symbol: *symbol,
        signed_qty: quantity.to_f64().expect("validated physical exposure projection"),
        exact_signed_qty: Some(engine_types::numeric::ExactNumber::derived(quantity.clone())),
    }).collect()
}

fn matching_intended_stop''')
s=s.replace('    exposure: &BTreeMap<SymbolId, f64>,','    exposure: &PhysicalExposure,').replace('side_of(exposure.get(&row.symbol).copied().unwrap_or(0.0))','exposure.get(&row.symbol).and_then(side_of)')
s=s.replace('type PositionState = (BTreeMap<SymbolId, f64>, BTreeMap<SymbolId, IntendedPositionStop>);','type PositionState = (PhysicalExposure, BTreeMap<SymbolId, IntendedPositionStop>);')
# Both ownership folds must apply non-venue portfolio transitions.
needle='''            WalRecord::ClaimsDropped { rows, .. } => claims.forget(rows),'''
replacement='''            WalRecord::PortfolioOffsetSettled { settlement } => {
                let prepared = claims.prepare_internal_settlement(settlement)?;
                claims.commit_internal_settlement(prepared)?;
            }
            WalRecord::SleeveStopSet { strategy, symbol, side, trigger_price, .. } => {
                claims.set_sleeve_stop_exact(*strategy, *symbol, *side, trigger_price.clone())?;
            }
'''+needle
assert s.count(needle)==2;s=s.replace(needle,replacement)
# Modify amounts only in the position-state match, not foreign_fills' ignored qty.
pos=s.index('fn position_state(');prefix=s[:pos];tail=s[pos:];tail=tail.replace('''                        qty,
                        forced_close,''','''                        qty,
                        amounts,
                        forced_close,''',1).replace('''                qty,
                forced_close,''','''                qty,
                amounts,
                forced_close,''',1)
tail=tail.replace('''                    note_owned_fill(&mut exposure, &mut intended, request, *symbol, *side, *qty);''','''                    let quantity = fill_quantity(*qty, amounts.as_deref())?;
                    note_owned_fill(&mut exposure, &mut intended, request, *symbol, *side, &quantity)?;''')
tail=tail.replace('side_of(exposure.get(symbol).copied().unwrap_or(0.0))','exposure.get(symbol).and_then(side_of)')
old='''.iter()
                    .filter(|row| row.signed_qty.is_finite() && row.signed_qty.abs() > QTY_EPS)
                    .map(|row| (row.symbol, row.signed_qty))
                    .collect();'''
assert tail.count(old)==2;tail=tail.replace('''logged_exposure
                    '''+old,'''logged_exposure_PLACEHOLDER;''').replace('''restated_exposure
                    '''+old,'''restated_exposure_PLACEHOLDER;''');tail=tail.replace('exposure = logged_exposure_PLACEHOLDER;','exposure = restored_exposure(logged_exposure)?;').replace('exposure = restated_exposure_PLACEHOLDER;','exposure = restored_exposure(restated_exposure)?;')
s=prefix+tail
s=s.replace('''    Ok(position_state(replayed)?.0)
}

/// The stop''','''    physical_exposure(replayed)?.into_iter().map(|(symbol, quantity)| quantity.to_f64().map(|quantity| (symbol, quantity)).map_err(|e| e.to_string())).collect()
}

pub(crate) fn physical_exposure(replayed: &[WalRecord]) -> Result<PhysicalExposure, String> {
    Ok(position_state(replayed)?.0)
}

/// The stop''')
s=s.replace('''        let logged_qty = logged.get(&position.symbol).copied().unwrap_or(0.0);
        if (venue_qty - logged_qty).abs() > tolerance(qty_step_of(position.symbol)) {''','''        let logged_qty = logged.get(&position.symbol).map(|qty| qty.to_f64()).transpose().map_err(|e| e.to_string())?.unwrap_or(0.0);
        if (venue_qty != 0.0 && !logged.contains_key(&position.symbol))
            || (venue_qty - logged_qty).abs() > tolerance(qty_step_of(position.symbol)) {''')
p.write_text(s)
# Engine canonical physical state and snapshot.
p=Path('engine/engine-core/src/engine.rs');s=p.read_text().replace('logged_exposure: std::collections::BTreeMap<SymbolId, f64>','logged_exposure: crate::reconcile::PhysicalExposure');start=s.index('            logged_exposure: self\n');end=s.index('            intended_stops:',start);s=s[:start]+'            logged_exposure: crate::reconcile::snapshot_exposure(&self.logged_exposure),\n'+s[end:];p.write_text(s)
p=Path('engine/engine-core/src/engine/boot_recovery.rs');s=p.read_text().replace('crate::reconcile::logged_exposure(effective)','crate::reconcile::physical_exposure(effective)');s=s.replace('''                    exec.qty,
                );
                if let Some(request)''','''                    &reconcile::fill_quantity(exec.qty, exec.amounts.as_ref()).map_err(EngineError::State)?,
                ).map_err(EngineError::State)?;
                if let Some(request)''');p.write_text(s)
p=Path('engine/engine-core/src/engine/venue_completion.rs');s=p.read_text();needle='''        // Only fills joined to orders this log sent enter trusted exposure.''';i=s.index(needle);before=s[:i];after=s[i:];after=after.replace('''                symbol, side, qty, ..''','''                symbol, side, qty, amounts, ..''',1).replace('''                *qty,
            );''','''                &reconcile::fill_quantity(*qty, amounts.as_deref()).map_err(EngineError::State)?,
            ).map_err(EngineError::State)?;''',1);p.write_text(before+after)
