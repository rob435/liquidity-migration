import re,sys
from pathlib import Path
log=Path(sys.argv[1] if len(sys.argv) > 1 else '/tmp/tier1-next-effects/order-callback-schema-check.log').read_text()
edits={}
for match in re.finditer(r'error\[(E0063|E0027)\]:[^\n]*`callbacks`[^\n]*\n\s*--> ([^:]+):(\d+):(\d+)',log):
 kind,file,line,col=match.groups();p=Path('engine')/file;s=p.read_text();line=int(line);rows=s.splitlines(True);start=sum(map(len,rows[:line-1]));chunk=s[start:start+250]
 m=re.search(r'(?:engine_types::)?WalRecord::OrderUpdate\s*\{',chunk)
 if not m: raise RuntimeError((p,line,chunk))
 at=start+m.end()
 edits.setdefault(p,set()).add((at, ' callbacks: None, ' if kind=='E0063' else ' callbacks: _, '))
for p,points in edits.items():
 s=p.read_text()
 for at,value in sorted(points,reverse=True):s=s[:at]+value+s[at:]
 p.write_text(s)
 print(p,len(points))
