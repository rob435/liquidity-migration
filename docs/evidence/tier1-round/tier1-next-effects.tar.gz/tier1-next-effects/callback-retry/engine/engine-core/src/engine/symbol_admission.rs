use super::*;
use engine_types::identity::IdentityError;
use engine_types::orders::{InstrumentCatalog, InstrumentCatalogClient};
use std::sync::Arc;
use tokio::sync::oneshot;

#[derive(Debug, thiserror::Error)]
pub(super) enum AdmissionFailure {
    #[error(transparent)]
    Identity(IdentityError),
    #[error("instrument catalog unavailable: {0}")]
    Catalog(VenueError),
    #[error("venue symbol installation unavailable: {0}")]
    Install(VenueError),
}

enum Phase {
    Idle,
    Fetching(tokio::task::JoinHandle<Result<InstrumentCatalog, VenueError>>),
    Installing {
        wanted: Vec<WantedSymbol>,
        expected: Vec<SymbolId>,
        receive: oneshot::Receiver<Result<Vec<Option<SymbolId>>, VenueError>>,
    },
}

pub(super) struct SymbolAdmission {
    catalog: InstrumentCatalog,
    client: Option<Arc<dyn InstrumentCatalogClient>>,
    installed: bool,
    phase: Phase,
    retry_after_ns: u64,
    pub(super) failure: Option<AdmissionFailure>,
}

impl SymbolAdmission {
    pub(super) fn new(
        catalog: InstrumentCatalog,
        client: Option<Arc<dyn InstrumentCatalogClient>>,
    ) -> Self {
        Self { catalog, client, installed: true, phase: Phase::Idle, retry_after_ns: 0, failure: None }
    }

    pub(super) fn contains(&self, name: &str) -> bool {
        matches!(&self.phase, Phase::Installing { wanted, .. } if wanted.iter().any(|row| row.name == name))
    }

    pub(super) fn busy(&self) -> bool { !matches!(self.phase, Phase::Idle) }

    fn refuse(&mut self, failure: AdmissionFailure) {
        if self.failure.as_ref().map(ToString::to_string) != Some(failure.to_string()) {
            tracing::warn!(%failure, "symbol admission retained; existing symbols remain usable");
        }
        self.failure = Some(failure);
    }
}

impl Drop for SymbolAdmission {
    fn drop(&mut self) {
        if let Phase::Fetching(task) = &self.phase { task.abort(); }
    }
}

impl<W: Wal, R: RiskKernel, V: VenueGateway> Engine<W, R, V> {
    pub(super) async fn admit_wanted<M: MarketFeed, O: OrderFeed>(
        &mut self, market_feed: &mut M, order_feed: &mut O,
    ) -> Result<(), EngineError> {
        match std::mem::replace(&mut self.symbol_admission.phase, Phase::Idle) {
            Phase::Fetching(task) if !task.is_finished() => {
                self.symbol_admission.phase = Phase::Fetching(task);
                return Ok(());
            }
            Phase::Fetching(task) => {
                match task.await {
                    Ok(Ok(catalog)) => {
                        self.symbol_admission.catalog = catalog;
                        self.symbol_admission.installed = false;
                        self.symbol_admission.failure = None;
                    }
                    result => {
                        let error = match result {
                            Ok(Err(error)) => error,
                            Err(error) => VenueError::Transport(error.to_string()),
                            _ => unreachable!(),
                        };
                        self.symbol_admission.refuse(AdmissionFailure::Catalog(error));
                        self.symbol_admission.retry_after_ns = clock::now_ns().saturating_add(1_000_000_000);
                    }
                }
            }
            Phase::Installing { wanted, expected, mut receive } => {
                match receive.try_recv() {
                    Err(oneshot::error::TryRecvError::Empty) => {
                        self.symbol_admission.phase = Phase::Installing { wanted, expected, receive };
                        return Ok(());
                    }
                    result => {
                        let result = match result {
                            Ok(result) => result,
                            Err(error) => Err(VenueError::Transport(error.to_string())),
                        };
                        let actual = match result {
                            Ok(actual) => actual,
                            Err(error) => {
                                self.symbol_admission.refuse(AdmissionFailure::Install(error));
                                self.symbol_admission.retry_after_ns = clock::now_ns().saturating_add(1_000_000_000);
                                self.wanted_symbols.splice(0..0, wanted);
                                return Ok(());
                            }
                        };
                        if actual.len() != expected.len() || actual.iter().zip(&expected).any(|(actual, expected)| *actual != Some(*expected)) {
                            return Err(EngineError::State("venue symbol installation disagrees with durable identity ids".into()));
                        }
                        for (wanted, expected) in wanted.into_iter().zip(expected) {
                            let core_id = self.books.market.add_symbol(&wanted.name);
                            if core_id != expected {
                                return Err(EngineError::State("core symbol table disagrees with durable identity ids".into()));
                            }
                            for (_, feed) in &wanted.listeners {
                                if market_feed.admit(&wanted.name, *feed) != Some(expected) {
                                    return Err(EngineError::State(format!("market feed id for {} differs from durable identity {}", wanted.name, expected.0)));
                                }
                            }
                            order_feed.learn(&wanted.name, expected);
                            self.routing.size_to(self.books.market.table.len());
                            for (strategy, feed) in wanted.listeners {
                                self.routing.add(expected, feed, strategy);
                                let subscription = Subscription { symbol: wanted.name.clone(), feed };
                                if !self.subscriptions.contains(&subscription) { self.subscriptions.push(subscription); }
                            }
                        }
                        self.symbol_admission.installed = true;
                        self.symbol_admission.failure = None;
                        let names = names_record(&self.host.names, &self.books.market);
                        self.wal.append(&names)?;
                        self.fills.learn(&names);
                    }
                }
            }
            Phase::Idle => {}
        }
        self.books.rules.resize(self.books.market.table.len(), None);
        for (name, rule) in &self.symbol_admission.catalog.rules {
            if let Some(symbol) = self.books.market.table.get(name) { self.books.rules[symbol.idx()] = Some(*rule); }
        }
        for (name, spec) in &self.symbol_admission.catalog.specs {
            if let Some(symbol) = self.books.market.table.get(name) {
                order_feed.learn_instrument(symbol, spec);
                self.instrument_specs.insert(symbol, spec.clone());
            }
        }
        if self.wanted_symbols.is_empty() || clock::now_ns() < self.symbol_admission.retry_after_ns { return Ok(()); }
        let mut ready = Vec::new();
        let mut missing_metadata = false;
        let mut available_ids = engine_types::identity::DENSE_ID_CAPACITY.saturating_sub(self.identities.instruments.len());
        for wanted in std::mem::take(&mut self.wanted_symbols) {
            let known = self.identities.instruments.iter().any(|binding| binding.symbol == wanted.name);
            if !known && available_ids == 0 {
                self.symbol_admission.refuse(AdmissionFailure::Identity(IdentityError::SymbolIdsExhausted));
                self.wanted_symbols.push(wanted);
                continue;
            }
            let rule = self.symbol_admission.catalog.rules.iter().any(|(name, _)| name == &wanted.name);
            let spec = self.symbol_admission.catalog.specs.iter().any(|(name, _)| name == &wanted.name);
            if !rule || (self.require_exact_instruments && !spec) {
                self.symbol_admission.refuse(AdmissionFailure::Identity(IdentityError::UnresolvedInstrument(wanted.name.clone())));
                self.wanted_symbols.push(wanted);
                missing_metadata = true;
                continue;
            }
            if !known { available_ids -= 1; }
            ready.push(wanted);
        }
        if ready.is_empty() {
            if missing_metadata {
                if let Some(client) = &self.symbol_admission.client {
                    let client = Arc::clone(client);
                    self.symbol_admission.phase = Phase::Fetching(tokio::spawn(async move { client.fetch().await }));
                }
                self.symbol_admission.retry_after_ns = clock::now_ns().saturating_add(1_000_000_000);
            }
            return Ok(());
        }
        let native_symbols = self.symbol_admission.catalog.specs.iter().map(|(name, spec)| (name.clone(), spec.native_symbol.clone())).collect();
        let requested = ready.iter().map(|wanted| wanted.name.clone()).collect::<Vec<_>>();
        let plan = match crate::identities::plan_identities(
            &[WalRecord::IdentityState { wall_ts_ms: clock::wall_ms(), state: self.identities.clone() }],
            &self.host.names, None, &native_symbols, &requested,
        ) {
            Ok(plan) => plan,
            Err(error) => {
                self.symbol_admission.refuse(AdmissionFailure::Identity(error));
                self.wanted_symbols.splice(0..0, ready);
                return Ok(());
            }
        };
        if plan.changed {
            self.wal.append(&WalRecord::IdentityState { wall_ts_ms: clock::wall_ms(), state: plan.state.clone() })?;
            self.wal.barrier()?;
            self.identities = plan.state;
        }
        ready.sort_by_key(|wanted| self.identities.instruments.iter().position(|binding| binding.symbol == wanted.name));
        let expected = ready.iter().map(|wanted| {
            self.identities.instruments.iter().position(|binding| binding.symbol == wanted.name)
                .map(|index| SymbolId(index as u16)).expect("planned symbol identity")
        }).collect();
        let catalog = (!self.symbol_admission.installed && self.symbol_admission.catalog.cache.is_some()).then(|| self.symbol_admission.catalog.clone());
        match self.venue.dispatch_symbol_admission(catalog, ready.iter().map(|wanted| wanted.name.clone()).collect()) {
            Ok(receive) => self.symbol_admission.phase = Phase::Installing { wanted: ready, expected, receive },
            Err(error) => {
                self.symbol_admission.refuse(AdmissionFailure::Install(error));
                self.symbol_admission.retry_after_ns = clock::now_ns().saturating_add(1_000_000_000);
                self.wanted_symbols.splice(0..0, ready);
            }
        }
        Ok(())
    }
}

#[cfg(test)]
#[path = "symbol_admission_tests.rs"]
mod tests;
