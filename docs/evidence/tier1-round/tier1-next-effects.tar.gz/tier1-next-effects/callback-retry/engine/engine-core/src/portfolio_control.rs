use std::collections::{BTreeMap, BTreeSet};
use engine_types::{StrategyId, SymbolId, WalRecord};
use engine_types::portfolio_control::*;

#[derive(Clone, Debug, Default)]
pub(crate) struct PortfolioControls {
    next_id: u64,
    pub exits: BTreeMap<(StrategyId, SymbolId), PortfolioExit>,
    pub emergencies: BTreeMap<SymbolId, PortfolioEmergency>,
}

impl PortfolioControls {
    pub fn replay(records: &[WalRecord]) -> Result<Self, String> {
        let mut book = Self { next_id: 1, ..Default::default() };
        for record in records { book.apply(record)?; }
        Ok(book)
    }
    pub fn next_id(&self) -> Result<u64, String> {
        if self.next_id == 0 || self.next_id == u64::MAX { return Err("portfolio control ID capacity exhausted".into()); }
        Ok(self.next_id)
    }
    pub fn snapshot(&self) -> PortfolioControlState {
        PortfolioControlState { schema_version: 1, next_id: self.next_id,
            exits: self.exits.values().cloned().collect(), emergencies: self.emergencies.values().cloned().collect() }
    }
    pub fn blocked(&self, strategy: StrategyId, symbol: SymbolId) -> bool {
        self.exits.contains_key(&(strategy, symbol)) || self.emergencies.contains_key(&symbol)
    }
    pub fn apply(&mut self, record: &WalRecord) -> Result<(), String> {
        match record {
            WalRecord::SegmentBase { portfolio_control: state, .. } => {
                if state.schema_version != 1 || state.next_id == 0 { return Err("invalid portfolio control snapshot".into()); }
                let mut next = Self { next_id: 1, ..Default::default() };
                let mut ids = BTreeSet::new();
                for exit in &state.exits {
                    validate_exit(exit)?;
                    if exit.id >= state.next_id || !ids.insert(exit.id) || next.exits.insert((exit.strategy, exit.symbol), exit.clone()).is_some() {
                        return Err("duplicate or unallocated portfolio exit in rotation".into());
                    }
                }
                for emergency in &state.emergencies {
                    validate_emergency(emergency)?;
                    if emergency.id >= state.next_id || !ids.insert(emergency.id) || next.emergencies.insert(emergency.symbol, emergency.clone()).is_some() {
                        return Err("duplicate or unallocated portfolio emergency in rotation".into());
                    }
                }
                next.next_id = state.next_id;
                *self = next;
            }
            WalRecord::PortfolioExitChanged { state } => {
                validate_exit(state)?;
                let key = (state.strategy, state.symbol);
                if let Some(old) = self.exits.get(&key) {
                    if state.id != old.id || state.trigger_price != old.trigger_price || state.started_ms != old.started_ms || state.attempt < old.attempt {
                        return Err("portfolio exit changed its identity or moved backward".into());
                    }
                } else { self.allocate(state.id)?; }
                self.exits.insert(key, state.clone());
            }
            WalRecord::PortfolioExitCompleted { id, strategy, symbol } => {
                if self.exits.get(&(*strategy, *symbol)).map(|state| state.id) != Some(*id) { return Err("portfolio exit completion has no active owner".into()); }
                self.exits.remove(&(*strategy, *symbol));
            }
            WalRecord::PortfolioEmergencyChanged { state } => {
                validate_emergency(state)?;
                if let Some(old) = self.emergencies.get(&state.symbol) {
                    if state.id != old.id || state.reason != old.reason || state.started_ms != old.started_ms || state.attempt < old.attempt {
                        return Err("portfolio emergency changed its identity or moved backward".into());
                    }
                    let legal = old.phase == state.phase || matches!((old.phase, state.phase),
                        (PortfolioEmergencyPhase::ResolveOrders, PortfolioEmergencyPhase::CloseNet)
                        | (PortfolioEmergencyPhase::CloseNet, PortfolioEmergencyPhase::SettleOffsets)
                        | (PortfolioEmergencyPhase::SettleOffsets, PortfolioEmergencyPhase::ResolveOrders));
                    if !legal { return Err("portfolio emergency skipped order resolution".into()); }
                } else {
                    if state.phase != PortfolioEmergencyPhase::ResolveOrders { return Err("portfolio emergency must start by resolving orders".into()); }
                    self.allocate(state.id)?;
                }
                self.emergencies.insert(state.symbol, state.clone());
            }
            WalRecord::PortfolioEmergencyCompleted { id, symbol } => {
                if self.emergencies.get(symbol).map(|state| state.id) != Some(*id) { return Err("portfolio emergency completion has no active owner".into()); }
                self.emergencies.remove(symbol);
            }
            WalRecord::PortfolioOffsetSettled { settlement } => {
                let Some(emergency) = self.emergencies.get(&settlement.symbol) else { return Err("internal settlement has no active emergency".into()); };
                if emergency.id != settlement.emergency_id || emergency.phase != PortfolioEmergencyPhase::SettleOffsets { return Err("internal settlement overtook physical close".into()); }
                validate_settlement(settlement)?;
            }
            _ => (),
        }
        Ok(())
    }
    fn allocate(&mut self, id: u64) -> Result<(), String> {
        if id != self.next_id()? { return Err("portfolio control ID is not the next durable identity".into()); }
        self.next_id += 1;
        Ok(())
    }
}

fn validate_order_id(id: &Option<String>, attempt: u32) -> Result<(), String> {
    if id.as_ref().is_some_and(|id| id.is_empty() || id.len() > 128 || attempt == 0) { return Err("invalid portfolio order attempt".into()); }
    Ok(())
}
fn validate_exit(state: &PortfolioExit) -> Result<(), String> {
    if state.id == 0 || !state.trigger_price.is_positive() { return Err("invalid portfolio exit identity or trigger".into()); }
    state.trigger_price.validate_storage().map_err(|e| e.to_string())?;
    validate_order_id(&state.order_id, state.attempt)
}
fn validate_emergency(state: &PortfolioEmergency) -> Result<(), String> {
    if state.id == 0 || !state.reference_price.is_positive() { return Err("invalid portfolio emergency identity or reference".into()); }
    state.reference_price.validate_storage().map_err(|e| e.to_string())?;
    validate_order_id(&state.order_id, state.attempt)
}
pub(crate) fn validate_settlement(settlement: &PortfolioOffsetSettlement) -> Result<(), String> {
    if settlement.emergency_id == 0 || !settlement.price.is_positive() || settlement.slices.len() < 2 { return Err("invalid internal settlement".into()); }
    settlement.price.validate_storage().map_err(|e| e.to_string())?;
    let mut by_asset = BTreeMap::<_, engine_types::numeric::Exact>::new();
    let mut owners = BTreeSet::new();
    for slice in &settlement.slices {
        slice.signed_quantity.validate_storage().map_err(|e| e.to_string())?;
        if slice.signed_quantity.is_zero() || !owners.insert(slice.strategy) { return Err("invalid internal settlement ownership".into()); }
        *by_asset.entry(slice.settlement_asset.clone()).or_default() += &slice.signed_quantity;
    }
    if by_asset.values().any(|net| !net.is_zero()) { return Err("internal settlement is not balanced in each asset".into()); }
    Ok(())
}
