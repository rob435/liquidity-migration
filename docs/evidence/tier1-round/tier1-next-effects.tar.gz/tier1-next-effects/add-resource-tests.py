from pathlib import Path
root=Path('/tmp/tier1-next-effects/callback-bounds/engine')
p=root/'engine-core/src/strategy_process/state.rs';s=p.read_text();s+='''
#[cfg(test)]
mod complete_process_budget_tests {
    use super::*;
    use engine_types::strategy_process::{CallbackSnapshot, StrategyRuntimeState};

    fn input(id: u64, strategy: u16) -> StrategyCallbackInput {
        let strategy = StrategyId(strategy);
        StrategyCallbackInput { callback_id: id, strategy, event: CallbackEvent::Boot,
            preparation: CallbackPreparation::Prepared { snapshot: CallbackSnapshot {
                strategy, now_ns: 1, wall_ms: 1, entries_enabled: true,
                account: engine_types::StrategyAccountSummary { equity_usdt: 1.0, available_margin_usdt: 1.0, observed_ns: 1 },
                symbols: Vec::new(), orders: Vec::new(), global_checkpoint: None,
                strategy_names: Vec::new(), strategy_events: Vec::new(),
            } },
        }
    }

    #[test]
    fn retained_route_manifests_share_the_complete_process_budget() {
        let mut state = CallbackState::default();
        let process = |id, strategy| StrategyProcessState {
            strategy: StrategyId(strategy), last_callback_id: id,
            runtime: StrategyRuntimeState { schema_version: 1, kind: "test".into(), configuration_sha256: "0".repeat(64), payload: Vec::new() },
            timers: Vec::new(),
            retained_signal_subscriptions: Some(vec![engine_types::Subscription { symbol: "x".repeat(MAX_PROCESS_PROPOSAL_BYTES / 2), feed: engine_types::Feed::Quote }]),
        };
        state.accept(input(0, 0)).unwrap();
        state.commit(0, process(0, 0)).unwrap();
        state.accept(input(1, 1)).unwrap();
        assert!(state.commit(1, process(1, 1)).is_err(), "route manifests escaped the aggregate committed-state budget");
        assert_eq!(state.committed.len(), 1);
        assert!(state.inputs.contains_key(&1));
    }

    #[test]
    fn prepared_snapshots_share_a_budget_separate_from_the_inbox() {
        let mut state = CallbackState::default();
        let mut first = input(0, 0);
        let mut second = input(1, 1);
        for input in [&mut first, &mut second] {
            let CallbackPreparation::Prepared { snapshot } = &mut input.preparation else { unreachable!() };
            snapshot.strategy_names = vec!["x".repeat(MAX_PROCESS_PROPOSAL_BYTES / 2)];
        }
        state.accept(first).unwrap();
        assert!(state.accept(second).is_err(), "prepared snapshots each obtained a new aggregate budget");
        assert_eq!(state.inputs.len(), 1);
    }
}
''';p.write_text(s)
p=root/'engine-core/src/engine/strategy_callbacks.rs';s=p.read_text();needle='            records.lock().unwrap().clear();\n            engine.on_strategy_callback(Some(completion)).unwrap();';repl='''            if exceeds {
                proposal.actions.push(Action::SetStrategyGlobalCheckpoint { strategy: StrategyId(0), checkpoint: engine_types::StrategyCheckpoint { schema_version: 1, decision_fingerprint: "retained-budget".into(), payload: vec![1] } });
                proposal.actions.push(Action::Cancel { symbol: SymbolId(0), client_order_id: "required-effect-suffix".into() });
            }
            records.lock().unwrap().clear();
            engine.on_strategy_callback(Some(completion)).unwrap();''';assert needle in s;s=s.replace(needle,repl,1);p.write_text(s)
