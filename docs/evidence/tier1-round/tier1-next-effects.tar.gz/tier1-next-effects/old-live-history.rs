    pub(super) async fn checkpoint_history_if_due(&mut self) -> Result<(), EngineError> {
        if clock::wall_ms() < self.next_history_checkpoint_ms {
            return Ok(());
        }
        self.renew_execution_history().await
    }

    pub(crate) async fn renew_execution_history(&mut self) -> Result<(), EngineError> {
        self.recover_history("while renewing the durable execution-history checkpoint")
            .await
    }

    /// After a private-stream gap: ask the venue what traded while the stream
    /// was away. The same pass also renews the quiet-run checkpoint.
    pub(super) async fn recover_gap_fills(&mut self) -> Result<(), EngineError> {
        self.recover_history("after a private-stream gap").await
    }

    /// Fold one complete execution-history interval through the ordinary fill
    /// books, then write its boundary after every returned row. Failure stops
    /// the run: advancing without the read would make the next boot trust a
    /// hole, and continuing until the venue forgets it would make repair
    /// impossible.
    async fn recover_history(&mut self, context: &str) -> Result<(), EngineError> {
        let now_ms = clock::wall_ms();
        let since = (self.recovered_until_ms - RECOVERY_PAD_MS).max(now_ms - RECOVERY_REACH_MS);
        if since >= now_ms {
            self.next_history_checkpoint_ms = now_ms.saturating_add(HISTORY_CHECKPOINT_INTERVAL_MS);
            return Ok(());
        }
        let mut execs = match self.venue.executions(since, now_ms).await {
            Ok(execs) => execs,
            Err(error) => {
                self.may_open = false;
                self.wal.append(&WalRecord::Reconciled {
                    wall_ts_ms: now_ms,
                    findings: vec![format!(
                        "execution history is unavailable {context}: {error}"
                    )],
                    may_open: false,
                })?;
                self.wal.barrier()?;
                return Err(EngineError::Venue(error));
            }
        };
        execs.sort_by_key(|exec| exec.venue_ts_ms);
        let mut delivered_counts: std::collections::HashMap<(String, i64, u64), usize> =
            std::collections::HashMap::new();
        for (id, ts, qty) in &self.recent_fills {
            *delivered_counts
                .entry((id.clone(), *ts, qty.to_bits()))
                .or_default() += 1;
        }
        let mut recovered = 0usize;
        let mut foreign = Vec::new();
        for exec in execs {
            if self.recovered_exec_ids.contains(&exec.exec_id, now_ms) {
                continue;
            }
            let key = (
                exec.client_order_id.clone(),
                exec.venue_ts_ms,
                exec.qty.to_bits(),
            );
            let same_delivered = delivered_counts.get_mut(&key).is_some_and(|count| {
                if *count == 0 {
                    false
                } else {
                    *count -= 1;
                    true
                }
            });
            if same_delivered {
                continue;
            }
            self.recovered_exec_ids
                .can_insert(&exec.exec_id, now_ms)
                .map_err(|e| EngineError::State(e.to_string()))?;
            let Some(symbol) = self.books.market.table.get(&exec.symbol) else {
                let finding = Self::foreign_unmapped_execution_line(
                    &exec.exec_id,
                    &exec.client_order_id,
                    &exec.symbol,
                    exec.qty,
                );
                self.wal.append(&WalRecord::Note {
                    source: "fill-recovery".into(),
                    text: finding.clone(),
                })?;
                self.recovered_exec_ids.insert(exec.exec_id, now_ms);
                foreign.push(finding);
                recovered += 1;
                continue;
            };
            if let Err(reason) = self
                .books
                .orders
                .validate_fill(&exec.client_order_id, symbol, exec.side, exec.qty, exec.px)
                .and_then(|()| self.books.orders.validate_fill_quantities(&exec.client_order_id, exec.qty, exec.amounts.as_ref()))
                .and_then(|()| {
                    exec.amounts.as_ref().map_or(Ok(()), |values| {
                        values
                            .validate_projection(exec.qty, exec.px, exec.fee)
                            .map_err(|error| error.to_string())
                    })
                })
            {
                foreign.push(Self::untrusted_fill_line(
                    &exec.exec_id,
                    &exec.client_order_id,
                    symbol,
                    exec.side,
                    exec.qty,
                    exec.px,
                    &reason,
                ));
                self.recovered_exec_ids.insert(exec.exec_id, now_ms);
                recovered += 1;
                continue;
            }
            let mut record = WalRecord::RecoveredFill {
                allocation: None,
                amounts: exec.amounts.clone(),
                exec_id: exec.exec_id.clone(),
                client_order_id: exec.client_order_id.clone(),
                symbol,
                side: exec.side,
                qty: exec.qty,
                px: exec.px,
                fee: exec.fee,
                is_maker: exec.is_maker,
                forced_close: exec.forced_close,
                venue_ts_ms: exec.venue_ts_ms,
                recovered_wall_ts_ms: now_ms,
            };
            let owner = self.books.orders.owner_of(&exec.client_order_id);
            let owned_request = self
                .books
                .orders
                .orders
                .get(&exec.client_order_id)
                .map(|order| order.request.clone());
            let allocation = match self.books.attribution.prepare_portfolio_recovered_for_order(
                owned_request.as_ref(),
                &self.host.names,
                &record,
            ) {
                Ok(allocation) => allocation,
                Err(reason) => {
                    foreign.push(Self::untrusted_fill_line(
                        &exec.exec_id,
                        &exec.client_order_id,
                        symbol,
                        exec.side,
                        exec.qty,
                        exec.px,
                        &reason,
                    ));
                    self.recovered_exec_ids.insert(exec.exec_id, now_ms);
                    recovered += 1;
                    continue;
                }
            };
            if let (
                Some(prepared),
                WalRecord::RecoveredFill {
                    allocation: recorded,
                    ..
                },
            ) = (&allocation, &mut record)
            {
                if prepared.allocation.policy
                    == engine_types::execution_allocation::AllocationPolicy::EmergencyNetFifo
                {
                    *recorded = Some(Box::new(prepared.allocation.clone()));
                }
            }
            let owned = allocation.is_some();
            self.wal.append(&record)?;
            if let Some(allocation) = allocation {
                self.books
                    .attribution
                    .commit_portfolio_fill(allocation)
                    .map_err(EngineError::State)?;
            }
            self.recovered_exec_ids.insert(exec.exec_id.clone(), now_ms);
            self.books.orders.try_apply(&record).map_err(EngineError::State)?;
            self.portfolio_controls.apply(&record).map_err(EngineError::State)?;
            self.portfolio_physical_after.insert(symbol, clock::now_ns());
        self.portfolio_controls.retain_native_offsets(&self.books.attribution.snapshot());
            if owned {
                reconcile::note_owned_fill(
                    &mut self.logged_exposure,
                    &mut self.intended_stops,
                    owned_request.as_ref(),
                    symbol,
                    exec.side,
                    &reconcile::fill_quantity(exec.qty, exec.amounts.as_ref()).map_err(EngineError::State)?,
                ).map_err(EngineError::State)?;
                if let Some(request) = owned_request.as_ref() {
                    self.books.attribution.remember_order_stop(request);
                }
                // What it cost is the same question whichever way it arrived,
                // and the anchor is the book its own order left at.
                let late_ns = now_ms
                    .saturating_sub(exec.venue_ts_ms)
                    .max(0)
                    .saturating_mul(1_000_000) as u64;
                // Dated to when it traded, not to when it was found, or a
                // trade from minutes ago is marked against this minute's book
                // and the number is read as a one-second fact.
                let update =
                    crate::portfolio_allocation::recovered_update(&record, clock::now_ns())
                        .expect("recovered fill");
                let slices = crate::portfolio_allocation::slice_updates(&update)
                    .map_err(EngineError::State)?
                    .unwrap_or_else(|| owner.map(|sid| vec![(sid, update)]).unwrap_or_default());
                for (sid, update) in slices {
                    let OrderUpdate::Fill { qty, fee, .. } = update else {
                        unreachable!()
                    };
                    self.fills.on_recovered_fill(
                        &execution::Fill {
                            client_order_id: exec.client_order_id.clone(),
                            strategy: sid,
                            symbol,
                            side: exec.side,
                            qty,
                            px: exec.px,
                            fee,
                            is_maker: exec.is_maker,
                            arrival_mid: self.arrival_mid_of(&exec.client_order_id),
                            venue_ts_ms: exec.venue_ts_ms,
                        },
                        clock::now_ns().checked_sub(late_ns),
                    );
                }
            } else {
                foreign.push(Self::foreign_fill_line(&exec.client_order_id, symbol));
            }
            // The kernel reserved this order's size when it approved it, and
            // only a fill releases the reservation. Skipping it here leaves the
            // position counted twice — once as a reservation that never ends,
            // once in the account view — and every later entry judged against
            // the sum.
            self.update_risk_from_canonical_order(&OrderUpdate::Fill {
                allocation: None,
                amounts: exec.amounts.clone().map(Box::new),
                exec_id: exec.exec_id.clone(),
                client_order_id: exec.client_order_id.clone(),
                symbol,
                side: exec.side,
                qty: exec.qty,
                px: exec.px,
                fee: exec.fee,
                is_maker: exec.is_maker,
                forced_close: exec.forced_close,
                venue_ts_ms: exec.venue_ts_ms,
                // The engine's own clock, not the venue's: `recv_ns` is what
                // the kernel compares against the account view's stamp, and the
                // two must come from one clock.
                recv_ns: clock::now_ns(),
            })?;
            if self.books.orders.orders.get(&exec.client_order_id).is_some_and(|order| !order.in_flight()) {
                self.risk.complete_order(&exec.client_order_id, clock::now_ns());
            }
            recovered += 1;
        }
        if recovered > 0 {
            tracing::warn!(count = recovered, "recovered fills from execution history");
        }
        if !foreign.is_empty() {
            self.may_open = false;
            self.wal.append(&WalRecord::Reconciled {
                wall_ts_ms: now_ms,
                findings: foreign,
                may_open: false,
            })?;
        }
        self.wal.append(&WalRecord::ExecutionHistoryCheckpoint {
            through_wall_ts_ms: now_ms,
        })?;
        self.wal.barrier()?;
        self.recovered_until_ms = now_ms;
        self.next_history_checkpoint_ms = now_ms.saturating_add(HISTORY_CHECKPOINT_INTERVAL_MS);
        Ok(())
    }

