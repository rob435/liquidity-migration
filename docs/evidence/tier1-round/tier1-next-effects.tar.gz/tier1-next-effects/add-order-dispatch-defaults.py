from pathlib import Path
import re
changed=[]
for p in Path('engine').rglob('*.rs'):
 if 'target' in p.parts: continue
 s=p.read_text(); edits=[]
 for m in re.finditer(r'WalRecord::OrderSent\s*\{',s):
  start=m.end(); depth=1; i=start; top=[]; quote=False; line=False; block=0
  while i<len(s) and depth:
   ch=s[i]; nx=s[i:i+2]
   if line:
    if ch=='\n':line=False
   elif block:
    if nx=='/*': block+=1;i+=1
    elif nx=='*/':block-=1;i+=1
   elif quote:
    if ch=='\\':i+=1
    elif ch=='"':quote=False
   elif nx=='//':line=True;i+=1
   elif nx=='/*':block=1;i+=1
   elif ch=='"':quote=True
   elif ch=='{':depth+=1
   elif ch=='}':depth-=1
   elif depth==1:top.append(ch)
   i+=1
  if depth:raise RuntimeError(p)
  text=''.join(top)
  if re.search(r'\bdispatch\s*:',text) or '..' in text:continue
  indent=re.search(r'\n([ \t]*)\S',s[start:i-1])
  indent=indent.group(1) if indent else ''
  if re.search(r'\b(request|wire_ns|arrival_mid)\s*:',text):
   insertion='\n'+indent+'dispatch: None,' if indent else ' dispatch: None,'
   edits.append((start,insertion))
  else:
   before=s[start:i-1].rstrip()
   edits.append((i-1, ('' if before.endswith(',') else ',')+' .. '))
 if edits:
  for at,value in reversed(edits):s=s[:at]+value+s[at:]
  p.write_text(s);changed.append((str(p),len(edits)))
print(changed)
