from pathlib import Path
p=Path('engine/engine-types/src/wal.rs');s=p.read_text();needle='    StrategyCallbackQueued {\n';s=s.replace(needle,'''    StrategyCallbackSource {
        strategy: StrategyId,
        event: crate::strategy_process::CallbackEvent,
    },
'''+needle,1);p.write_text(s)
p=Path('engine/engine-types/src/strategy_process.rs');s=p.read_text().replace('pub source: Option<(Vec<StrategyId>, OrderUpdate)>,','pub source: Option<(Vec<StrategyId>, CallbackEvent)>,');p.write_text(s)
p=Path('engine/engine-core/src/strategy_process/order_news.rs');s=p.read_text();s=s.replace('            if let WalRecord::OrderUpdate { callbacks: Some(owners), .. } = record {','''            let owners = match record {
                WalRecord::OrderUpdate { callbacks: Some(owners), .. } => owners.clone(),
                WalRecord::StrategyCallbackSource { strategy, .. } => vec![*strategy],
                _ => continue,
            };
            {''').replace('self.record(index as u64 + 1, owners)?;','self.record(index as u64 + 1, &owners)?;');old='''                    let WalRecord::OrderUpdate { update, callbacks: Some(owners) } = source else { return Err("callback order origin does not name owned parent news".into()); };
                    if !owners.contains(&input.strategy) { return Err("callback order origin belongs to another sleeve".into()); }
                    let expected = Self::slice(update, input.strategy)?;
                    if input.event != (engine_types::strategy_process::CallbackEvent::Order { update: expected }) { return Err("callback order view differs from its durable parent".into()); }''';new='''                    let expected = match source {
                        WalRecord::OrderUpdate { update, callbacks: Some(owners) } if owners.contains(&input.strategy) => engine_types::strategy_process::CallbackEvent::Order { update: Self::slice(update, input.strategy)? },
                        WalRecord::StrategyCallbackSource { strategy, event } if *strategy == input.strategy => event.clone(),
                        _ => return Err("callback source origin has no matching durable owner".into()),
                    };
                    if input.event != expected { return Err("callback view differs from its durable parent".into()); }''';assert old in s;s=s.replace(old,new);p.write_text(s)
p=Path('engine/engine-wal/src/callback_reader.rs');s=p.read_text().replace('    update: Option<serde_json::Value>,','''    update: Option<serde_json::Value>,
    strategy: Option<StrategyId>,
    event: Option<engine_types::strategy_process::CallbackEvent>,''');s=s.replace('            Some((owners, update))\n        } else { None };','''            Some((owners, engine_types::strategy_process::CallbackEvent::Order { update }))
        } else if envelope.kind == "strategy_callback_source" {
            Some((vec![envelope.strategy.ok_or_else(|| corrupt("callback source has no owner"))?], envelope.event.ok_or_else(|| corrupt("callback source has no event"))?))
        } else { None };''');p.write_text(s)
p=Path('engine/engine-core/src/tests.rs');s=p.read_text().replace('Some((owners.clone(), update.clone())),','Some((owners.clone(), engine_types::strategy_process::CallbackEvent::Order { update: update.clone() })),',1);s=s.replace('            _ => None,\n        };\n        Ok(Some(engine_types::strategy_process::CallbackWalRecord','            WalRecord::StrategyCallbackSource { strategy, event } => Some((vec![*strategy], event.clone())),\n            _ => None,\n        };\n        Ok(Some(engine_types::strategy_process::CallbackWalRecord',1);s=s.replace('        WalRecord::StrategyCallbackQueued { .. } =>','        WalRecord::StrategyCallbackSource { .. } => "strategy_callback_source",\n        WalRecord::StrategyCallbackQueued { .. } =>',1);p.write_text(s)
p=Path('engine/engine-core/src/replay.rs');s=p.read_text().replace('        WalRecord::StrategyCallbackQueued { input } =>','        WalRecord::StrategyCallbackSource { strategy, event } => format!("callback source {} {event:?}", names.strategy(*strategy)),\n        WalRecord::StrategyCallbackQueued { input } =>',1);p.write_text(s)
p=Path('engine/engine-core/src/strategy_process/host.rs');s=p.read_text();old='''        self.enqueue_inner(strategy, &EngineEvent::Order(update), Some(origin))?;
        self.order_news.accepted(strategy, origin);
        Ok(())''';new='''        self.enqueue_source(strategy, CallbackEvent::Order { update }, origin)
    }

    pub fn enqueue_source(&mut self, strategy: StrategyId, event: CallbackEvent, origin: engine_types::strategy_process::CallbackOrderOrigin) -> Result<(), String> {
        self.enqueue_inner(strategy, &event.engine_event()?, Some(origin))?;
        self.order_news.accepted(strategy, origin);
        Ok(())''';assert old in s;s=s.replace(old,new,1);p.write_text(s)
p=Path('engine/engine-core/src/engine/strategy_callbacks.rs');s=p.read_text().replace('if let Some((owners, update)) = record.source {','if let Some((owners, event)) = record.source {',1);s=s.replace('''                let update = crate::strategy_process::order_news::OrderNews::slice(&update, strategy).map_err(EngineError::State)?;''','''                let event = match event {
                    engine_types::strategy_process::CallbackEvent::Order { update } => engine_types::strategy_process::CallbackEvent::Order { update: crate::strategy_process::order_news::OrderNews::slice(&update, strategy).map_err(EngineError::State)? },
                    event => event,
                };''',1).replace('self.host.callbacks.enqueue_order(strategy, update, origin)','self.host.callbacks.enqueue_source(strategy, event, origin)',1);
needle='    fn service_order_callback_sources(&mut self) -> Result<(), EngineError> {';insert='''    pub(super) fn deliver_callback_source(&mut self, strategy: StrategyId, event: EngineEvent) -> Result<(), EngineError> {
        if !self.host.callbacks.isolated() {
            self.host.feed(&self.books, strategy, &event, clock::now_ns());
            return Ok(());
        }
        self.ensure_callback_reader(&[])?;
        let event = engine_types::strategy_process::CallbackEvent::from(&event);
        let ready = !self.host.callbacks.order_news.unread_for(strategy);
        let sequence = self.wal.append(&WalRecord::StrategyCallbackSource { strategy, event: event.clone() })?;
        self.host.callbacks.order_news.record(sequence, &[strategy]).map_err(EngineError::State)?;
        if ready {
            let origin = self.host.callbacks.order_news.origin(sequence).map_err(EngineError::State)?;
            if let Err(error) = self.host.callbacks.enqueue_source(strategy, event, origin) { self.host.callbacks.faults.insert(strategy, error); }
        }
        Ok(())
    }

''';assert needle in s;s=s.replace(needle,insert+needle);p.write_text(s)
p=Path('engine/engine-core/src/engine/intent_admission.rs');s=p.read_text();s=s.replace('pub(super) fn tell_refused(&mut self, intent: &Intent, reason: &str) {','pub(super) fn tell_refused(&mut self, intent: &Intent, reason: &str) -> Result<(), EngineError> {',1);s=s.replace('''        let now = clock::now_ns();
        self.host.feed(&self.books, intent.strategy, &event, now);
    }

    /// Turn an entry''','''        self.deliver_callback_source(intent.strategy, event)
    }

    /// Turn an entry''',1);import re;s=re.sub(r'(self\.tell_refused\([^\n]+\));',r'\1?;',s);p.write_text(s)
p=Path('engine/engine-core/src/engine/scheduling.rs');s=p.read_text();s=re.sub(r'(self\.tell_refused\([^\n]+\));',r'\1?;',s);p.write_text(s)
p=Path('engine/engine-wal/tests/wal.rs');s=p.read_text().replace('assert!(matches!(update, OrderUpdate::Fill { fee: None, .. }));','assert!(matches!(update, engine_types::strategy_process::CallbackEvent::Order { update: OrderUpdate::Fill { fee: None, .. } }));',1);p.write_text(s)
