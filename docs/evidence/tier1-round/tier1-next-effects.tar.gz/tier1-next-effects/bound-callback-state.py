from pathlib import Path
root=Path('/tmp/tier1-next-effects/callback-bounds/engine')
p=root/'engine-core/src/strategy_process/state.rs';s=p.read_text()
s=s.replace('    bytes: BTreeMap<StrategyId, usize>,','    bytes: BTreeMap<StrategyId, usize>,\n    prepared_bytes: BTreeMap<StrategyId, usize>,\n    committed_bytes: BTreeMap<StrategyId, usize>,')
s=s.replace('let used = self.bytes.get(&input.strategy).copied().unwrap_or_default();','let used: usize = self.bytes.values().sum();')
s=s.replace('        self.capacity_for(&input, 0)?;','''        self.capacity_for(&input, 0)?;
        let prepared = Self::preparation_size(input)?;
        if prepared > 0 {
            self.preparation_capacity(input.strategy, prepared)?;
        }'''.replace('preparation_size(input)', 'preparation_size(&input)'))
s=s.replace('                state.timers.retain(|timer| timer.id != id);','''                state.timers.retain(|timer| timer.id != id);
                self.committed_bytes.insert(input.strategy, Self::encoded_size(state)?);''')
s=s.replace('        *self.bytes.entry(input.strategy).or_default() += Self::size(&input)?;','''        *self.bytes.entry(input.strategy).or_default() += Self::size(&input)?;
        if prepared > 0 { self.prepared_bytes.insert(input.strategy, prepared); }''')
s=s.replace('''        Self::encoded_size(input)?;
        self.bytes.get(&input.strategy).copied().ok_or_else(|| "callback byte owner absent".into())''','''        if input.snapshot().is_some_and(|snapshot| snapshot.strategy != input.strategy) {
            return Err("prepared invocation escapes its owner".into());
        }
        let size = Self::preparation_size(input)?;
        self.preparation_capacity(input.strategy, size)?;
        Ok(size)''')
s=s.replace('        self.bytes.insert(input.strategy, next);','        self.prepared_bytes.insert(input.strategy, next);')
a=s.index('    pub fn commit(');b=s.index('\n    pub fn replay(',a)
s=s[:a]+'''    fn preparation_size(input: &StrategyCallbackInput) -> Result<usize, String> {
        if input.snapshot().is_none() { return Ok(0); }
        Self::encoded_size(&input.preparation)
    }

    fn preparation_capacity(&self, strategy: StrategyId, size: usize) -> Result<(), String> {
        if self.prepared_bytes.contains_key(&strategy) {
            return Err("strategy has more than one prepared invocation".into());
        }
        let used: usize = self.prepared_bytes.values().sum();
        if used.saturating_add(size) > MAX_PROCESS_PROPOSAL_BYTES {
            return Err("strategy prepared invocation budget is full".into());
        }
        Ok(())
    }

    fn process_size(state: &StrategyProcessState) -> Result<usize, String> {
        state.runtime.validate()?;
        if state.timers.len() > engine_types::strategy_process::MAX_PROCESS_TIMERS {
            return Err("strategy committed timer budget is full".into());
        }
        let mut timers = std::collections::BTreeSet::new();
        if state.timers.iter().any(|timer| !timers.insert(timer.id)) {
            return Err("strategy committed timer identity is repeated".into());
        }
        Self::encoded_size(state)
    }

    fn process_capacity(&self, state: &StrategyProcessState) -> Result<usize, String> {
        let size = Self::process_size(state)?;
        let used: usize = self.committed_bytes.iter().filter(|(strategy, _)| **strategy != state.strategy).map(|(_, bytes)| bytes).sum();
        if used.saturating_add(size) > MAX_PROCESS_PROPOSAL_BYTES {
            return Err("strategy committed process budget is full".into());
        }
        Ok(size)
    }

    pub fn can_commit(&self, input_id: u64, state: &StrategyProcessState) -> Result<usize, String> {
        let input = self.inputs.get(&input_id).ok_or("strategy commit has no accepted callback")?;
        if input.snapshot().is_none() || state.strategy != input.strategy || state.last_callback_id != input_id {
            return Err("strategy commit belongs to another callback".into());
        }
        if self.inputs.values().find(|pending| pending.strategy == state.strategy)
            .is_some_and(|pending| pending.callback_id != input_id) {
            return Err("strategy commit overtakes an earlier callback".into());
        }
        self.process_capacity(state)
    }

    pub fn commit(&mut self, input_id: u64, state: StrategyProcessState) -> Result<(), String> {
        let committed_size = self.can_commit(input_id, &state)?;
        let input = self.inputs.get(&input_id).ok_or("strategy commit has no accepted callback")?;
        let size = Self::size(input)?;
        let used = self.bytes.get_mut(&state.strategy).ok_or("strategy callback byte ownership is absent")?;
        *used = used.checked_sub(size).ok_or("strategy callback byte ownership underflow")?;
        self.prepared_bytes.remove(&state.strategy);
        self.committed_bytes.insert(state.strategy, committed_size);
        self.inputs.remove(&input_id);
        self.committed.insert(state.strategy, state);
        Ok(())
    }
''' +s[b:]
s=s.replace('''                        process.runtime.validate()?;
                        if process.strategy.idx() >= strategy_count
                            || state.committed.insert(process.strategy, process.clone()).is_some() {''','''                        let size = state.process_capacity(process)?;
                        if process.strategy.idx() >= strategy_count
                            || state.committed.insert(process.strategy, process.clone()).is_some() {''')
s=s.replace('''                        state.next_id = state.next_id.max(process.last_callback_id''','''                        state.committed_bytes.insert(process.strategy, size);
                        state.next_id = state.next_id.max(process.last_callback_id''')
s=s.replace('''                    for input in strategy_callbacks { state.validate_input(input, strategy_count)?; state.accept(input.clone())?; }''','''                    for input in strategy_callbacks {
                        state.validate_input(input, strategy_count)?;
                        if input.snapshot().is_some() && state.inputs.values().any(|known| known.strategy == input.strategy) {
                            return Err("prepared restatement overtakes an earlier input".into());
                        }
                        state.accept(input.clone())?;
                    }''')
p.write_text(s)
p=root/'engine-core/src/engine/strategy_callbacks.rs';s=p.read_text();a=s.index('        let transition = if actions.is_empty()');s=s[:a]+'''        if let Err(error) = self.host.callbacks.state.can_commit(completion.input_id, &process) {
            return self.fail_strategy_callback(completion.strategy, error);
        }
'''+s[a:];p.write_text(s)
p=root/'engine-core/src/strategy_process/host.rs';s=p.read_text().replace('let used = self.unwritten_bytes.get(&strategy).copied().unwrap_or_default();','let used = self.unwritten_bytes.values().sum();');p.write_text(s)
