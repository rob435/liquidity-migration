from pathlib import Path
p=Path('engine/engine-core/src/tests.rs');s=p.read_text();needle='impl Wal for MockWal {\n';insert='''struct MockCallbackReader(Arc<Mutex<Vec<WalRecord>>>);

impl engine_types::strategy_process::CallbackWalReader for MockCallbackReader {
    fn start(&self) -> engine_types::strategy_process::CallbackWalCursor {
        engine_types::strategy_process::CallbackWalCursor { segment: 1, sequence: 1, offset: 0 }
    }
    fn next(&mut self, cursor: engine_types::strategy_process::CallbackWalCursor) -> Result<Option<engine_types::strategy_process::CallbackWalRecord>, WalError> {
        let records = self.0.lock().unwrap();
        let Some(record) = records.get(cursor.sequence as usize - 1) else { return Ok(None); };
        let source = match record {
            WalRecord::OrderUpdate { callbacks: Some(owners), update } => Some((owners.clone(), update.clone())),
            _ => None,
        };
        Ok(Some(engine_types::strategy_process::CallbackWalRecord {
            next: engine_types::strategy_process::CallbackWalCursor { segment: cursor.segment, sequence: cursor.sequence + 1, offset: cursor.offset + 1 }, source,
        }))
    }
}

''';assert needle in s;s=s.replace(needle,insert+needle+'''    fn callback_reader(&mut self) -> Result<Option<Box<dyn engine_types::strategy_process::CallbackWalReader>>, WalError> {
        Ok(Some(Box::new(MockCallbackReader(self.records.clone()))))
    }

''',1);p.write_text(s)
p=Path('engine/engine-core/src/engine/strategy_callbacks.rs');s=p.read_text();needle='    #[tokio::test]\n    async fn successive_callbacks_cannot_grow_committed_timers_without_a_bound()';insert='''    #[tokio::test]
    async fn a_full_callback_inbox_retains_private_fill_and_boot_until_delivery() {
        use crate::strategy_process::state::CallbackState;
        use engine_types::strategy_process::{CallbackEvent, StrategyCallbackInput, MAX_PROCESS_PROPOSAL_BYTES};
        let (mut engine, records, input_id) = prepared().await;
        let snapshot = engine.host.callbacks.state.inputs[&input_id].snapshot().unwrap().clone();
        engine.host.callbacks.state = CallbackState::default();
        let mut filler = StrategyCallbackInput {
            order_origin: None, callback_id: 100, strategy: StrategyId(0),
            preparation: CallbackPreparation::Prepared { snapshot },
            event: CallbackEvent::IntentRefused { symbol: SymbolId(0), reduce_only: false, reason: String::new() },
        };
        let overhead = CallbackState::size(&filler).unwrap();
        let CallbackEvent::IntentRefused { reason, .. } = &mut filler.event else { unreachable!() };
        *reason = "x".repeat(MAX_PROCESS_PROPOSAL_BYTES - overhead - 8);
        engine.host.callbacks.state.accept(filler).unwrap();
        let sent = WalRecord::OrderSent {
            dispatch: None,
            request: OrderRequest { client_order_id: "callback-owned".into(), strategy: StrategyId(0), symbol: SymbolId(0), side: Side::Buy, qty: 0.01, kind: OrderKind::Market, stop: Some(StopSpec { trigger_px: 29_000.0 }), reduce_only: false, close_position: false, sleeve_effect: None, exact_terms: None }, wire_ns: 1, arrival_mid: 30_000.0,
        };
        engine.books.orders.apply(&sent);
        engine.books.registry.own("callback-owned", StrategyId(0));
        engine.wal.append(&sent).unwrap();
        let fill = OrderUpdate::Fill { allocation: None, amounts: None, exec_id: "callback-private-fill".into(), client_order_id: "callback-owned".into(), symbol: SymbolId(0), side: Side::Buy, qty: 0.01, px: 30_000.0, fee: Some(0.1), is_maker: false, forced_close: None, venue_ts_ms: clock::wall_ms(), recv_ns: clock::now_ns() };
        engine.take_update(fill).await.unwrap();
        assert!(engine.host.callbacks.unwritten.is_empty());
        assert!(engine.host.callbacks.order_news.unread_for(StrategyId(0)), "private news was discarded when the callback inbox filled");
        assert!(!engine.feed_one_strategy(StrategyId(0), &EngineEvent::Boot, clock::now_ns()));
        assert!(engine.host.callbacks.pending_boot.contains(&StrategyId(0)));
        assert_eq!(engine.host.callbacks.state.inputs.len(), 1);
        let parent = records.lock().unwrap().iter().find_map(|record| match record { WalRecord::OrderUpdate { callbacks: Some(owners), update: update @ OrderUpdate::Fill { .. } } => Some((owners.clone(), update.clone())), _ => None }).expect("one durable parent must carry callback ownership");
        assert_eq!(parent.0, [StrategyId(0)]);
        let OrderUpdate::Fill { allocation, .. } = &parent.1 else { unreachable!() };
        assert!(allocation.is_some(), "terminal sender eviction must not erase callback allocation");
        engine.host.callbacks.state.commit(100, StrategyProcessState { strategy: StrategyId(0), last_callback_id: 100, runtime: engine.host.strategies[0].runtime_state().unwrap().unwrap(), timers: Vec::new(), retained_signal_subscriptions: None }).unwrap();
        for _ in 0..100 {
            engine.service_order_callback_sources().unwrap();
            if !engine.host.callbacks.order_news.unread() { break; }
            if engine.host.callbacks.order_news.pending() {
                let completion = engine.host.callbacks.order_news.completed.recv().await.unwrap();
                engine.on_order_callback_source(completion).unwrap();
            }
        }
        assert!(!engine.host.callbacks.order_news.unread(), "private news never retried after capacity returned");
        engine.service_strategy_callbacks().unwrap();
        let result = engine.host.callbacks.durable.recv().await;
        engine.on_callback_durable(result).unwrap();
        let inputs: Vec<_> = engine.host.callbacks.state.inputs.values().cloned().collect();
        assert_eq!(inputs.len(), 2);
        assert!(matches!(inputs[0].event, CallbackEvent::Order { .. }));
        assert!(inputs[0].order_origin.is_some());
        assert!(matches!(inputs[1].event, CallbackEvent::Boot));
        assert!(!engine.host.callbacks.pending_boot.contains(&StrategyId(0)));
        engine.service_strategy_callbacks().unwrap();
        let result = engine.host.callbacks.durable.recv().await;
        engine.on_callback_durable(result).unwrap();
        let facts = engine.host.callbacks.state.inputs[&inputs[0].callback_id].snapshot().unwrap().symbols[0].facts.as_ref().unwrap().clone();
        assert_eq!(facts.filled_signed_qty, 0.01, "order callback snapshot preceded committed fill accounting");
        assert_eq!(facts.open_order_count, 0);
        assert_eq!(records.lock().unwrap().iter().filter(|record| matches!(record, WalRecord::OrderUpdate { callbacks: Some(_), update: OrderUpdate::Fill { .. } })).count(), 1);
        let replay = records.lock().unwrap().clone();
        let mut restored = crate::strategy_process::order_news::OrderNews::default();
        restored.attach(engine.wal.callback_reader().unwrap().unwrap(), &replay, 1).unwrap();
        assert!(!restored.unread(), "accepted callback source redelivered on restart");
        engine.host.callbacks.stop().await;
    }

''';assert needle in s;s=s.replace(needle,insert+needle,1);p.write_text(s)
