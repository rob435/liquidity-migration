from pathlib import Path
p=Path('engine/engine-types/src/wal.rs');s=p.read_text().replace('''    StrategyCallbackSource {
        strategy: StrategyId,''','''    StrategyCallbackSource {
        #[serde(default, skip_serializing_if = "Option::is_none")]
        placement: Option<String>,
        strategy: StrategyId,''',1);p.write_text(s)
for name in ['engine/engine-core/src/replay.rs','engine/engine-core/src/tests.rs','engine/engine-core/src/strategy_process/order_news.rs']:
 p=Path(name);s=p.read_text().replace('WalRecord::StrategyCallbackSource { strategy, event }','WalRecord::StrategyCallbackSource { strategy, event, .. }');p.write_text(s)
p=Path('engine/engine-core/src/strategy_process/host.rs');s=p.read_text().replace('    pub retry_inputs: super::retry::RetryInputs,','    pub retry_inputs: super::retry::RetryInputs,\n    pub refused_orders: BTreeSet<String>,',1);needle='        let (completed, completions) = tokio::sync::mpsc::channel';insert='''        let effects = crate::effects::Effects::replay(records, strategies.len())?;
        let unfinished: BTreeSet<_> = effects.transitions.values().flat_map(|transition| transition.order_ids.iter().flatten()).collect();
        let refused_orders = records.iter().filter_map(|record| match record {
            WalRecord::StrategyCallbackSource { placement: Some(id), .. } if unfinished.contains(id) => Some(id.clone()),
            _ => None,
        }).collect();
''';assert needle in s;s=s.replace(needle,insert+needle,1);s=s.replace('            retry_inputs: Default::default(),','            retry_inputs: Default::default(),\n            refused_orders,',1);p.write_text(s)
p=Path('engine/engine-core/src/engine/strategy_callbacks.rs');s=p.read_text().replace('fn deliver_callback_source(&mut self, strategy: StrategyId, event: EngineEvent)', 'fn deliver_callback_source(&mut self, strategy: StrategyId, event: EngineEvent, placement: Option<String>)',1);needle='        self.ensure_callback_reader(&[])?;\n        let event =';insert='''        if placement.as_ref().is_some_and(|id| self.host.callbacks.refused_orders.contains(id)) { return Ok(()); }
''';assert needle in s;s=s.replace(needle,insert+needle,1);s=s.replace('WalRecord::StrategyCallbackSource { strategy, event: event.clone() }','WalRecord::StrategyCallbackSource { placement: placement.clone(), strategy, event: event.clone() }',1);needle='        self.host.callbacks.order_news.record(sequence, &[strategy]).map_err(EngineError::State)?;';s=s.replace(needle,'''        if let Some(id) = placement {
            if self.host.effects.transitions.values().any(|transition| transition.order_ids.iter().flatten().any(|known| known == &id)) { self.host.callbacks.refused_orders.insert(id); }
        }
'''+needle,1);p.write_text(s)
p=Path('engine/engine-core/src/engine/intent_admission.rs');s=p.read_text();s=s.replace('self.journal_and_admit_intent(&intent, decided_ns)?','self.journal_and_admit_intent(&intent, decided_ns, client_order_id.as_deref())?',1);s=s.replace('''        decided_ns: u64,
    ) -> Result<bool, EngineError> {''','''        decided_ns: u64,
        client_order_id: Option<&str>,
    ) -> Result<bool, EngineError> {''',1);s=s.replace('self.tell_refused(intent, "unreal_number")?','self.tell_refused(intent, "unreal_number", client_order_id)?').replace('self.tell_refused(intent, "stale_quote")?','self.tell_refused(intent, "stale_quote", client_order_id)?').replace('self.deny_opening(intent, refusal)?','self.deny_opening(intent, refusal, client_order_id)?').replace('self.tell_refused(&intent, &reason)?','self.tell_refused(&intent, &reason, client_order_id.as_deref())?').replace('self.tell_refused(&intent, "batch_leverage_conflict")?','self.tell_refused(&intent, "batch_leverage_conflict", client_order_id.as_deref())?');s=s.replace('''        refusal: OpeningRefusal,
    ) -> Result<(), EngineError> {''','''        refusal: OpeningRefusal,
        client_order_id: Option<&str>,
    ) -> Result<(), EngineError> {''',1).replace('self.tell_refused(intent, refusal.as_str())?','self.tell_refused(intent, refusal.as_str(), client_order_id)?');s=s.replace('self.tell_refused(intent, why)?','self.tell_refused(intent, why, Some(client_order_id))?');s=s.replace('fn tell_refused(&mut self, intent: &Intent, reason: &str)','fn tell_refused(&mut self, intent: &Intent, reason: &str, client_order_id: Option<&str>)',1);s=s.replace('self.deliver_callback_source(intent.strategy, event)','self.deliver_callback_source(intent.strategy, event, client_order_id.map(str::to_owned))',1);p.write_text(s)
p=Path('engine/engine-core/src/engine/scheduling.rs');s=p.read_text();s=s.replace('''                        self.tell_refused(intent, "wake_action_limit")?;''','''                        let order_id = effect.and_then(|key| self.host.effects.transitions.get(&key.transition_id).and_then(|transition| transition.order_ids.get(key.index)).cloned().flatten());
                        self.tell_refused(intent, "wake_action_limit", order_id.as_deref())?;''',1);p.write_text(s)
p=Path('engine/engine-core/src/engine/strategy_effects.rs');s=p.read_text().replace('''.is_some_and(|id| self.books.orders.contains(id))''','''.is_some_and(|id| self.books.orders.contains(id) || self.host.callbacks.refused_orders.contains(id))''',1);needle='''        self.wal.append(&WalRecord::StrategyEffectCompleted {''';insert='''        let order_id = self.host.effects.transitions.get(&key.transition_id).and_then(|transition| transition.order_ids.get(key.index)).cloned().flatten();
''';s=s.replace(needle,insert+needle,1);s=s.replace('''        self.host.effects.complete(key).map_err(EngineError::State)
''','''        self.host.effects.complete(key).map_err(EngineError::State)?;
        if let Some(id) = order_id { self.host.callbacks.refused_orders.remove(&id); }
        Ok(())
''',1);p.write_text(s)
