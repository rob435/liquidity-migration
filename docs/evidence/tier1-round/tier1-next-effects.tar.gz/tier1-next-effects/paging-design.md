Purpose: Retain all accepted callbacks on WAL while loading only active heads, so inactive owners cannot consume active inbox or stop rotation.

Chosen bounded representation:
- PagedCallbacks slots map callback_id -> {strategy, queued Cursor, prepared Option<Cursor>, event SHA256}. Payloads remain on immutable WAL segments, including legacy SegmentBase nested input arrays.
- New runtime accepts at most one queued callback per sleeve; identical durable source replay returns accepted via slot hash. Market updates retain one latest dirty flag; timer/signal/event/control sources retry from their existing owners. Legacy multiple queued inputs are represented as compact cursor slots and drained FIFO. No new per-sleeve backlog grows in metadata.
- State.inputs contains only active heads loaded under existing64MiB resident input and64MiB prepared budgets. Initial/committed process memory remains existing global64MiB bound; inactive committed runtime retained but not instantiated/executed.
- New v5 fields planned: strategy_callback_queues Vec<CallbackQueueSlot>, strategy_callback_sources Vec<SourceFrontier>, signal_callback_deliveries Vec<ExactDeliveryIdentity>. strategy_callbacks legacy arrays serialize empty after paging; reader still extracts old nested inputs from old SegmentBase.
- SourceFrontier per sleeve records source read cursor + accepted origin + latest origin across segments. Rotation preserves these and old segment references, no unread-source rotation veto.
- Shared callback WAL reader supports arbitrary family segments, position inventory, one callback input extraction at a frame/legacy nested array. Bounded selective Deserialize (not full snapshot allocation). Source reads and active-head reads can have bounded separate1 read task each; unify if simpler.
- Boot must use paged replay before cloning all input payloads. Read current WAL frame positions on an off-core task; PagedCallbacks validates per-sleeve FIFO commit/preparation using slots; CallbackState owns committed process state and loaded heads only. Embedded/direct fixture CallbackState::replay remains for legacy tests.
- New acceptance: append CallbackQueued -> barrier -> slot ownership; keep payload only if active head fits else drop transient payload and load later. Existing input source marking is only after acceptance (barrier included by rotation guard).
- Preparation: load exact input/hash from queued or legacy base cursor, fresh snapshot after prior effects, append Prepared -> barrier -> slot prepared cursor. Commit atomically clears slot with process/effect outcome.
- SignalState replay must mark exact retained accepted observations delivered from CallbackQueued; persist delivered identities for no-op callbacks that commit without Consume so restart doesn't re-offer them. No synthetic consumption.

Current completed proof status before paging:
- callback-complete-after.log18 Linux callback tests pass from source-only isolated snapshot with paired fixes.
- callback-all-budgets-after.log11 passed incl initial runtime/route manifest/prepared/inbox budgets.
- order-news-inbox-before.log missing parent retry registration fails; callback-resources-and-retry-after.log15pass.
- refusal-source-before.log internal host.feed drops refusal when inbox full.
- refusal-disposition-before.log restart re-admits effect with durable refusal when flush_placements doesn't recognize refused_orders.
- inactive-callback-before.log inactive constructor wrongly requests executable runtime.
- refusal-proof-before/engine source retained; mutation.py defines targeted changes; phase1 original intent snapshot refusal-source-before-intent.rs; phase2 restored source routing, retained missing disposition check + inactive constructor guard.
- callback-retry/engine is same source with those three fixes restored; root portfolio DTOs present but control module unused at snapshot (warning only).
- v5-reader-before.log missing typed fill_quantity accepted; v5-and-order-news-wal-after.log49pass before newer source/portfolio fields.
- v4-identities-before.log actual v4 without new identities rejected; reader corrected requirements to v5 only. Latest whole WAL rerun was compilation-blocked by transient serde_json production dep; peer now fixed. Need rerun.

Current shared code gaps before paging:
- strategy_process/order_news.rs source queue readonly worker + new actual file restart per-sleeve0.25/0.75 test not yet run (test filter callback omitted name).
- strategy_process/retry.rs latest market flags + FIFO durable retry keys; new full-inbox refusal/latestQuote regression passes in prior snapshot before latest FIFO rewrite; final run needed.
- engine/strategy_callbacks.rs1094lines mostly tests; root owns finaldocs. Source variants are generic StrategyCallbackSource{placement:Option<String>,strategy,event}. order_origin serialized name remains unshipped newfield despite generic meaning.
- Host.refused_orders validates pending transition intent owner/symbol/reduce flag, retains only unfinished placements. Tell_refused optionalclientID explicitly propagated through existing admission helpers; root policy edits preserve.
- Need slow callback WAL read/private cancel liveness proof; actual read worker bounded1 but not yet tested with blocked filesystem stub.
- Need independently review venue agent async amend DispatchWrite::Amend(Box<DurableAmend>) using shared dispatch durability owner; agent says17restingtests pass + stalled sync before failure.

Coordination: root owns portfolio controls, exact inventory/risk/upper policy; inputs owns catalog/identity/source lifecycle and asks us to own signal delivery-marker persistence for paging; venue owns catalog adapters/exact amend and cannot take reader extension. Root approved paging and awaits exact DTO handshake. All future builds CARGO_INCREMENTAL=0, no funded/live operations.
