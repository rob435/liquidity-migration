from pathlib import Path
p=Path('engine/engine-core/src/engine/strategy_callbacks.rs');s=p.read_text();start=s.index('        use crate::strategy_process::state::CallbackState;',s.index('async fn a_full_callback_inbox'));end=s.index('        let sent = WalRecord::OrderSent',start);setup=s[start:end];helper='''    async fn full_inbox() -> (Engine<crate::tests::MockWal, crate::tests::MockRisk, crate::tests::MockVenue>, std::sync::Arc<std::sync::Mutex<Vec<WalRecord>>>) {
'''+setup+'        (engine, records)\n    }\n\n';s=s[:start]+'''        use engine_types::strategy_process::CallbackEvent;
        let (mut engine, records) = full_inbox().await;
'''+s[end:];needle='    #[tokio::test]\n    async fn a_full_callback_inbox';s=s.replace(needle,helper+needle,1)
needle='    #[tokio::test]\n    async fn successive_callbacks_cannot';insert='''    #[tokio::test]
    async fn a_refusal_retries_from_its_durable_source_before_the_latest_market_wake() {
        use engine_types::strategy_process::CallbackEvent;
        let (mut engine, records) = full_inbox().await;
        let intent = Intent { strategy: StrategyId(0), symbol: SymbolId(0), side: Side::Buy, qty: 0.01, kind: OrderKind::Market, stop: Some(StopSpec { trigger_px: 90.0 }), reduce_only: false, tag: "refusal".into(), decided_ns: clock::now_ns(), work: None, leverage: None };
        engine.tell_refused(&intent, "test refusal", None).unwrap();
        assert!(engine.host.callbacks.order_news.unread(), "full inbox lost an internal refusal");
        for bid in [99.0, 199.0] {
            let event = MarketEvent::Quote { symbol: SymbolId(0), quote: engine_types::Quote { bid_px: bid, ask_px: bid + 2.0, recv_ns: clock::now_ns(), ..Default::default() } };
            engine.books.market.apply(&event);
            assert!(!engine.feed_one_strategy(StrategyId(0), &EngineEvent::Market(event), clock::now_ns()));
        }
        assert_eq!(engine.host.callbacks.retry_inputs.market.len(), 1, "overload retained each historical quote instead of one latest wake");
        engine.host.callbacks.state.commit(100, StrategyProcessState { strategy: StrategyId(0), last_callback_id: 100, runtime: engine.host.strategies[0].runtime_state().unwrap().unwrap(), timers: Vec::new(), retained_signal_subscriptions: None }).unwrap();
        for _ in 0..100 {
            engine.service_order_callback_sources().unwrap();
            if !engine.host.callbacks.order_news.unread() { break; }
            if engine.host.callbacks.order_news.pending() {
                let completion = engine.host.callbacks.order_news.completed.recv().await.unwrap();
                engine.on_order_callback_source(completion).unwrap();
            }
        }
        engine.retry_callback_inputs();
        assert!(engine.host.callbacks.retry_inputs.market.is_empty());
        let inputs: Vec<_> = engine.host.callbacks.unwritten.iter().collect();
        assert_eq!(inputs.len(), 2);
        assert!(matches!(&inputs[0].event, CallbackEvent::IntentRefused { reason, .. } if reason == "test refusal"));
        assert!(matches!(inputs[1].event, CallbackEvent::Quote { quote, .. } if quote.bid_px == 199.0));
        assert!(inputs[0].order_origin.is_some());
        let rows = records.lock().unwrap().clone();
        let mut restored = crate::strategy_process::order_news::OrderNews::default();
        restored.attach(engine.wal.callback_reader().unwrap().unwrap(), &rows, 1).unwrap();
        assert!(restored.unread(), "restart before callback admission lost the durable refusal");
        engine.host.callbacks.stop().await;
    }

    #[tokio::test]
    async fn a_refusal_source_is_a_replayable_disposition_before_effect_completion() {
        use engine_types::strategy_process::CallbackEvent;
        let (mut engine, records, input_id) = prepared().await;
        let mut completion = proposal_completion(&mut engine, input_id);
        completion.result.as_mut().unwrap().1.actions = vec![Action::Place(Intent { strategy: StrategyId(0), symbol: SymbolId(0), side: Side::Buy, qty: 0.01, kind: OrderKind::Market, stop: Some(StopSpec { trigger_px: 90.0 }), reduce_only: false, tag: "denied-effect".into(), decided_ns: clock::now_ns(), work: None, leverage: None })];
        engine.on_strategy_callback(Some(completion)).unwrap();
        let result = engine.host.callbacks.durable.recv().await;
        engine.on_callback_durable(result).unwrap();
        let transition = engine.host.effects.transitions.values().next().unwrap().clone();
        let Action::Place(intent) = &transition.effects[0] else { unreachable!() };
        let id = transition.order_ids[0].as_deref().unwrap();
        engine.tell_refused(intent, "test denied effect", Some(id)).unwrap();
        let replay = records.lock().unwrap().clone();
        engine.host.callbacks.stop().await;
        engine.host.callbacks = CallbackHost::new(CallbackExecution::Isolated { executable: "/bin/false".into() }, &engine.host.strategies, &replay).unwrap();
        assert!(engine.host.callbacks.refused_orders.contains(id));
        engine.host.effects = crate::effects::Effects::replay(&replay, 1).unwrap();
        engine.host.pending.clear();
        let before = records.lock().unwrap().len();
        engine.flush_placements(vec![(intent.clone(), Some(EffectKey { transition_id: transition.id, index: 0 }))], clock::now_ns()).await.unwrap();
        assert!(engine.host.effects.transitions.is_empty());
        assert!(engine.host.callbacks.refused_orders.is_empty());
        assert!(engine.books.orders.orders.is_empty());
        assert!(!records.lock().unwrap()[before..].iter().any(|record| matches!(record, WalRecord::StrategyCallbackSource { .. } | WalRecord::OrderSent { .. } | WalRecord::Intent { .. })), "restart re-admitted an effect whose refusal was already durable");
        assert_eq!(replay.iter().filter(|record| matches!(record, WalRecord::StrategyCallbackSource { event: CallbackEvent::IntentRefused { .. }, .. })).count(), 1);
    }

    #[tokio::test]
    async fn an_inactive_sleeve_preserves_uncommitted_callbacks_and_reactivates_the_same_tail() {
        struct Paused;
        impl Strategy for Paused {
            fn name(&self) -> &str { "paused" }
            fn subscriptions(&self) -> Vec<Subscription> { Vec::new() }
            fn callback_enabled(&self) -> bool { false }
            fn on_event(&mut self, _: &EngineEvent, _: &mut dyn engine_types::StrategyCtx) { panic!("paused callback executed"); }
            fn runtime_state(&self) -> Result<Option<engine_types::strategy_process::StrategyRuntimeState>, String> { panic!("inactive constructor requested an executable runtime"); }
        }
        let (mut engine, records, input_id) = prepared().await;
        let mut completion = proposal_completion(&mut engine, input_id);
        completion.result.as_mut().unwrap().1.actions.clear();
        engine.on_strategy_callback(Some(completion)).unwrap();
        let result = engine.host.callbacks.durable.recv().await;
        engine.on_callback_durable(result).unwrap();
        assert!(engine.feed_one_strategy(StrategyId(0), &EngineEvent::Boot, clock::now_ns()));
        engine.service_strategy_callbacks().unwrap();
        let result = engine.host.callbacks.durable.recv().await;
        engine.on_callback_durable(result).unwrap();
        let base = engine.rotation_base(clock::wall_ms());
        let active = std::mem::replace(&mut engine.host.strategies, vec![Box::new(Paused)]);
        engine.host.callbacks.stop().await;
        engine.host.callbacks = CallbackHost::new(CallbackExecution::Isolated { executable: "/bin/false".into() }, &engine.host.strategies, std::slice::from_ref(&base)).unwrap();
        let pending = engine.host.callbacks.state.inputs.clone();
        let committed = engine.host.callbacks.state.committed.clone();
        records.lock().unwrap().clear();
        engine.restore_strategy_callbacks().await.unwrap();
        assert_eq!(engine.host.strategies[0].name(), "paused");
        assert_eq!(engine.host.callbacks.state.inputs, pending);
        assert_eq!(engine.host.callbacks.state.committed, committed);
        assert!(!engine.host.callbacks.running());
        assert!(!records.lock().unwrap().iter().any(|record| matches!(record, WalRecord::StrategyCallbackPrepared { .. } | WalRecord::StrategyProcessTransitionQueued { .. })));
        let rotated = engine.rotation_base(clock::wall_ms());
        engine.host.strategies = active;
        engine.host.callbacks = CallbackHost::new(CallbackExecution::Isolated { executable: "/bin/false".into() }, &engine.host.strategies, &[rotated]).unwrap();
        assert_eq!(engine.host.callbacks.state.inputs, pending);
        engine.service_strategy_callbacks().unwrap();
        assert!(matches!(engine.host.callbacks.write, Some(CallbackWrite::Prepare(_))));
        let result = engine.host.callbacks.durable.recv().await;
        engine.on_callback_durable(result).unwrap();
        assert!(engine.host.callbacks.state.inputs.values().next().unwrap().snapshot().is_some());
        assert_eq!(engine.host.callbacks.state.committed, committed);
    }

''';assert needle in s;s=s.replace(needle,insert+needle,1);p.write_text(s)
